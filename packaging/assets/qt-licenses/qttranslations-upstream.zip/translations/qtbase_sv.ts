<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv_SE">
<context>
    <name>CloseButton</name>
    <message>
        <source>Close Tab</source>
        <translation>Stäng flik</translation>
    </message>
</context>
<context>
    <name>MAC_APPLICATION_MENU</name>
    <message>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Inställningar…</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Tjänster</translation>
    </message>
    <message>
        <source>Hide %1</source>
        <translation>Dölj %1</translation>
    </message>
    <message>
        <source>Hide Others</source>
        <translation>Dölj övriga</translation>
    </message>
    <message>
        <source>Show All</source>
        <translation>Visa alla</translation>
    </message>
    <message>
        <source>Quit %1</source>
        <translation>Avsluta %1</translation>
    </message>
</context>
<context>
    <name>Print Device Input Slot</name>
    <message>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
</context>
<context>
    <name>Print Device Output Bin</name>
    <message>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
</context>
<context>
    <name>QAbstractFileIconProvider</name>
    <message>
        <source>Drive</source>
        <translation>Enhet</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <source>File Folder</source>
        <comment>Match Windows Explorer</comment>
        <translation>Filmapp</translation>
    </message>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation>Mapp</translation>
    </message>
    <message>
        <source>Alias</source>
        <comment>macOS Finder</comment>
        <translation>Alias</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <comment>All other platforms</comment>
        <translation>Genväg</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Okänt</translation>
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <source>Socket operation timed out</source>
        <translation>Tidsgräns för uttagsåtgärd överstegs</translation>
    </message>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>Åtgärden på uttag stöds inte</translation>
    </message>
    <message>
        <source>Host not found</source>
        <translation>Värden hittades inte</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Anslutningen nekades</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Tidsgränsen för anslutning överstegs</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>Försöker ansluta när en anslutning pågår</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>Uttaget är inte anslutet</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Nätverket är inte nåbart</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>&amp;Select All</source>
        <translation>Markera &amp;allt</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>&amp;Stega uppåt</translation>
    </message>
    <message>
        <source>Step &amp;down</source>
        <translation>Stega &amp;nedåt</translation>
    </message>
</context>
<context>
    <name>QAccessibleActionInterface</name>
    <message>
        <source>Press</source>
        <translation>Tryck</translation>
    </message>
    <message>
        <source>Increase</source>
        <translation>Öka</translation>
    </message>
    <message>
        <source>Decrease</source>
        <translation>Minska</translation>
    </message>
    <message>
        <source>ShowMenu</source>
        <translation>Visa meny</translation>
    </message>
    <message>
        <source>SetFocus</source>
        <translation>Ställ in fokus</translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation>Växla</translation>
    </message>
    <message>
        <source>Scroll Left</source>
        <translation>Rulla vänster</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Rulla höger</translation>
    </message>
    <message>
        <source>Scroll Up</source>
        <translation>Rulla uppåt</translation>
    </message>
    <message>
        <source>Scroll Down</source>
        <translation>Rulla nedåt</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>Föregående sida</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Nästa sida</translation>
    </message>
    <message>
        <source>Triggers the action</source>
        <translation>Växlar åtgärden</translation>
    </message>
    <message>
        <source>Increase the value</source>
        <translation>Öka värdet</translation>
    </message>
    <message>
        <source>Decrease the value</source>
        <translation>Minska värdet</translation>
    </message>
    <message>
        <source>Shows the menu</source>
        <translation>Visar menyn</translation>
    </message>
    <message>
        <source>Sets the focus</source>
        <translation>Ställ in fokus</translation>
    </message>
    <message>
        <source>Toggles the state</source>
        <translation>Växlar tillståndet</translation>
    </message>
    <message>
        <source>Scrolls to the left</source>
        <translation>Rullar åt vänster</translation>
    </message>
    <message>
        <source>Scrolls to the right</source>
        <translation>Rullar åt höger</translation>
    </message>
    <message>
        <source>Scrolls up</source>
        <translation>Rullar upp</translation>
    </message>
    <message>
        <source>Scrolls down</source>
        <translation>Rullar ner</translation>
    </message>
    <message>
        <source>Goes back a page</source>
        <translation>Går tillbaka en sida</translation>
    </message>
    <message>
        <source>Goes to the next page</source>
        <translation>Går framåt en sida</translation>
    </message>
</context>
<context>
    <name>QAndroidPlatformTheme</name>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Yes to All</source>
        <translation>Ja till allt</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <source>No to All</source>
        <translation>Nej till allt</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Application &quot;%1&quot; requires Qt %2, found Qt %3.</source>
        <translation>Programmet &quot;%1&quot; kräver Qt %2, hittade Qt %3.</translation>
    </message>
    <message>
        <source>Incompatible Qt Library Error</source>
        <translation>Inkompatibelt Qt-biblioteksfel</translation>
    </message>
</context>
<context>
    <name>QAxSelect</name>
    <message>
        <source>Select ActiveX Control</source>
        <translation>Välj ActiveX Control</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>COM &amp;Object:</source>
        <translation>COM-&amp;objekt:</translation>
    </message>
    <message>
        <source>Sandboxing:</source>
        <translation>Sandboxing:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>In process</source>
        <translation>I process</translation>
    </message>
    <message>
        <source>Out of process</source>
        <translation>Utanför process</translation>
    </message>
    <message>
        <source>CLSID:</source>
        <translation>CLSID:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Nyckel:</translation>
    </message>
    <message>
        <source>Word&amp;nbsp;size:</source>
        <translation>Ordstorlek:</translation>
    </message>
    <message>
        <source>DLL:</source>
        <translation>DLL:</translation>
    </message>
    <message>
        <source>Binary:</source>
        <translation>Binär:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
</context>
<context>
    <name>QCocoaMenuBar</name>
    <message>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
</context>
<context>
    <name>QCocoaMenuItem</name>
    <message>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <source>Config</source>
        <translation>Konfiguration</translation>
    </message>
    <message>
        <source>Preference</source>
        <translation>Inställning</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Inställning</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>Konfigurera</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Avsluta</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Avsluta</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Klipp ut</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Klistra in</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Om Qt</translation>
    </message>
</context>
<context>
    <name>QCocoaTheme</name>
    <message>
        <source>Don&apos;t Save</source>
        <translation>Spara inte</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>Hu&amp;e:</source>
        <translation>Nya&amp;ns:</translation>
    </message>
    <message>
        <source>&amp;Sat:</source>
        <translation>&amp;Mättnad:</translation>
    </message>
    <message>
        <source>&amp;Val:</source>
        <translation>&amp;Ljushet:</translation>
    </message>
    <message>
        <source>&amp;Red:</source>
        <translation>&amp;Röd:</translation>
    </message>
    <message>
        <source>&amp;Green:</source>
        <translation>&amp;Grön:</translation>
    </message>
    <message>
        <source>Bl&amp;ue:</source>
        <translation>Bl&amp;å:</translation>
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
        <translation>Alfa&amp;kanal:</translation>
    </message>
    <message>
        <source>&amp;HTML:</source>
        <translation>&amp;HTML:</translation>
    </message>
    <message>
        <source>Cursor at %1, %2
Press ESC to cancel</source>
        <translation>Markör på %1, %2
Tryck ESC för att avbryta</translation>
    </message>
    <message>
        <source>Select Color</source>
        <translation>Välj färg</translation>
    </message>
    <message>
        <source>&amp;Basic colors</source>
        <translation>&amp;Basfärger</translation>
    </message>
    <message>
        <source>&amp;Custom colors</source>
        <translation>&amp;Anpassade färger</translation>
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
        <translation>&amp;Lägg till i anpassade färger</translation>
    </message>
    <message>
        <source>&amp;Pick Screen Color</source>
        <translation>&amp;Välj skärmfärg</translation>
    </message>
</context>
<context>
    <name>QComboBox</name>
    <message>
        <source>Open the combo box selection popup</source>
        <translation>Öppnar kombinationsruta för väljare</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falskt</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Sant</translation>
    </message>
</context>
<context>
    <name>QCommandLineParser</name>
    <message>
        <source>Displays version information.</source>
        <translation>Visar versionsinformation.</translation>
    </message>
    <message>
        <source>Displays help on commandline options.</source>
        <translation>Visar hjälp för kommandoradsalternativ.</translation>
    </message>
    <message>
        <source>Displays help, including generic Qt options.</source>
        <translation>Visar hjälp, inklusive allmänna Qt-alternativ.</translation>
    </message>
    <message>
        <source>Unknown option &apos;%1&apos;.</source>
        <translation>Okänt alternativ &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Unknown options: %1.</source>
        <translation>Okända alternativ: %1.</translation>
    </message>
    <message>
        <source>Missing value after &apos;%1&apos;.</source>
        <translation>Saknar värde efter &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Unexpected value after &apos;%1&apos;.</source>
        <translation>Oväntat värde efter &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>[options]</source>
        <translation>[alternativ]</translation>
    </message>
    <message>
        <source>Usage: %1</source>
        <translation>Användning: %1</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Alternativ:</translation>
    </message>
    <message>
        <source>Arguments:</source>
        <translation>Argument:</translation>
    </message>
</context>
<context>
    <name>QCupsJobWidget</name>
    <message>
        <source>Job</source>
        <translation>Jobb</translation>
    </message>
    <message>
        <source>Job Control</source>
        <translation>Jobbkontroll</translation>
    </message>
    <message>
        <source>Banner Pages</source>
        <translation>Försättssidor</translation>
    </message>
    <message>
        <source>Print Immediately</source>
        <translation>Skriv ut direkt</translation>
    </message>
    <message>
        <source>Hold Indefinitely</source>
        <translation>Håll kvar tills vidare</translation>
    </message>
    <message>
        <source>Day (06:00 to 17:59)</source>
        <translation>Dag (06:00 till 17:59)</translation>
    </message>
    <message>
        <source>Night (18:00 to 05:59)</source>
        <translation>Natt (18:00 till 05:59)</translation>
    </message>
    <message>
        <source>Second Shift (16:00 to 23:59)</source>
        <translation>Andra skiftet (16:00 till 23:59)</translation>
    </message>
    <message>
        <source>Third Shift (00:00 to 07:59)</source>
        <translation>Tredje skiftet (00:00 till 07:59)</translation>
    </message>
    <message>
        <source>Weekend (Saturday to Sunday)</source>
        <translation>Helg (Lördag till söndag)</translation>
    </message>
    <message>
        <source>Specific Time</source>
        <translation>Specifik tid</translation>
    </message>
    <message>
        <source>None</source>
        <comment>CUPS Banner page</comment>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>Standard</source>
        <comment>CUPS Banner page</comment>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Unclassified</source>
        <comment>CUPS Banner page</comment>
        <translation>Öppet</translation>
    </message>
    <message>
        <source>Confidential</source>
        <comment>CUPS Banner page</comment>
        <translation>Konfidentiellt</translation>
    </message>
    <message>
        <source>Classified</source>
        <comment>CUPS Banner page</comment>
        <translation>Begränsat hemligt</translation>
    </message>
    <message>
        <source>Secret</source>
        <comment>CUPS Banner page</comment>
        <translation>Hemligt</translation>
    </message>
    <message>
        <source>Top Secret</source>
        <comment>CUPS Banner page</comment>
        <translation>Kvalificerat hemligt</translation>
    </message>
    <message>
        <source>Scheduled &amp;printing:</source>
        <translation>Schemalag&amp;d utskrift:</translation>
    </message>
    <message>
        <source>&amp;Billing information:</source>
        <translation>&amp;Faktureringsinformation:</translation>
    </message>
    <message>
        <source>Job &amp;priority:</source>
        <translation>Jobb&amp;prioritet:</translation>
    </message>
    <message>
        <source>&amp;Start:</source>
        <comment>Banner page at start</comment>
        <translation>&amp;Start:</translation>
    </message>
    <message>
        <source>&amp;End:</source>
        <comment>Banner page at end</comment>
        <translation>Sl&amp;ut:</translation>
    </message>
</context>
<context>
    <name>QCupsPrinterSupport</name>
    <message>
        <source>Authentication Needed</source>
        <translation>Autentisering krävs</translation>
    </message>
    <message>
        <source>Authentication needed to use %1.</source>
        <translation>Autentisering krävs för att använda %1.</translation>
    </message>
    <message>
        <source>Authentication needed to use %1 on %2.</source>
        <translation>Autentisering krävs för att använda %1 på %2.</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Användarnamn:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Lösenord:</translation>
    </message>
</context>
<context>
    <name>QDB2Driver</name>
    <message>
        <source>Unable to connect</source>
        <translation>Kunde inte ansluta</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Kunde inte rulla tillbaka transaktion</translation>
    </message>
    <message>
        <source>Unable to set autocommit</source>
        <translation>Kunde inte ställa in automatisk verkställning</translation>
    </message>
</context>
<context>
    <name>QDB2Result</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>Kunde inte köra villkor</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Kunde inte förbereda frågesats</translation>
    </message>
    <message>
        <source>Unable to bind variable</source>
        <translation>Kunde inte binda variabel</translation>
    </message>
    <message>
        <source>Unable to fetch record %1</source>
        <translation>Kunde inte hämta posten %1</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>Kunde inte hämta nästa</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>Kunde inte hämta första</translation>
    </message>
</context>
<context>
    <name>QDBusTrayIcon</name>
    <message>
        <source>OK</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>Vad är det här?</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <source>OK</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>QDnsLookup</name>
    <message>
        <source>Operation cancelled</source>
        <translation>Åtgärden avbröts</translation>
    </message>
    <message>
        <source>Invalid domain name</source>
        <translation>Ogiltigt domännamn</translation>
    </message>
    <message>
        <source>SSL/TLS support not present</source>
        <translation>SSL/TLS-stöd finns inte</translation>
    </message>
    <message>
        <source>Request timed out</source>
        <translation>Begäran gick över tidsgränsen</translation>
    </message>
    <message>
        <source>Server could not process query</source>
        <translation>Servern kunde inte behandla frågesats</translation>
    </message>
    <message>
        <source>Server failure</source>
        <translation>Serverfel</translation>
    </message>
    <message>
        <source>Non existent domain</source>
        <translation>Icke-existerande domän</translation>
    </message>
    <message>
        <source>Server refused to answer</source>
        <translation>Servern vägrade svara</translation>
    </message>
    <message>
        <source>Invalid reply received (rcode %1)</source>
        <translation>Ogiltigt svar togs emot (rcode %1)</translation>
    </message>
    <message>
        <source>Invalid reply received</source>
        <translation>Ogiltigt svar togs emot</translation>
    </message>
    <message>
        <source>Invalid reply received (%1)</source>
        <translation>Ogiltigt svar togs emot (%1)</translation>
    </message>
    <message>
        <source>IPv6 nameservers are currently not supported on this OS</source>
        <translation>IPv6-namnservrar stöds för närvarande inte av detta operativsystem</translation>
    </message>
    <message>
        <source>Reply was too large</source>
        <translation>Svaret var för stort</translation>
    </message>
    <message>
        <source>Could not expand domain name</source>
        <translation>Kunde inte expandera domännamn</translation>
    </message>
    <message>
        <source>Invalid IPv4 address record</source>
        <translation>Ogiltig IPv4-adresspost</translation>
    </message>
    <message>
        <source>Invalid IPv6 address record</source>
        <translation>Ogiltig IPv6-adresspost</translation>
    </message>
    <message>
        <source>Invalid canonical name record</source>
        <translation>Ogiltig kanonisk namnpost</translation>
    </message>
    <message>
        <source>Invalid name server record</source>
        <translation>Ogiltig namnserverpost</translation>
    </message>
    <message>
        <source>Invalid pointer record</source>
        <translation>Ogiltig pekarpost</translation>
    </message>
    <message>
        <source>Invalid mail exchange record</source>
        <translation>Ogiltig e-postserverpost</translation>
    </message>
    <message>
        <source>Invalid service record</source>
        <translation>Ogiltig tjänstepost</translation>
    </message>
    <message>
        <source>Invalid TLS association record</source>
        <translation>Ogiltig TLS-associeringspost</translation>
    </message>
    <message>
        <source>Invalid text record</source>
        <translation>Ogiltig textpost</translation>
    </message>
</context>
<context>
    <name>QDnsLookupRunnable</name>
    <message>
        <source>Not yet supported on this OS</source>
        <translation>Stöds ännu inte i detta operativsystem</translation>
    </message>
</context>
<context>
    <name>QDockWidget</name>
    <message>
        <source>Float</source>
        <extracomment>Accessible name for button undocking a dock widget (floating state)</extracomment>
        <translation>Flytande</translation>
    </message>
    <message>
        <source>Undocks and re-attaches the dock widget</source>
        <translation>Avdockar och återkopplar dockwidgeten</translation>
    </message>
    <message>
        <source>Close</source>
        <extracomment>Accessible name for button closing a dock widget</extracomment>
        <translation>Stäng</translation>
    </message>
    <message>
        <source>Closes the dock widget</source>
        <translation>Stänger dockwidgeten</translation>
    </message>
</context>
<context>
    <name>QDomParser</name>
    <message>
        <source>Error occurred while processing XML declaration</source>
        <translation>Fel inträffade under behandling av XML-deklaration</translation>
    </message>
    <message>
        <source>Multiple DTD sections are not allowed</source>
        <translation>Flera DTD-sektioner tillåts inte</translation>
    </message>
    <message>
        <source>Error occurred while processing document type declaration</source>
        <translation>Fel inträffade vid behandling av dokumenttypens deklaration</translation>
    </message>
    <message>
        <source>Error occurred while processing comment</source>
        <translation>Fel inträffade vid behandling av kommentar</translation>
    </message>
    <message>
        <source>Error occurred while processing a processing instruction</source>
        <translation>Fel inträffade vid behandling av en behandlande instruktion</translation>
    </message>
    <message>
        <source>Error occurred while processing a start element</source>
        <translation>Fel inträffade vid behandling av ett startelement</translation>
    </message>
    <message>
        <source>Unexpected end element &apos;%1&apos;</source>
        <translation>Oväntat slutelement &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Error occurred while processing an end element</source>
        <translation>Fel inträffade vid behandling av ett slutelement</translation>
    </message>
    <message>
        <source>Error occurred while processing the element content</source>
        <translation>Fel inträffade vid behandling av elementinnehållet</translation>
    </message>
    <message>
        <source>Error occurred while processing comments</source>
        <translation>Fel inträffade vid behandling av kommentarer</translation>
    </message>
    <message>
        <source>Error occurred while processing an entity reference</source>
        <translation>Fel inträffade vid behandling av en entitetsreferens</translation>
    </message>
    <message>
        <source>Unexpected token</source>
        <translation>Oväntad token</translation>
    </message>
    <message>
        <source>Tag mismatch</source>
        <translation>Tagg stämmer inte överens</translation>
    </message>
    <message>
        <source>Error occurred while processing entity declaration</source>
        <translation>Fel inträffade vid behandling av entitetsdeklaration</translation>
    </message>
    <message>
        <source>Error occurred while processing notation declaration</source>
        <translation>Fel inträffade vid behandling av notationsdeklaration</translation>
    </message>
</context>
<context>
    <name>QDtls</name>
    <message>
        <source>Multicast and broadcast addresses are not supported</source>
        <translation>Multicast och broadcast-adresser stöds inte</translation>
    </message>
    <message>
        <source>Cannot set peer after handshake started</source>
        <translation>Kan inte ställa in motpart efter handskakning startats</translation>
    </message>
    <message>
        <source>Invalid address</source>
        <translation>Ogiltig adress</translation>
    </message>
    <message>
        <source>Cannot set verification name after handshake started</source>
        <translation>Kan inte ställa in verifieringsnamn efter att handskakning startats</translation>
    </message>
    <message>
        <source>Cannot set configuration after handshake started</source>
        <translation>Kan inte ställa in konfiguration efter att handskakning startats</translation>
    </message>
    <message>
        <source>Cannot start/continue handshake, invalid handshake state</source>
        <translation>Kan inte starta/fortsätta handskakning, ogiltigt handshake-tillstånd</translation>
    </message>
    <message>
        <source>Invalid (nullptr) socket</source>
        <translation>Ogiltigt uttag (nullptr)</translation>
    </message>
    <message>
        <source>To start a handshake you must set peer&apos;s address and port first</source>
        <translation>Du måste ange motpartens adress och port först för att starta en handskakning</translation>
    </message>
    <message>
        <source>To start a handshake, DTLS server requires non-empty datagram (client hello)</source>
        <translation>DTLS-servern kräver icke-tomt datagram (client hello) för att starta en handskakning</translation>
    </message>
    <message>
        <source>Cannot start handshake, already done/in progress</source>
        <translation>Kan inte starta handskakning, redan gjort/pågår</translation>
    </message>
    <message>
        <source>A valid QUdpSocket and non-empty datagram are needed to continue the handshake</source>
        <translation>En giltig QUdpSocket och icke-tomt datagram krävs för att fortsätta handskakningen</translation>
    </message>
    <message>
        <source>Cannot continue handshake, not in InProgress state</source>
        <translation>Kan inte fortsätta handskakning, inte i InProgress-tillstånd</translation>
    </message>
    <message>
        <source>Cannot resume, not in VerificationError state</source>
        <translation>Kan inte återuppta, inte i VerificationError-tillstånd</translation>
    </message>
    <message>
        <source>No handshake in progress, nothing to abort</source>
        <translation>Ingen handskakning pågår, ingenting att avbryta</translation>
    </message>
    <message>
        <source>Cannot send shutdown alert, not encrypted</source>
        <translation>Kan inte skicka nerstängningsvarning, inte krypterad</translation>
    </message>
    <message>
        <source>Cannot write a datagram, not in encrypted state</source>
        <translation>Kan inte skriva ett datagram, inte i encrypted-tillstånd</translation>
    </message>
    <message>
        <source>Cannot read a datagram, not in encrypted state</source>
        <translation>Kan inte läsa ett datagram, inte i encrypted-tillstånd</translation>
    </message>
    <message>
        <source>%1 failed</source>
        <extracomment>%1: Some function</extracomment>
        <translation>%1 misslyckades</translation>
    </message>
    <message>
        <source>Invalid SslMode, SslServerMode or SslClientMode expected</source>
        <translation>Ogiltigt SslMode, SslServerMode eller SslClientMode förväntades</translation>
    </message>
    <message>
        <source>Invalid protocol version, DTLS protocol expected</source>
        <translation>Ogiltig protokollversion, DTLS-protokollet förväntades</translation>
    </message>
    <message>
        <source>BIO_ADD_new failed, cannot start handshake</source>
        <translation>BIO_ADD_new misslyckades, kan inte starta handskakning</translation>
    </message>
    <message>
        <source>Cannot start the handshake, verified client hello expected</source>
        <translation>Kan inte starta handskakningen, verifierad client hello förväntades</translation>
    </message>
    <message>
        <source>Peer verification failed</source>
        <translation>Verifiering av motpart misslyckades</translation>
    </message>
    <message>
        <source>The DTLS connection has been closed</source>
        <translation>DTLS-anslutningen har stängts</translation>
    </message>
    <message>
        <source>Error while writing: %1</source>
        <translation>Fel vid skrivning: %1</translation>
    </message>
    <message>
        <source>The DTLS connection has been shutdown</source>
        <translation>DTLS-anslutningen har stängts ner</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Fel vid läsning: %1</translation>
    </message>
    <message>
        <source>Invalid (empty) secret</source>
        <translation>Ogiltig hemlighet (empty)</translation>
    </message>
</context>
<context>
    <name>QDtlsClientVerifier</name>
    <message>
        <source>A valid UDP socket, non-empty datagram, and valid address/port were expected</source>
        <translation>Ett giltigt UDP-uttag, icke-tomt datagram och giltig adress/port förväntades</translation>
    </message>
    <message>
        <source>BIO_ADDR_new failed, ignoring client hello</source>
        <translation>BIO_ADDR_new misslyckades, ignorerar client hello</translation>
    </message>
</context>
<context>
    <name>QErrorMessage</name>
    <message>
        <source>An error occurred</source>
        <translation>Ett fel inträffade</translation>
    </message>
    <message>
        <source>Debug Message:</source>
        <translation>Felsökningsmeddelande:</translation>
    </message>
    <message>
        <source>Warning:</source>
        <translation>Varning:</translation>
    </message>
    <message>
        <source>Critical Error:</source>
        <translation>Kritiskt fel:</translation>
    </message>
    <message>
        <source>Fatal Error:</source>
        <translation>Ödesdigert fel:</translation>
    </message>
    <message>
        <source>Information:</source>
        <translation>Information:</translation>
    </message>
    <message>
        <source>&amp;Show this message again</source>
        <translation>&amp;Visa detta meddelande igen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Ok</translation>
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <source>Destination file is the same file.</source>
        <translation>Målfilen är samma fil.</translation>
    </message>
    <message>
        <source>Source file does not exist.</source>
        <translation>Källfilen finns inte.</translation>
    </message>
    <message>
        <source>Destination file exists</source>
        <translation>Målfilen finns redan</translation>
    </message>
    <message>
        <source>Error while renaming: %1</source>
        <translation>Fel vid namnbyte: %1</translation>
    </message>
    <message>
        <source>Unable to restore from %1: %2</source>
        <translation>Kunde inte återskapa från %1: %2</translation>
    </message>
    <message>
        <source>Will not rename sequential file using block copy</source>
        <translation>Kommer inte byta namn på sekvensfil med blockkopiering</translation>
    </message>
    <message>
        <source>Cannot remove source file: %1</source>
        <translation>Kan inte ta bort källfilen: %1</translation>
    </message>
</context>
<context>
    <name>QFileDevice</name>
    <message>
        <source>No file engine available or engine does not support UnMapExtension</source>
        <translation>Ingen filmotor tillgänglig eller motorn saknar stöd för UnMapExtension</translation>
    </message>
    <message>
        <source>No file engine available</source>
        <translation>Ingen filmotor tillgänglig</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Back</source>
        <translation>Bakåt</translation>
    </message>
    <message>
        <source>Go back</source>
        <translation>Gå bakåt</translation>
    </message>
    <message>
        <source>Alt+Left</source>
        <translation>Alt+vänster</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Framåt</translation>
    </message>
    <message>
        <source>Go forward</source>
        <translation>Gå framåt</translation>
    </message>
    <message>
        <source>Alt+Right</source>
        <translation>Alt+höger</translation>
    </message>
    <message>
        <source>Parent Directory</source>
        <translation>Föräldrakatalog</translation>
    </message>
    <message>
        <source>Go to the parent directory</source>
        <translation>Gå till överliggande katalog</translation>
    </message>
    <message>
        <source>Alt+Up</source>
        <translation>Alt+upp</translation>
    </message>
    <message>
        <source>Create New Folder</source>
        <translation>Skapa ny mapp</translation>
    </message>
    <message>
        <source>Create a New Folder</source>
        <translation>Skapa en ny mapp</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>Listvy</translation>
    </message>
    <message>
        <source>Change to list view mode</source>
        <translation>Byt till listvyläget</translation>
    </message>
    <message>
        <source>Detail View</source>
        <translation>Detaljerad vy</translation>
    </message>
    <message>
        <source>Change to detail view mode</source>
        <translation>Byt till detaljerat vyläge</translation>
    </message>
    <message>
        <source>Sidebar</source>
        <translation>Sidorad</translation>
    </message>
    <message>
        <source>List of places and bookmarks</source>
        <translation>Lista över platser och bokmärken</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Filer</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Alla filer (*)</translation>
    </message>
    <message>
        <source>Find Directory</source>
        <translation>Hitta katalog</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>Spara som</translation>
    </message>
    <message>
        <source>Directory:</source>
        <translation>Katalog:</translation>
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation>Fil&amp;namn:</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Öppna</translation>
    </message>
    <message>
        <source>&amp;Choose</source>
        <translation>&amp;Välj</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Spara</translation>
    </message>
    <message>
        <source>Show </source>
        <translation>Visa </translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation>&amp;Byt namn</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Ta bort</translation>
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation>Visa &amp;dolda filer</translation>
    </message>
    <message>
        <source>&amp;New Folder</source>
        <translation>&amp;Ny mapp</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation>Alla filer (*)</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Kataloger</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 finns redan.
Vill du ersätta den?</translation>
    </message>
    <message>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1
Katalogen hittades inte.
Kontrollera att det korrekta katalognamnet angavs.</translation>
    </message>
    <message>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1
Filen hittades inte.
Kontrollera att det korrekta filnamnet angavs.</translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation>Ny mapp</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>\&quot;%1\&quot; är skrivskyddad.
Vill du ta bort den ändå?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete &apos;%1&apos;?</source>
        <translation>Är du säker på att du vill ta bort \&quot;%1\&quot;?</translation>
    </message>
    <message>
        <source>Could not delete directory.</source>
        <translation>Kunde inte ta bort katalogen.</translation>
    </message>
    <message>
        <source>Recent Places</source>
        <translation>Tidigare platser</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>&amp;Look in:</source>
        <translation>&amp;Titta i:</translation>
    </message>
    <message>
        <source>Files of &amp;type:</source>
        <translation>Filer av &amp;typ:</translation>
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Datum ändrad</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>Min dator</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Dator</translation>
    </message>
</context>
<context>
    <name>QFontDatabase</name>
    <message>
        <source>Normal</source>
        <comment>The Normal or Regular font weight</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Fet stil</translation>
    </message>
    <message>
        <source>Demi Bold</source>
        <translation>Demi-fet</translation>
    </message>
    <message>
        <source>Medium</source>
        <comment>The Medium font weight</comment>
        <translation>Medium</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Svart</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Ljus</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>Tunn</translation>
    </message>
    <message>
        <source>Extra Light</source>
        <translation>Extraljus</translation>
    </message>
    <message>
        <source>Extra Bold</source>
        <translation>Extrafet stil</translation>
    </message>
    <message>
        <source>Extra</source>
        <extracomment>The word for &quot;Extra&quot; as in &quot;Extra Bold, Extra Thin&quot; used as a pattern for string searches</extracomment>
        <translation>Extra</translation>
    </message>
    <message>
        <source>Demi</source>
        <extracomment>The word for &quot;Demi&quot; as in &quot;Demi Bold&quot; used as a pattern for string searches</extracomment>
        <translation>Demi</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Kursiv</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Sned</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Valfri</translation>
    </message>
    <message>
        <source>Latin</source>
        <translation>Latin</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Grekiska</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Kyrilliska</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation>Armeniska</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation>Hebreiska</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabiska</translation>
    </message>
    <message>
        <source>Syriac</source>
        <translation>Syriska</translation>
    </message>
    <message>
        <source>Thaana</source>
        <translation>Tāna</translation>
    </message>
    <message>
        <source>Devanagari</source>
        <translation>Devanāgarī</translation>
    </message>
    <message>
        <source>Bengali</source>
        <translation>Bengaliska</translation>
    </message>
    <message>
        <source>Gurmukhi</source>
        <translation>Gurmukhi</translation>
    </message>
    <message>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <source>Tamil</source>
        <translation>Tamil</translation>
    </message>
    <message>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <source>Sinhala</source>
        <translation>Sinhala</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation>Thai</translation>
    </message>
    <message>
        <source>Lao</source>
        <translation>Laotiska</translation>
    </message>
    <message>
        <source>Tibetan</source>
        <translation>Tibetanska</translation>
    </message>
    <message>
        <source>Myanmar</source>
        <translation>Burmesiska</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiska</translation>
    </message>
    <message>
        <source>Khmer</source>
        <translation>Khmer</translation>
    </message>
    <message>
        <source>Simplified Chinese</source>
        <translation>Förenklad kinesiska</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Traditionell kinesiska</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japanska</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation>Koreanska</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation>Vietnamesiska</translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation>Symbolspråk</translation>
    </message>
    <message>
        <source>Ogham</source>
        <translation>Ogham</translation>
    </message>
    <message>
        <source>Runic</source>
        <translation>Runsvenska</translation>
    </message>
    <message>
        <source>N&apos;Ko</source>
        <translation>N&apos;Ko</translation>
    </message>
</context>
<context>
    <name>QFontDialog</name>
    <message>
        <source>Select Font</source>
        <translation>Välj typsnitt</translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation>&amp;Typsnitt</translation>
    </message>
    <message>
        <source>Font st&amp;yle</source>
        <translation>T&amp;ypsnittsstil</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Storlek</translation>
    </message>
    <message>
        <source>Effects</source>
        <translation>Effekter</translation>
    </message>
    <message>
        <source>Stri&amp;keout</source>
        <translation>Genomstru&amp;ken</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>&amp;Understruken</translation>
    </message>
    <message>
        <source>Sample</source>
        <translation>Test</translation>
    </message>
    <message>
        <source>Wr&amp;iting System</source>
        <translation>Skr&amp;ivsystem</translation>
    </message>
</context>
<context>
    <name>QGnomeTheme</name>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Spara</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Avbryt</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>S&amp;täng</translation>
    </message>
    <message>
        <source>Close without Saving</source>
        <translation>Stäng utan att spara</translation>
    </message>
</context>
<context>
    <name>QGuiApplication</name>
    <message>
        <source>QT_LAYOUT_DIRECTION</source>
        <comment>Translate this string to the string &apos;LTR&apos; in left-to-right languages or to &apos;RTL&apos; in right-to-left languages (such as Hebrew and Arabic) to get proper widget layout.</comment>
        <translation>LTR</translation>
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <source>No host name given</source>
        <translation>Inget värdnamn angivet</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <source>No host name given</source>
        <translation>Inget värdnamn angivet</translation>
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation>Ogiltigt värdnamn</translation>
    </message>
    <message>
        <source>Unknown address type</source>
        <translation>Okänd adresstyp</translation>
    </message>
    <message>
        <source>Host not found</source>
        <translation>Värden hittades inte</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>Unsupported content encoding: %1</source>
        <translation>Oväntad innehållsenkodning: %1</translation>
    </message>
    <message>
        <source>Failed to initialize the compression decoder.</source>
        <translation>Misslyckades med att initiera komprimeringsdekodern.</translation>
    </message>
    <message>
        <source>The decompressed output exceeds the limits specified by QNetworkRequest::decompressedSafetyCheckThreshold()</source>
        <translation>Dekomprimerat utdata överstiger gränserna som angivets av QNetworkRequest::decompressedSafetyCheckThreshold()</translation>
    </message>
    <message>
        <source>Brotli error: %1</source>
        <extracomment>Brotli (compression algorithm) decoding error, e.g. corrupted input or memory allocation problem.</extracomment>
        <translation>Brotli-fel: %1</translation>
    </message>
    <message>
        <source>ZStandard error: %1</source>
        <translation>ZStandard-fel: %1</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>Anslutningen stängd</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation>Värden %1 hittades inte</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Anslutningen nekades</translation>
    </message>
    <message>
        <source>Proxy requires authentication</source>
        <translation>Proxy kräver autentisering</translation>
    </message>
    <message>
        <source>Host requires authentication</source>
        <translation>Värden kräver autentisering</translation>
    </message>
    <message>
        <source>Data corrupted</source>
        <translation>Data är skadat</translation>
    </message>
    <message>
        <source>Unknown protocol specified</source>
        <translation>Okänt protokoll angivet</translation>
    </message>
    <message>
        <source>SSL handshake failed</source>
        <translation>SSL-handskakningsfel</translation>
    </message>
    <message>
        <source>Too many redirects</source>
        <translation>För många omdirigeringar</translation>
    </message>
    <message>
        <source>Insecure redirect</source>
        <translation>Osäker omdirigering</translation>
    </message>
    <message>
        <source>Decompression failed: %1</source>
        <translation>Dekomprimering misslyckades: %1</translation>
    </message>
    <message>
        <source>Data downloaded is too large to store</source>
        <translation>Data hämtat är för stort att lagra</translation>
    </message>
    <message>
        <source>Failed to initialize decompression: %1</source>
        <translation>Misslyckades med att initiera dekomprimering: %1</translation>
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <source>Did not receive HTTP response from proxy</source>
        <translation>Tog inte emot något HTTP-svar från proxyn</translation>
    </message>
    <message>
        <source>Error parsing authentication request from proxy</source>
        <translation>Fel vid tolkning av autentiseringsbegäran från proxy</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation>Autentisering krävs</translation>
    </message>
    <message>
        <source>Proxy denied connection</source>
        <translation>Proxyn nekade anslutningen</translation>
    </message>
    <message>
        <source>Error communicating with HTTP proxy</source>
        <translation>Fel vid kommunicering med HTTP-proxy</translation>
    </message>
    <message>
        <source>Proxy server not found</source>
        <translation>Proxyservern hittades inte</translation>
    </message>
    <message>
        <source>Proxy connection refused</source>
        <translation>Proxyanslutningen vägrades</translation>
    </message>
    <message>
        <source>Proxy server connection timed out</source>
        <translation>Anslutningen till proxyservern gick över tidsgränsen</translation>
    </message>
    <message>
        <source>Proxy connection closed prematurely</source>
        <translation>Proxyanslutningen stängdes i förtid</translation>
    </message>
</context>
<context>
    <name>QIBaseDriver</name>
    <message>
        <source>Error opening database</source>
        <translation>Fel vid öppnade av databas</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>Kunde inte starta transaktion</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Kunde inte rulla tillbaka transaktion</translation>
    </message>
    <message>
        <source>Could not subscribe to event notifications for %1.</source>
        <translation>Kunde inte prenumerera på händelseaviseringar för %1.</translation>
    </message>
    <message>
        <source>Could not unsubscribe from event notifications for %1.</source>
        <translation>Kunde inte avprenumerera från händelseaviseringar för %1.</translation>
    </message>
</context>
<context>
    <name>QIBaseResult</name>
    <message>
        <source>Unable to create BLOB</source>
        <translation>Kunde inte skapa BLOB</translation>
    </message>
    <message>
        <source>Unable to write BLOB</source>
        <translation>Kunde inte skriva BLOB</translation>
    </message>
    <message>
        <source>Unable to open BLOB</source>
        <translation>Kunde inte öppna BLOB</translation>
    </message>
    <message>
        <source>Unable to read BLOB</source>
        <translation>Kunde inte läsa BLOB</translation>
    </message>
    <message>
        <source>Could not find array</source>
        <translation>Kunde inte hitta kedja</translation>
    </message>
    <message>
        <source>Could not get array data</source>
        <translation>Kunde inte få kedjedata</translation>
    </message>
    <message>
        <source>Array size mismatch. Field name: %3, expected size: %1. Supplied size: %2</source>
        <translation>Kedjestorleken stämmer inte. Fältnamn: %3, förväntad storlek: %1. Levererad storlek: %2</translation>
    </message>
    <message>
        <source>Array dimensions mismatch. Field name: %1</source>
        <translation>Kedjans dimensioner stämmer inte. Fältnamn: %1</translation>
    </message>
    <message>
        <source>Array size mismatch: size of %1 is %2, size of provided list is %3</source>
        <translation>Kedjans storlek stämmer inte: storlek för %1 är %2, storlek för tillhandahållen lista är %3</translation>
    </message>
    <message>
        <source>Could not get query info</source>
        <translation>Kunde inte gå frågesatsinformation</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>Kunde inte starta transaktion</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Could not allocate statement</source>
        <translation>Kunde inte allokera frågesats</translation>
    </message>
    <message>
        <source>Could not prepare statement</source>
        <translation>Kunde inte förbereda frågesats</translation>
    </message>
    <message>
        <source>Could not describe input statement</source>
        <translation>Kunde inte beskriva inmatningsfrågesats</translation>
    </message>
    <message>
        <source>Could not describe statement</source>
        <translation>Kunde inte beskriva frågesats</translation>
    </message>
    <message>
        <source>Unable to close statement</source>
        <translation>Kunde inte stänga frågesats</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>Kunde inte köra frågesats</translation>
    </message>
    <message>
        <source>Could not fetch next item</source>
        <translation>Kunde inte hämta nästa post</translation>
    </message>
    <message>
        <source>Could not get statement info</source>
        <translation>Kunde inte få frågesatsinformation</translation>
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <source>file to open is a directory</source>
        <translation>filen som ska öppnas är en katalog</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Åtkomst nekad</translation>
    </message>
    <message>
        <source>Too many open files</source>
        <translation>För många öppna filer</translation>
    </message>
    <message>
        <source>No such file or directory</source>
        <translation>Ingen sådan fil eller katalog</translation>
    </message>
    <message>
        <source>No space left on device</source>
        <translation>Inget ledigt utrymme på enheten</translation>
    </message>
</context>
<context>
    <name>QImageReader</name>
    <message>
        <source>Invalid device</source>
        <translation>Ogiltig enhet</translation>
    </message>
    <message>
        <source>File not found</source>
        <translation>Filen hittades inte</translation>
    </message>
    <message>
        <source>Unsupported image format</source>
        <translation>Bildformatet stöds inte</translation>
    </message>
    <message>
        <source>Unable to read image data</source>
        <translation>Kunde inte läsa bilddata</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
</context>
<context>
    <name>QImageWriter</name>
    <message>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
    <message>
        <source>Device is not set</source>
        <translation>Enheten är inte inställd</translation>
    </message>
    <message>
        <source>Cannot open device for writing: %1</source>
        <translation>Kan inte öppna enhet för skrivning: %1</translation>
    </message>
    <message>
        <source>Device not writable</source>
        <translation>Enheten är inte skrivbar</translation>
    </message>
    <message>
        <source>Unsupported image format</source>
        <translation>Bildformatet stöds inte</translation>
    </message>
    <message>
        <source>Image is empty</source>
        <translation>Bilden är tom</translation>
    </message>
</context>
<context>
    <name>QInputDialog</name>
    <message>
        <source>Enter a value:</source>
        <translation>Ange ett värde:</translation>
    </message>
</context>
<context>
    <name>QJsonParseError</name>
    <message>
        <source>no error occurred</source>
        <translation>inga fel inträffade</translation>
    </message>
    <message>
        <source>unterminated object</source>
        <translation>oavslutat objekt</translation>
    </message>
    <message>
        <source>missing name separator</source>
        <translation>saknar namnavgränsare</translation>
    </message>
    <message>
        <source>unterminated array</source>
        <translation>oavslutad kedja</translation>
    </message>
    <message>
        <source>missing value separator</source>
        <translation>saknar värdesavgränsare</translation>
    </message>
    <message>
        <source>illegal value</source>
        <translation>ogiltigt värde</translation>
    </message>
    <message>
        <source>invalid termination by number</source>
        <translation>ogiltig avslutning med siffra</translation>
    </message>
    <message>
        <source>illegal number</source>
        <translation>ogiltig siffra</translation>
    </message>
    <message>
        <source>invalid escape sequence</source>
        <translation>ogiltig escape sequence</translation>
    </message>
    <message>
        <source>invalid UTF8 string</source>
        <translation>ogiltig UTF8-sträng</translation>
    </message>
    <message>
        <source>unterminated string</source>
        <translation>oavslutad sträng</translation>
    </message>
    <message>
        <source>object is missing after a comma</source>
        <translation>objekt saknas efter ett komma</translation>
    </message>
    <message>
        <source>too deeply nested document</source>
        <translation>för djupt nästlat dokument</translation>
    </message>
    <message>
        <source>too large document</source>
        <translation>för stort dokument</translation>
    </message>
    <message>
        <source>garbage at the end of the document</source>
        <translation>skräp på slutet av dokumentet</translation>
    </message>
</context>
<context>
    <name>QKeySequenceEdit</name>
    <message>
        <source>Press shortcut</source>
        <translation>Tryck genväg</translation>
    </message>
    <message>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation>%1, ...</translation>
    </message>
</context>
<context>
    <name>QLibrary</name>
    <message>
        <source>&apos;%1&apos; is not a valid Windows DLL (%2)</source>
        <translation>&apos;%1&apos;är inte en giltig Windows DLL (%2)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is too small</source>
        <translation>&apos;%1&apos; är för liten</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a Qt plugin (%2)</source>
        <translation>&apos;%1&apos; är inte ett Qt-instick (%2)</translation>
    </message>
    <message>
        <source>metadata not found</source>
        <translation>metadata hittades inte</translation>
    </message>
    <message>
        <source>invalid signature</source>
        <translation>ogiltig signatur</translation>
    </message>
    <message>
        <source>file is for a different processor</source>
        <translation>filen är för en annan processor</translation>
    </message>
    <message>
        <source>file has no sections</source>
        <translation>filen har inga sektioner</translation>
    </message>
    <message>
        <source>wrong characteristics</source>
        <translation>felaktiga egenskaper</translation>
    </message>
    <message>
        <source>file is for a different word size</source>
        <translation>filen är för en annan word-storlek</translation>
    </message>
    <message>
        <source>file has no code</source>
        <translation>filen är ingen kod</translation>
    </message>
    <message>
        <source>a section name is empty or extends past the end of the file</source>
        <translation>ett sektionsnamn är tomt eller överstiger filslutet</translation>
    </message>
    <message>
        <source>section contents extend past the end of the file</source>
        <translation>sektionsinnehållet överstiger filslutet</translation>
    </message>
    <message>
        <source>.qtmetadata section is too small</source>
        <translation>.qtmetadata-sektionen är för liten</translation>
    </message>
    <message>
        <source>.qtmetadata section has incorrect magic</source>
        <translation>.qtmetadata-sektionen har felaktig magic</translation>
    </message>
    <message>
        <source>.qtmetadata section is writable</source>
        <translation>.qtmetadata-sektionen är skrivbar</translation>
    </message>
    <message>
        <source>.qtmetadata section is executable</source>
        <translation>.qtmetadata-sektionen är körbar</translation>
    </message>
    <message>
        <source>file is for the wrong endianness</source>
        <translation>filen är för fel byteordning</translation>
    </message>
    <message>
        <source>file has an unknown ELF version</source>
        <translation>filen har en okänd ELF-version</translation>
    </message>
    <message>
        <source>file has an unexpected ABI</source>
        <translation>filen har en oväntad ABI</translation>
    </message>
    <message>
        <source>file is not a shared object</source>
        <translation>filen är inte ett delat objekt</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid ELF object (%2)</source>
        <translation>&apos;%1&apos; är inte ett giltigt ELF-objekt (%2)</translation>
    </message>
    <message>
        <source>unimplemented: PN_XNUM program headers</source>
        <translation>inte implementerat: PN_XNUM-programrubriker</translation>
    </message>
    <message>
        <source>program header table extends past the end of the file</source>
        <translation>programrubrikstabell sträcker sig över filens slut</translation>
    </message>
    <message>
        <source>a program header entry extends past the end of the file</source>
        <translation>en programrubrikspost sträcker sig över slutet på filen</translation>
    </message>
    <message>
        <source>a note segment start is not properly aligned (offset 0x%1, alignment %2)</source>
        <translation>en note-segmentstart är inte korrekt justerad (offset 0x%1, justering %2)</translation>
    </message>
    <message>
        <source>section table extends past the end of the file</source>
        <translation>sektionstabellen överstiger filslutet</translation>
    </message>
    <message>
        <source>section header string table extends past the end of the file</source>
        <translation>strängtabell för sektionshuvud sträcker sig över filens slut</translation>
    </message>
    <message>
        <source>a section name extends past the end of the file</source>
        <translation>ett sektionsnamn överstiger filslutet</translation>
    </message>
    <message>
        <source>file too small</source>
        <translation>filen är för liten</translation>
    </message>
    <message>
        <source>unexpected program header entry size (%1)</source>
        <translation>oväntad storlek för programrubrikpost (%1)</translation>
    </message>
    <message>
        <source>unexpected section entry size (%1)</source>
        <translation>oväntad storlek för sektionspost (%1)</translation>
    </message>
    <message>
        <source>e_shstrndx greater than the number of sections e_shnum (%1 &gt;= %2)</source>
        <translation>e_shstrndx större än antalet sektioner e_shnum (%1 &gt;= %2)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a Qt plugin</source>
        <translation>&apos;%1&apos; är inte en Qt-insticksmodul</translation>
    </message>
    <message>
        <source>Failed to extract plugin meta data from &apos;%1&apos;: %2</source>
        <translation>Misslyckades med att extrahera metadata för insticksmodul från &quot;%1&quot;: %2</translation>
    </message>
    <message>
        <source>The shared library was not found.</source>
        <translation>Delade biblioteket hittades inte.</translation>
    </message>
    <message>
        <source>Could not resolve &apos;qt_plugin_instance&apos; function</source>
        <translation>Kunde inte slå upp funktionen &apos;qt_plugin_instance&apos;</translation>
    </message>
    <message>
        <source>metadata too small</source>
        <translation>metadata för litet</translation>
    </message>
    <message>
        <source>entrypoint to query the plugin meta data not found</source>
        <translation>ingångspunkt för fråga efter insticksmodulens metadata hittades inte</translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is not a valid Qt plugin.</source>
        <translation>Filen &apos;%1&apos; är inte en giltig Qt-insticksmodul.</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (%2.%3.%4) [%5]</source>
        <translation>Insticksmodulen &apos;%1&apos; använder inkompatibelt Qt-bibliotek. (%2.%3.%4) [%5]</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (Cannot mix debug and release libraries.)</source>
        <translation>Insticksmodulen &apos;%1&apos; använder inkompatibelt Qt-bibliotek. (Kan inte blanda bibliotek för debug och release.)</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
    <message>
        <source>Cannot load library %1: %2</source>
        <translation>Kan inte läsa in biblioteket %1: %2</translation>
    </message>
    <message>
        <source>Cannot unload library %1: %2</source>
        <translation>Kan inte läsa ur biblioteket %1: %2</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid Mach-O binary (%2)</source>
        <translation>&apos;%1&apos; är inte en giltig Mach-O-binär (%2)</translation>
    </message>
    <message>
        <source>file is corrupt</source>
        <translation>filen är skadad</translation>
    </message>
    <message>
        <source>no suitable architecture in fat binary</source>
        <translation>ingen passande arkitektur i fet binär</translation>
    </message>
    <message>
        <source>invalid magic %1</source>
        <translation>ogiltig magic %1</translation>
    </message>
    <message>
        <source>wrong architecture</source>
        <translation>fel arkitektur</translation>
    </message>
    <message>
        <source>not a dynamic library</source>
        <translation>inte ett dynamiskt bibliotek</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Ångra</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Gör om</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Klipp &amp;ut</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiera</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>Klistra &amp;in</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
</context>
<context>
    <name>QLocalServer</name>
    <message>
        <source>%1: Name error</source>
        <translation>%1: Namnfel</translation>
    </message>
    <message>
        <source>%1: Permission denied</source>
        <translation>%1: Behörighet nekad</translation>
    </message>
    <message>
        <source>%1: Address in use</source>
        <translation>%1: Adressen används</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Okänt fel %2</translation>
    </message>
</context>
<context>
    <name>QLocalSocket</name>
    <message>
        <source>%1: Connection refused</source>
        <translation>%1: Anslutningen nekades</translation>
    </message>
    <message>
        <source>%1: Remote closed</source>
        <translation>%1: Fjärr stängde</translation>
    </message>
    <message>
        <source>%1: Invalid name</source>
        <translation>%1: Ogiltig namn</translation>
    </message>
    <message>
        <source>%1: Socket access error</source>
        <translation>%1: Fel vid uttagsåtkomst</translation>
    </message>
    <message>
        <source>%1: Socket resource error</source>
        <translation>%1: Fel i uttagsresurs</translation>
    </message>
    <message>
        <source>%1: Socket operation timed out</source>
        <translation>%1: Uttagsåtgärden översteg tidsgräns</translation>
    </message>
    <message>
        <source>%1: Datagram too large</source>
        <translation>%1: Datagram för stort</translation>
    </message>
    <message>
        <source>%1: Connection error</source>
        <translation>%1: Anslutningsfel</translation>
    </message>
    <message>
        <source>%1: The socket operation is not supported</source>
        <translation>%1: Uttagsåtgärden stöds inte</translation>
    </message>
    <message>
        <source>%1: Operation not permitted when socket is in this state</source>
        <translation>%1: Åtgärden tilläts inte när uttaget är i detta tillstånd</translation>
    </message>
    <message>
        <source>%1: Unknown error</source>
        <translation>%1: Okänt fel</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>Försöker ansluta när en anslutning pågår</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Okänt fel %2</translation>
    </message>
    <message>
        <source>%1: Access denied</source>
        <translation>%1: Åtkomst nekad</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>Uttaget är inte anslutet</translation>
    </message>
    <message>
        <source>Remote closed</source>
        <translation>Fjärr stängde</translation>
    </message>
</context>
<context>
    <name>QMYSQLDriver</name>
    <message>
        <source>Unable to allocate a MYSQL object</source>
        <translation>Kunde inte allokera ett MYSQL-objekt</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Kunde inte ansluta</translation>
    </message>
    <message>
        <source>Unable to open database &apos;%1&apos;</source>
        <translation>Kunde inte öppna databasen &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Kunde inte påbörja transaktion</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Kunde inte rulla tillbaka transaktion</translation>
    </message>
</context>
<context>
    <name>QMYSQLResult</name>
    <message>
        <source>Unable to fetch data</source>
        <translation>Kunde inte hämta data</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>Kunde inte köra frågesats</translation>
    </message>
    <message>
        <source>Unable to store result</source>
        <translation>Kunde inte lagra resultat</translation>
    </message>
    <message>
        <source>Unable to execute next query</source>
        <translation>Kunde inte köra nästa frågesats</translation>
    </message>
    <message>
        <source>Unable to store next result</source>
        <translation>Kunde inte lagra nästa resultat</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Kunde inte förbereda frågesats</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>Kunde inte återställa frågesats</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>Kunde inte binda värde</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Kunde inte köra frågesats</translation>
    </message>
    <message>
        <source>Unable to bind outvalues</source>
        <translation>Kunde inte binda utvärden</translation>
    </message>
    <message>
        <source>Unable to store statement results</source>
        <translation>Kunde inte lagra resultat från frågesats</translation>
    </message>
</context>
<context>
    <name>QMdiArea</name>
    <message>
        <source>(Untitled)</source>
        <translation>(Namnlös)</translation>
    </message>
</context>
<context>
    <name>QMdiSubWindow</name>
    <message>
        <source>- [%1]</source>
        <translation>- [%1]</translation>
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimera</translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation>Maximera</translation>
    </message>
    <message>
        <source>Unshade</source>
        <translation>Avskugga</translation>
    </message>
    <message>
        <source>Shade</source>
        <translation>Skugga</translation>
    </message>
    <message>
        <source>Restore Down</source>
        <translation>Återställ nedåt</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Återställ</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>Åte&amp;rställ</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Flytta</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Storlek</translation>
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation>Mi&amp;nimera</translation>
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ximera</translation>
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation>Stanna kvar övers&amp;t</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>S&amp;täng</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Show Details...</source>
        <translation>Visa detaljer...</translation>
    </message>
    <message>
        <source>Hide Details...</source>
        <translation>Dölj detaljer...</translation>
    </message>
    <message>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;&lt;p&gt;This program uses Qt version %1.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Om Qt&lt;/h3&gt;&lt;p&gt;Detta program använder Qt version %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under multiple licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of GNU (L)GPL.&lt;/p&gt;&lt;p&gt;Qt licensed under GNU (L)GPL is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the respective licenses.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;https://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) The Qt Company Ltd. and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd. product developed as an open source project. See &lt;a href=&quot;https://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <extracomment>Leave this text untranslated or include a verbatim copy of it below and note that it is the authoritative version in case of doubt.</extracomment>
        <translation>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under multiple licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of GNU (L)GPL.&lt;/p&gt;&lt;p&gt;Qt licensed under GNU (L)GPL is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the respective licenses.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;https://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) The Qt Company Ltd. and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd. product developed as an open source project. See &lt;a href=&quot;https://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Om Qt</translation>
    </message>
</context>
<context>
    <name>QMimerSQL</name>
    <message>
        <source>No Mimer SQL error for code %1</source>
        <translation>Inget Mimer SQL-fel för kod %1</translation>
    </message>
    <message>
        <source>Generic Mimer SQL error</source>
        <translation>Allmänt Mimer SQL-fel</translation>
    </message>
</context>
<context>
    <name>QMimerSQLDriver</name>
    <message>
        <source>Could not connect to database</source>
        <translation>Kunde inte ansluta till databasen</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>Kunde inte starta transaktion</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Could not roll back transaction</source>
        <translation>Kunde inte rulla tillbaka transaktion</translation>
    </message>
</context>
<context>
    <name>QMimerSQLResult</name>
    <message>
        <source>Could not get %1, column %2</source>
        <extracomment>Data type, column</extracomment>
        <translation>Kunde inte få %1, kolumn %2</translation>
    </message>
    <message>
        <source>Could not set %1, parameter %2</source>
        <extracomment>Data type, parameter</extracomment>
        <translation>Kunde inte ställa in %1, parameter %2</translation>
    </message>
    <message>
        <source>Could not close cursor</source>
        <translation>Kunde inte stänga markör</translation>
    </message>
    <message>
        <source>Could not close statement</source>
        <translation>Kunde inte stänga villkor</translation>
    </message>
    <message>
        <source>Fetch did not succeed</source>
        <translation>Hämtningen lyckades inte</translation>
    </message>
    <message>
        <source>Fetch first did not succeed</source>
        <translation>Hämta först lyckades inte</translation>
    </message>
    <message>
        <source>Could not fetch next row</source>
        <translation>Kunde inte hämta nästa rad</translation>
    </message>
    <message>
        <source>Unknown data type %1</source>
        <translation>Okänd datatyp %1</translation>
    </message>
    <message>
        <source>Could not check null, column %1</source>
        <translation>Kunde inte kontrollera null, kolumn %1</translation>
    </message>
    <message>
        <source>Could not prepare/execute statement</source>
        <translation>Kunde inte förbereda/köra frågesats</translation>
    </message>
    <message>
        <source>Wrong number of parameters</source>
        <translation>Felaktigt antal parametrar</translation>
    </message>
    <message>
        <source>Unknown datatype, parameter %1</source>
        <translation>Okänd datatyp, parameter %1</translation>
    </message>
    <message>
        <source>Could not execute statement/open cursor</source>
        <translation>Kunde inte köra villkor/öppen markör</translation>
    </message>
    <message>
        <source>Only input parameters can be used in batch operations</source>
        <translation>Endast inmatningsparametrar kan användas i satskörningar</translation>
    </message>
    <message>
        <source>Could not add batch %1</source>
        <extracomment>%1 is the batch number</extracomment>
        <translation>Kunde inte lägga till sats %1</translation>
    </message>
    <message>
        <source>Could not execute batch</source>
        <translation>Kunde inte köra sats</translation>
    </message>
</context>
<context>
    <name>QMimerSQLResult:</name>
    <message>
        <source>Fetch last did not succeed</source>
        <translation>Hämtning sist lyckades inte</translation>
    </message>
    <message>
        <source>Column %1 out of range</source>
        <translation>Kolumn %1 utanför intervallet</translation>
    </message>
</context>
<context>
    <name>QNativeSocketEngine</name>
    <message>
        <source>Unable to initialize non-blocking socket</source>
        <translation>Kunde inte initiera icke-blockerande uttag</translation>
    </message>
    <message>
        <source>Unable to initialize broadcast socket</source>
        <translation>Kunde inte initiera uttag för broadcast</translation>
    </message>
    <message>
        <source>Attempt to use IPv6 socket on a platform with no IPv6 support</source>
        <translation>Försök att använda IPv6-uttag på en plattform som saknar IPv6-stöd</translation>
    </message>
    <message>
        <source>The remote host closed the connection</source>
        <translation>Fjärrvärden stängde anslutningen</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>Tidsgräns för nätverksåtgärd överstegs</translation>
    </message>
    <message>
        <source>Out of resources</source>
        <translation>Slut på resurser</translation>
    </message>
    <message>
        <source>Unsupported socket operation</source>
        <translation>Uttagsåtgärden stöds inte</translation>
    </message>
    <message>
        <source>Protocol type not supported</source>
        <translation>Protokolltypen stöds inte</translation>
    </message>
    <message>
        <source>Invalid socket descriptor</source>
        <translation>Ogiltig uttagsbeskrivare</translation>
    </message>
    <message>
        <source>Host unreachable</source>
        <translation>Värden är inte nåbar</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Nätverket är inte nåbart</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Åtkomst nekad</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Tidsgränsen för anslutning överstegs</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Anslutningen vägrades</translation>
    </message>
    <message>
        <source>The bound address is already in use</source>
        <translation>Bindningsadress används redan</translation>
    </message>
    <message>
        <source>The address is not available</source>
        <translation>Adressen är inte tillgänglig</translation>
    </message>
    <message>
        <source>The address is protected</source>
        <translation>Adressen är skyddad</translation>
    </message>
    <message>
        <source>Datagram was too large to send</source>
        <translation>Datagram för för stor för att skicka</translation>
    </message>
    <message>
        <source>Unable to send a message</source>
        <translation>Kunde inte skicka ett meddelande</translation>
    </message>
    <message>
        <source>Unable to receive a message</source>
        <translation>Kunde inte ta emot ett meddelande</translation>
    </message>
    <message>
        <source>Unable to write</source>
        <translation>Kunde inte skriva</translation>
    </message>
    <message>
        <source>Network error</source>
        <translation>Nätverksfel</translation>
    </message>
    <message>
        <source>Another socket is already listening on the same port</source>
        <translation>Ett annat uttag lyssnar redan på samma port</translation>
    </message>
    <message>
        <source>Operation on non-socket</source>
        <translation>Åtgärd på icke-uttag</translation>
    </message>
    <message>
        <source>The proxy type is invalid for this operation</source>
        <translation>Proxytypen är ogiltig för denna åtgärd</translation>
    </message>
    <message>
        <source>Temporary error</source>
        <translation>Temporärt fel</translation>
    </message>
    <message>
        <source>Network dropped connection on reset</source>
        <translation>Nätverket stängde anslutningen vid nollställning</translation>
    </message>
    <message>
        <source>Connection reset by peer</source>
        <translation>Anslutningen nollställdes av motpart</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessCacheBackend</name>
    <message>
        <source>Error opening %1</source>
        <translation>Fel vid öppning %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDataBackend</name>
    <message>
        <source>Invalid URI: %1</source>
        <translation>Ogiltig URI: %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDebugPipeBackend</name>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Skrivfel vid skrivning till %1: %2</translation>
    </message>
    <message>
        <source>Socket error on %1: %2</source>
        <translation>Uttagsfel på %1: %2</translation>
    </message>
    <message>
        <source>Remote host closed the connection prematurely on %1</source>
        <translation>Fjärrvärden stängde anslutningen i förtid på %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFileBackend</name>
    <message>
        <source>Request for opening non-local file %1</source>
        <translation>Begäran för öppning av icke-lokala filen %1</translation>
    </message>
    <message>
        <source>Error opening %1: %2</source>
        <translation>Fel vid öppning av %1: %2</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Skrivfel vid skrivning till %1: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: Path is a directory</source>
        <translation>Kan inte öppna %1: Sökvägen är en katalog</translation>
    </message>
    <message>
        <source>Read error reading from %1: %2</source>
        <translation>Läsfel vid läsning från %1: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkReply</name>
    <message>
        <source>Error transferring %1 - server replied: %2</source>
        <translation>Fel vid överföring %1 - servern svarade: %2</translation>
    </message>
    <message>
        <source>Error transferring %1 - server replied with status code %2</source>
        <translation>Fel vid överföring %1 - servern svarade med statuskod %2</translation>
    </message>
    <message>
        <source>Protocol &quot;%1&quot; is unknown</source>
        <translation>Protokollet &quot;%1&quot; är okänt</translation>
    </message>
    <message>
        <source>backend start error.</source>
        <translation>fel vid start av bakände.</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyHttpImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Åtgärden avbröts</translation>
    </message>
    <message>
        <source>Operation timed out</source>
        <translation>Åtgärden översteg tidsgränsen</translation>
    </message>
    <message>
        <source>No suitable proxy found</source>
        <translation>Ingen lämplig proxy hittades</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Åtgärden avbröts</translation>
    </message>
</context>
<context>
    <name>QOCIDriver</name>
    <message>
        <source>Unable to initialize</source>
        <comment>QOCIDriver</comment>
        <translation>Kunde inte initiera</translation>
    </message>
    <message>
        <source>Unable to logon</source>
        <translation>Kunde inte logga in</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Kunde inte påbörja transaktion</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Kunde inte rulla tillbaka transaktion</translation>
    </message>
</context>
<context>
    <name>QOCIResult</name>
    <message>
        <source>Unable to bind column for batch execute</source>
        <translation>Kunde inte binda kolumn för satskörning</translation>
    </message>
    <message>
        <source>Unable to execute batch statement</source>
        <translation>Kunde inte köra satsfråga</translation>
    </message>
    <message>
        <source>Unable to goto next</source>
        <translation>Kunde inte gå till nästa</translation>
    </message>
    <message>
        <source>Unable to alloc statement</source>
        <translation>Kunde inte allokera frågesats</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Kunde inte förbereda frågesats</translation>
    </message>
    <message>
        <source>Unable to get statement type</source>
        <translation>Kunde inte få villkorstypen</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>Kunde inte binda värde</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Kunde inte köra frågesats</translation>
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <source>Unable to connect</source>
        <translation>Kunde inte ansluta</translation>
    </message>
    <message>
        <source>Unable to connect - Driver doesn&apos;t support all functionality required</source>
        <translation>Kunde inte ansluta - Drivrutinen har inte stöd för all funktionalitet som krävs</translation>
    </message>
    <message>
        <source>Unable to disable autocommit</source>
        <translation>Kunde inte inaktivera automatisk verkställning</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Kunde inte rulla tillbaka transaktion</translation>
    </message>
    <message>
        <source>Unable to enable autocommit</source>
        <translation>Kunde inte aktivera automatisk verkställning</translation>
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <source>Unable to fetch last</source>
        <translation>Kunde inte hämta sista</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_ATTR_CURSOR_TYPE&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: Kunde inte ställa in \&quot;SQL_ATTR_CURSOR_TYPE\&quot; som frågesatsattribut. Kontrollera konfigurationen för din ODBC-drivrutin</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Kunde inte köra villkor</translation>
    </message>
    <message>
        <source>Unable to fetch</source>
        <translation>Kunde inte hämta</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>Kunde inte hämta nästa</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>Kunde inte hämta första</translation>
    </message>
    <message>
        <source>Unable to fetch previous</source>
        <translation>Kunde inte hämta föregående</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_CURSOR_STATIC&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: Kunde inte ställa in \&quot;SQL_CURSOR_STATIC\&quot; som frågesatsattribut. Kontrollera konfigurationen för din ODBC-drivrutin</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Kunde inte förbereda frågesats</translation>
    </message>
    <message>
        <source>Unable to bind variable</source>
        <translation>Kunde inte binda variabel</translation>
    </message>
</context>
<context>
    <name>QPSQLDriver</name>
    <message>
        <source>Unable to connect</source>
        <translation>Kunde inte ansluta</translation>
    </message>
    <message>
        <source>Unable to set client encoding to &apos;UNICODE&apos;</source>
        <translation>Kunde inte ställa in klientenkodning till &apos;UNICODE&apos;</translation>
    </message>
    <message>
        <source>Could not begin transaction</source>
        <translation>Kunde inte påbörja transaktion</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Could not rollback transaction</source>
        <translation>Kunde inte rulla tillbaka transaktion</translation>
    </message>
    <message>
        <source>Unable to subscribe</source>
        <translation>Kunde inte prenumerera</translation>
    </message>
    <message>
        <source>Unable to unsubscribe</source>
        <translation>Kunde inte avprenumerera</translation>
    </message>
</context>
<context>
    <name>QPSQLResult</name>
    <message>
        <source>Query results lost - probably discarded on executing another SQL query.</source>
        <translation>Frågesatsens resultat förlorades - antagligen förkastade vid körning av en annan SQL-fråga.</translation>
    </message>
    <message>
        <source>Unable to create query</source>
        <translation>Kunde inte skapa fråga</translation>
    </message>
    <message>
        <source>Unable to get result</source>
        <translation>Kunde inte få resultat</translation>
    </message>
    <message>
        <source>Unable to send query</source>
        <translation>Kunde inte skicka frågesats</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Kunde inte förbereda villkor</translation>
    </message>
</context>
<context>
    <name>QPageSetupWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation>Papper</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Sidstorlek:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Bredd:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Höjd:</translation>
    </message>
    <message>
        <source>Paper source:</source>
        <translation>Papperskälla:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientering</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Stående</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Liggande</translation>
    </message>
    <message>
        <source>Reverse landscape</source>
        <translation>Omvänt liggande</translation>
    </message>
    <message>
        <source>Reverse portrait</source>
        <translation>Omvänt stående</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>Marginaler</translation>
    </message>
    <message>
        <source>top margin</source>
        <translation>övre marginal</translation>
    </message>
    <message>
        <source>left margin</source>
        <translation>vänstermarginal</translation>
    </message>
    <message>
        <source>right margin</source>
        <translation>högermarginal</translation>
    </message>
    <message>
        <source>bottom margin</source>
        <translation>nedre marginal</translation>
    </message>
    <message>
        <source>Page Layout</source>
        <translation>Sidlayout</translation>
    </message>
    <message>
        <source>Millimeters (mm)</source>
        <translation>Millimeter (mm)</translation>
    </message>
    <message>
        <source>Inches (in)</source>
        <translation>Tum (in)</translation>
    </message>
    <message>
        <source>Points (pt)</source>
        <translation>Punkter (pt)</translation>
    </message>
    <message>
        <source>Pica (P̸)</source>
        <translation>Pica (P̸)</translation>
    </message>
    <message>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Anpassad</translation>
    </message>
    <message>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation>mm</translation>
    </message>
    <message>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation>pt</translation>
    </message>
    <message>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation>tum</translation>
    </message>
    <message>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation>P̸</translation>
    </message>
    <message>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation>DD</translation>
    </message>
    <message>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation>CC</translation>
    </message>
    <message>
        <source>Page &amp;order:</source>
        <translation>Sid&amp;ordning:</translation>
    </message>
    <message>
        <source>Pages &amp;per sheet:</source>
        <translation>Sidor &amp;per ark:</translation>
    </message>
</context>
<context>
    <name>QPageSize</name>
    <message>
        <source>Custom (%1mm x %2mm)</source>
        <extracomment>Custom size name in millimeters</extracomment>
        <translation>Anpassad (%1mm x %2mm)</translation>
    </message>
    <message>
        <source>Custom (%1pt x %2pt)</source>
        <extracomment>Custom size name in points</extracomment>
        <translation>Anpassad (%1pt x %2pt)</translation>
    </message>
    <message>
        <source>Custom (%1in x %2in)</source>
        <extracomment>Custom size name in inches</extracomment>
        <translation>Anpassad (%1 tum x %2 tum)</translation>
    </message>
    <message>
        <source>Custom (%1pc x %2pc)</source>
        <extracomment>Custom size name in picas</extracomment>
        <translation>Anpassad (%1pc x %2pc)</translation>
    </message>
    <message>
        <source>Custom (%1DD x %2DD)</source>
        <extracomment>Custom size name in didots</extracomment>
        <translation>Anpassad (%1DD x %2DD)</translation>
    </message>
    <message>
        <source>Custom (%1CC x %2CC)</source>
        <extracomment>Custom size name in ciceros</extracomment>
        <translation>Anpassad (%1CC x %2CC)</translation>
    </message>
    <message>
        <source>%1 x %2 in</source>
        <extracomment>Page size in &apos;Inch&apos;.</extracomment>
        <translation>%1 x %2 tum</translation>
    </message>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source>B6</source>
        <translation>B6</translation>
    </message>
    <message>
        <source>B7</source>
        <translation>B7</translation>
    </message>
    <message>
        <source>B8</source>
        <translation>B8</translation>
    </message>
    <message>
        <source>B9</source>
        <translation>B9</translation>
    </message>
    <message>
        <source>B10</source>
        <translation>B10</translation>
    </message>
    <message>
        <source>Executive (7.5 x 10 in)</source>
        <translation>Executive (7.5 x 10 tum)</translation>
    </message>
    <message>
        <source>Executive (7.25 x 10.5 in)</source>
        <translation>Executive (7.25 x 10.5 tum)</translation>
    </message>
    <message>
        <source>Folio (8.27 x 13 in)</source>
        <translation>Folio (8.27 x 13 tum)</translation>
    </message>
    <message>
        <source>Legal</source>
        <translation>Legal</translation>
    </message>
    <message>
        <source>Letter / ANSI A</source>
        <translation>Brev / ANSI A</translation>
    </message>
    <message>
        <source>Tabloid / ANSI B</source>
        <translation>Nyhetstidning / ANSI B</translation>
    </message>
    <message>
        <source>Ledger / ANSI B</source>
        <translation>Ledger / ANSI B</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Anpassad</translation>
    </message>
    <message>
        <source>A3 Extra</source>
        <translation>A3 Extra</translation>
    </message>
    <message>
        <source>A4 Extra</source>
        <translation>A4 Extra</translation>
    </message>
    <message>
        <source>A4 Plus</source>
        <translation>A4 Plus</translation>
    </message>
    <message>
        <source>A4 Small</source>
        <translation>A4 liten</translation>
    </message>
    <message>
        <source>A5 Extra</source>
        <translation>A5 Extra</translation>
    </message>
    <message>
        <source>B5 Extra</source>
        <translation>B5 Extra</translation>
    </message>
    <message>
        <source>JIS B0</source>
        <translation>JIS B0</translation>
    </message>
    <message>
        <source>JIS B1</source>
        <translation>JIS B1</translation>
    </message>
    <message>
        <source>JIS B2</source>
        <translation>JIS B2</translation>
    </message>
    <message>
        <source>JIS B3</source>
        <translation>JIS B3</translation>
    </message>
    <message>
        <source>JIS B4</source>
        <translation>JIS B4</translation>
    </message>
    <message>
        <source>JIS B5</source>
        <translation>JIS B5</translation>
    </message>
    <message>
        <source>JIS B6</source>
        <translation>JIS B6</translation>
    </message>
    <message>
        <source>JIS B7</source>
        <translation>JIS B7</translation>
    </message>
    <message>
        <source>JIS B8</source>
        <translation>JIS B8</translation>
    </message>
    <message>
        <source>JIS B9</source>
        <translation>JIS B9</translation>
    </message>
    <message>
        <source>JIS B10</source>
        <translation>JIS B10</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <source>Legal Extra</source>
        <translation>Brev extra</translation>
    </message>
    <message>
        <source>Letter Extra</source>
        <translation>Brev extra</translation>
    </message>
    <message>
        <source>Letter Plus</source>
        <translation>Brev plus</translation>
    </message>
    <message>
        <source>Letter Small</source>
        <translation>Brev litet</translation>
    </message>
    <message>
        <source>Tabloid Extra</source>
        <translation>Nyhetstidning extra</translation>
    </message>
    <message>
        <source>Architect A</source>
        <translation>Arkitekt A</translation>
    </message>
    <message>
        <source>Architect B</source>
        <translation>Arkitekt B</translation>
    </message>
    <message>
        <source>Architect C</source>
        <translation>Arkitekt C</translation>
    </message>
    <message>
        <source>Architect D</source>
        <translation>Arkitekt D</translation>
    </message>
    <message>
        <source>Architect E</source>
        <translation>Arkitekt E</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Anteckning</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation>Quarto</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation>Kungörelse</translation>
    </message>
    <message>
        <source>Super A</source>
        <translation>Super A</translation>
    </message>
    <message>
        <source>Super B</source>
        <translation>Super B</translation>
    </message>
    <message>
        <source>Postcard</source>
        <translation>Vykort</translation>
    </message>
    <message>
        <source>Double Postcard</source>
        <translation>Dubbelt vykort</translation>
    </message>
    <message>
        <source>PRC 16K</source>
        <translation>PRC 16K</translation>
    </message>
    <message>
        <source>PRC 32K</source>
        <translation>PRC 32K</translation>
    </message>
    <message>
        <source>PRC 32K Big</source>
        <translation>PRC 32K stor</translation>
    </message>
    <message>
        <source>Fan-fold US (14.875 x 11 in)</source>
        <translation>Fan-fold US (14.875 x 11 tum)</translation>
    </message>
    <message>
        <source>Fan-fold German (8.5 x 12 in)</source>
        <translation>Fan-fold tysk (8.5 x 12 tum)</translation>
    </message>
    <message>
        <source>Fan-fold German Legal (8.5 x 13 in)</source>
        <translation>Fan-fold tysk Legal (8.5 x 13 tum)</translation>
    </message>
    <message>
        <source>Envelope B4</source>
        <translation>Kuvert B4</translation>
    </message>
    <message>
        <source>Envelope B5</source>
        <translation>Kuvert B5</translation>
    </message>
    <message>
        <source>Envelope B6</source>
        <translation>Kuvert B6</translation>
    </message>
    <message>
        <source>Envelope C0</source>
        <translation>Kuvert C0</translation>
    </message>
    <message>
        <source>Envelope C1</source>
        <translation>Kuvert C1</translation>
    </message>
    <message>
        <source>Envelope C2</source>
        <translation>Kuvert C2</translation>
    </message>
    <message>
        <source>Envelope C3</source>
        <translation>Kuvert C3</translation>
    </message>
    <message>
        <source>Envelope C4</source>
        <translation>Kuvert C4</translation>
    </message>
    <message>
        <source>Envelope C5</source>
        <translation>Kuvert C5</translation>
    </message>
    <message>
        <source>Envelope C6</source>
        <translation>Kuvert C6</translation>
    </message>
    <message>
        <source>Envelope C65</source>
        <translation>Kuvert C65</translation>
    </message>
    <message>
        <source>Envelope C7</source>
        <translation>Kuvert C7</translation>
    </message>
    <message>
        <source>Envelope DL</source>
        <translation>Kuvert DL</translation>
    </message>
    <message>
        <source>Envelope US 9</source>
        <translation>Kuvert US 9</translation>
    </message>
    <message>
        <source>Envelope US 10</source>
        <translation>Kuvert US 10</translation>
    </message>
    <message>
        <source>Envelope US 11</source>
        <translation>Kuvert US 11</translation>
    </message>
    <message>
        <source>Envelope US 12</source>
        <translation>Kuvert US 12</translation>
    </message>
    <message>
        <source>Envelope US 14</source>
        <translation>Kuvert US 14</translation>
    </message>
    <message>
        <source>Envelope Monarch</source>
        <translation>Envelope Monarch</translation>
    </message>
    <message>
        <source>Envelope Personal</source>
        <translation>Kuvert Personal</translation>
    </message>
    <message>
        <source>Envelope Chou 3</source>
        <translation>Kuvert Chou 3</translation>
    </message>
    <message>
        <source>Envelope Chou 4</source>
        <translation>Kuvert Chou 4</translation>
    </message>
    <message>
        <source>Envelope Invite</source>
        <translation>Envelope Invite</translation>
    </message>
    <message>
        <source>Envelope Italian</source>
        <translation>Kuvert italienskt</translation>
    </message>
    <message>
        <source>Envelope Kaku 2</source>
        <translation>Kuvert Kaku 2</translation>
    </message>
    <message>
        <source>Envelope Kaku 3</source>
        <translation>Kuvert Kaku 3</translation>
    </message>
    <message>
        <source>Envelope PRC 1</source>
        <translation>Kuvert PRC 1</translation>
    </message>
    <message>
        <source>Envelope PRC 2</source>
        <translation>Kuvert PRC 2</translation>
    </message>
    <message>
        <source>Envelope PRC 3</source>
        <translation>Kuvert PRC 3</translation>
    </message>
    <message>
        <source>Envelope PRC 4</source>
        <translation>Kuvert PRC 4</translation>
    </message>
    <message>
        <source>Envelope PRC 5</source>
        <translation>Kuvert PRC 5</translation>
    </message>
    <message>
        <source>Envelope PRC 6</source>
        <translation>Kuvert PRC 6</translation>
    </message>
    <message>
        <source>Envelope PRC 7</source>
        <translation>Kuvert PRC 7</translation>
    </message>
    <message>
        <source>Envelope PRC 8</source>
        <translation>Kuvert PRC 8</translation>
    </message>
    <message>
        <source>Envelope PRC 9</source>
        <translation>Kuvert PRC 9</translation>
    </message>
    <message>
        <source>Envelope PRC 10</source>
        <translation>Kuvert PRC 10</translation>
    </message>
    <message>
        <source>Envelope You 4</source>
        <translation>Kuvert You 4</translation>
    </message>
</context>
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Spara allt</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Ja till &amp;allt</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nej</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;ej till allt</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Försök igen</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignorera</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Förkasta</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Verkställ</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Nollställ</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Nollställ till standard</translation>
    </message>
</context>
<context>
    <name>QPluginLoader</name>
    <message>
        <source>The plugin was not loaded.</source>
        <translation>Insticksprogrammet lästes inte in.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
</context>
<context>
    <name>QPrintDialog</name>
    <message>
        <source>Print</source>
        <translation>Skriv ut</translation>
    </message>
    <message>
        <source>Left to Right, Top to Bottom</source>
        <translation>Vänster till höger, topp till botten</translation>
    </message>
    <message>
        <source>Left to Right, Bottom to Top</source>
        <translation>Vänster till höger, botten till toppen</translation>
    </message>
    <message>
        <source>Right to Left, Bottom to Top</source>
        <translation>Höger till vänster, botten till toppen</translation>
    </message>
    <message>
        <source>Right to Left, Top to Bottom</source>
        <translation>Höger till vänster, toppen till botten</translation>
    </message>
    <message>
        <source>Bottom to Top, Left to Right</source>
        <translation>Botten till toppen, vänster till höger</translation>
    </message>
    <message>
        <source>Bottom to Top, Right to Left</source>
        <translation>Botten till toppen, höger till vänster</translation>
    </message>
    <message>
        <source>Top to Bottom, Left to Right</source>
        <translation>Topp till botten, vänster till höger</translation>
    </message>
    <message>
        <source>Top to Bottom, Right to Left</source>
        <translation>Topp till botten, höger till vänster</translation>
    </message>
    <message>
        <source>1 (1x1)</source>
        <translation>1 (1x1)</translation>
    </message>
    <message>
        <source>2 (2x1)</source>
        <translation>2 (2x1)</translation>
    </message>
    <message>
        <source>4 (2x2)</source>
        <translation>4 (2x2)</translation>
    </message>
    <message>
        <source>6 (2x3)</source>
        <translation>6 (2x3)</translation>
    </message>
    <message>
        <source>9 (3x3)</source>
        <translation>9 (3x3)</translation>
    </message>
    <message>
        <source>16 (4x4)</source>
        <translation>16 (4x4)</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Alla sidor</translation>
    </message>
    <message>
        <source>Odd Pages</source>
        <translation>Udda sidor</translation>
    </message>
    <message>
        <source>Even Pages</source>
        <translation>Jämna sidor</translation>
    </message>
    <message>
        <source>&amp;Options &gt;&gt;</source>
        <translation>A&amp;lternativ &gt;&gt;</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>Skriv &amp;ut</translation>
    </message>
    <message>
        <source>&amp;Options &lt;&lt;</source>
        <translation>A&amp;lternativ &lt;&lt;</translation>
    </message>
    <message>
        <source>Invalid Pages Definition</source>
        <translation>Ogiltig siddefinition</translation>
    </message>
    <message>
        <source>%1 does not follow the correct syntax. Please use &apos;,&apos; to separate ranges and pages, &apos;-&apos; to define ranges and make sure ranges do not intersect with each other.</source>
        <translation>%1 följer inte korrekt syntax. Använd &quot;,&quot; för att separera intervall och sidor, &quot;&apos;-&quot; för att definiera intervall och försäka dig om att intervallen inte överlappar varandra.</translation>
    </message>
    <message>
        <source>Duplex Settings Conflicts</source>
        <translation>Konflikter i dubbelsidiga inställningar</translation>
    </message>
    <message>
        <source>There are conflicts in duplex settings. Do you want to fix them?</source>
        <translation>Det finns konflikter i dubbelsidiga inställningar. Vill du rätta till dem?</translation>
    </message>
    <message>
        <source>Print to File (PDF)</source>
        <translation>Skriv ut till fil (PDF)</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Lokal fil</translation>
    </message>
    <message>
        <source>Write PDF file</source>
        <translation>Skriv PDF-fil</translation>
    </message>
    <message>
        <source>Print To File ...</source>
        <translation>Skriv ut till fil ...</translation>
    </message>
    <message>
        <source>%1 is a directory.
Please choose a different file name.</source>
        <translation>%1 är en katalog.
Välj ett annat filnamn.</translation>
    </message>
    <message>
        <source>File %1 is not writable.
Please choose a different file name.</source>
        <translation>Filen %1 är inte skrivbar.
Välj ett annat filnamn.</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to overwrite it?</source>
        <translation>%1 finns redan.
Vill du skriva över den?</translation>
    </message>
    <message>
        <source>Options &apos;Pages Per Sheet&apos; and &apos;Page Set&apos; cannot be used together.
Please turn one of those options off.</source>
        <translation>Alternativen &quot;Sidor per ark&quot; och &quot;Siduppsättning&quot; kan inte användas samtidigt.
Stäng av ett av alternativen.</translation>
    </message>
    <message>
        <source>The &apos;From&apos; value cannot be greater than the &apos;To&apos; value.</source>
        <translation>Värdet &quot;Från&quot; får inte vara större än värdet för &quot;Till&quot;.</translation>
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
        <source>Page Setup</source>
        <translation>Sidkonfiguration</translation>
    </message>
    <message>
        <source>%1%</source>
        <extracomment>Zoom factor percentage value, % is the percent sign</extracomment>
        <translation>%1%</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Förhandsvisa utskrift</translation>
    </message>
    <message>
        <source>Next page</source>
        <translation>Nästa sida</translation>
    </message>
    <message>
        <source>Previous page</source>
        <translation>Föregående sida</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>Första sidan</translation>
    </message>
    <message>
        <source>Last page</source>
        <translation>Sista sidan</translation>
    </message>
    <message>
        <source>Fit width</source>
        <translation>Anpassa till bredd</translation>
    </message>
    <message>
        <source>Fit page</source>
        <translation>Anpassa till sida</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation>Zooma in</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation>Zooma ut</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Stående</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Liggande</translation>
    </message>
    <message>
        <source>Show single page</source>
        <translation>Visa en sida</translation>
    </message>
    <message>
        <source>Show facing pages</source>
        <translation>Visa uppslagssidor</translation>
    </message>
    <message>
        <source>Show overview of all pages</source>
        <translation>Visa översikt över alla sidor</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Skriv ut</translation>
    </message>
    <message>
        <source>Page setup</source>
        <translation>Sidkonfiguration</translation>
    </message>
    <message>
        <source>Export to PDF</source>
        <translation>Exportera till PDF</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesDialog</name>
    <message>
        <source>Printer Properties</source>
        <translation>Skrivaregenskaper</translation>
    </message>
    <message>
        <source>Job Options</source>
        <translation>Jobbalternativ</translation>
    </message>
    <message>
        <source>Page Setup Conflicts</source>
        <translation>Konflikter i sidkonfiguration</translation>
    </message>
    <message>
        <source>There are conflicts in page setup options. Do you want to fix them?</source>
        <translation>Det finns konflikter i alternativen för sidkonfiguration. Vill du rätta till dem?</translation>
    </message>
    <message>
        <source>Advanced Option Conflicts</source>
        <translation>Konflikter i avancerade alternativ</translation>
    </message>
    <message>
        <source>There are conflicts in some advanced options. Do you want to fix them?</source>
        <translation>Det finns konflikter i några avancerade alternativ. Vill du rätta till dem?</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avancerat</translation>
    </message>
    <message>
        <source>There are conflicts in some options. Please fix them.</source>
        <translation>Det finns konflikter i vissa alternativ. Rätta till dem.</translation>
    </message>
</context>
<context>
    <name>QPrintSettingsOutput</name>
    <message>
        <source>Form</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <source>Copies</source>
        <translation>Kopior</translation>
    </message>
    <message>
        <source>Print range</source>
        <translation>Skriv ut intervall</translation>
    </message>
    <message>
        <source>Print all</source>
        <translation>Skriv ut alla</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Sidor från</translation>
    </message>
    <message>
        <source>to</source>
        <translation>till</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Sidor</translation>
    </message>
    <message>
        <source>Specify pages or ranges separated by commas. Ranges are specified by two numbers separated by a hyphen. E.g: 3,5-7,9 prints pages 3, 5, 6, 7 and 9.</source>
        <translation>Ange sidor eller intervall separerade med kommatecken. Intervall anges med två siffror separerade med ett skiljetecken. T.ex 3,5-7,9 skriver ut sidorna 3, 5, 6, 7 och 9.</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Aktuell sida</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Val</translation>
    </message>
    <message>
        <source>Output Settings</source>
        <translation>Utskriftsinställningar</translation>
    </message>
    <message>
        <source>Copies:</source>
        <translation>Kopior:</translation>
    </message>
    <message>
        <source>Collate</source>
        <translation>Sortera</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation>Omvänd</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <source>Color Mode</source>
        <translation>Färgläge</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <source>Grayscale</source>
        <translation>Gråskala</translation>
    </message>
    <message>
        <source>Double Sided Printing</source>
        <translation>Dubbelsidig utskrift</translation>
    </message>
    <message>
        <source>Off</source>
        <translation>Av</translation>
    </message>
    <message>
        <source>Long side binding</source>
        <translation>Långsidesbindning</translation>
    </message>
    <message>
        <source>Short side binding</source>
        <translation>Kortsidesbindning</translation>
    </message>
    <message>
        <source>Page &amp;Set:</source>
        <translation>Sidupps&amp;ättning:</translation>
    </message>
</context>
<context>
    <name>QPrintWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Skrivare</translation>
    </message>
    <message>
        <source>&amp;Name:</source>
        <translation>&amp;Namn:</translation>
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation>E&amp;genskaper</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Plats:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Förhandsvisa</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>Output &amp;file:</source>
        <translation>Utdata&amp;fil:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>QProcess</name>
    <message>
        <source>Process failed to start</source>
        <translation>Proceesen misslyckades att starta</translation>
    </message>
    <message>
        <source>Process crashed</source>
        <translation>Processen kraschade</translation>
    </message>
    <message>
        <source>Process operation timed out</source>
        <translation>Processåtgärden gick över tidsgränsen</translation>
    </message>
    <message>
        <source>Error reading from process</source>
        <translation>Fel vid läsning från process</translation>
    </message>
    <message>
        <source>Error writing to process</source>
        <translation>Fel vid skrivning till process</translation>
    </message>
    <message>
        <source>No program defined</source>
        <translation>Inget program definierat</translation>
    </message>
    <message>
        <source>Could not open input redirection for reading</source>
        <translation>Kunde inte öppna inmatningsomdirigering för läsning</translation>
    </message>
    <message>
        <source>Resource error (fork failure): %1</source>
        <translation>Resursfel (förgreningsfel): %1</translation>
    </message>
    <message>
        <source>Child process modifier threw an exception: %1</source>
        <translation>Barnprocessmodifierare kastade ett undantag: %1</translation>
    </message>
    <message>
        <source>Child process modifier reported error: %1</source>
        <translation>Barnprocessmodifierare rapporterade fel: %1</translation>
    </message>
    <message>
        <source>Child process modifier reported error: %1: %2</source>
        <translation>Barnprocessmodifierare rapporterade fel: %1: %2</translation>
    </message>
    <message>
        <source>Child process set up failed: %1: %2</source>
        <translation>Barnprocesskonfiguration misslyckades: %1: %2</translation>
    </message>
    <message>
        <source>Could not open output redirection for writing</source>
        <translation>Kunde inte öppna utmatningsomdirigering för skrivning</translation>
    </message>
    <message>
        <source>Process failed to start: %1</source>
        <translation>Process misslyckades med att starta: %1</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
</context>
<context>
    <name>QRegularExpression</name>
    <message>
        <source>no error</source>
        <translation>inget fel</translation>
    </message>
    <message>
        <source>\ at end of pattern</source>
        <translation>\ vid slutet av mönstret</translation>
    </message>
    <message>
        <source>\c at end of pattern</source>
        <translation>\c vid slutet av mönstret</translation>
    </message>
    <message>
        <source>unrecognized character follows \</source>
        <translation>okänt tecken följer efter \</translation>
    </message>
    <message>
        <source>numbers out of order in {} quantifier</source>
        <translation>antalet är i fel ordning i {}-kvantifierare</translation>
    </message>
    <message>
        <source>number too big in {} quantifier</source>
        <translation>antal för stort i {}-kvantifierare</translation>
    </message>
    <message>
        <source>missing terminating ] for character class</source>
        <translation>saknar avslutande ] för teckenklass</translation>
    </message>
    <message>
        <source>escape sequence is invalid in character class</source>
        <translation>escape-sekvens är ogiltig i teckenklass</translation>
    </message>
    <message>
        <source>range out of order in character class</source>
        <translation>intervallet är i fel ordning i teckenklass</translation>
    </message>
    <message>
        <source>quantifier does not follow a repeatable item</source>
        <translation>kvantifierare följer inte en upprepande post</translation>
    </message>
    <message>
        <source>internal error: unexpected repeat</source>
        <translation>internt fel: oväntad repetition</translation>
    </message>
    <message>
        <source>unrecognized character after (? or (?-</source>
        <translation>okänt tecken efter (? eller (?-</translation>
    </message>
    <message>
        <source>POSIX named classes are supported only within a class</source>
        <translation>POSIX-namngivna klasser stöds endast inom en klass</translation>
    </message>
    <message>
        <source>POSIX collating elements are not supported</source>
        <translation>POSIX sammanställande element stöds inte</translation>
    </message>
    <message>
        <source>missing closing parenthesis</source>
        <translation>saknar avslutande  parantes</translation>
    </message>
    <message>
        <source>reference to non-existent subpattern</source>
        <translation>referens till icke-existerande undermönster</translation>
    </message>
    <message>
        <source>pattern passed as NULL</source>
        <translation>mönster skickad som NULL</translation>
    </message>
    <message>
        <source>unrecognised compile-time option bit(s)</source>
        <translation>okänd compile-time option bit(ar)</translation>
    </message>
    <message>
        <source>missing ) after (?# comment</source>
        <translation>saknar ) efter (?#-kommentar</translation>
    </message>
    <message>
        <source>parentheses are too deeply nested</source>
        <translation>paranteser är för djupt nästlade</translation>
    </message>
    <message>
        <source>regular expression is too large</source>
        <translation>reguljärt uttryck är för stort</translation>
    </message>
    <message>
        <source>failed to allocate heap memory</source>
        <translation>misslyckades med att allokera heap-minne</translation>
    </message>
    <message>
        <source>unmatched closing parenthesis</source>
        <translation>omatchad avslutande parantes</translation>
    </message>
    <message>
        <source>internal error: code overflow</source>
        <translation>internt fel: kodöverflöde</translation>
    </message>
    <message>
        <source>missing closing parenthesis for condition</source>
        <translation>saknar avslutande parantes för villkor</translation>
    </message>
    <message>
        <source>lookbehind assertion is not fixed length</source>
        <translation>lookbehind-assertion har ingen fast längd</translation>
    </message>
    <message>
        <source>a relative value of zero is not allowed</source>
        <translation>ett relativt värde av noll tillåts inte</translation>
    </message>
    <message>
        <source>conditional subpattern contains more than two branches</source>
        <translation>villkorligt undermönster innehåller fler än två grenar</translation>
    </message>
    <message>
        <source>assertion expected after (?( or (?(?C)</source>
        <translation>assertion förväntades efter (?( eller (?(?C)</translation>
    </message>
    <message>
        <source>digit expected after (?+ or (?-</source>
        <translation>siffra förväntades efter (?+ eller (?-</translation>
    </message>
    <message>
        <source>unknown POSIX class name</source>
        <translation>okänt POSIX-klassnamn</translation>
    </message>
    <message>
        <source>internal error in pcre2_study(): should not occur</source>
        <translation>internt fel i pcre2_study(): ska inte inträffa</translation>
    </message>
    <message>
        <source>this version of PCRE2 does not have Unicode support</source>
        <translation>denna version av PCRE2 har inte stöd för Unicode</translation>
    </message>
    <message>
        <source>parentheses are too deeply nested (stack check)</source>
        <translation>parenteser är för djupt nästlade (stackkontroll)</translation>
    </message>
    <message>
        <source>character code point value in \x{} or \o{} is too large</source>
        <translation>värdet för teckenkodpunkt i \x{} eller \o{} är för stort</translation>
    </message>
    <message>
        <source>lookbehind is too complicated</source>
        <translation>lookbehind är för komplicerad</translation>
    </message>
    <message>
        <source>\C is not allowed in a lookbehind assertion in UTF-16 mode</source>
        <translation>\C är inte tillåtet i en lookbehind-assertion i UTF-16-läget</translation>
    </message>
    <message>
        <source>PCRE2 does not support \F, \L, \l, \N{name}, \U, or \u</source>
        <translation>PCRE2 har inte stöd för \F, \L, \l, \N{name}, \U, eller \u</translation>
    </message>
    <message>
        <source>number after (?C is greater than 255</source>
        <translation>tal efter (?C är större än 255</translation>
    </message>
    <message>
        <source>closing parenthesis for (?C expected</source>
        <translation>avslutande parentes för (?C förväntades</translation>
    </message>
    <message>
        <source>invalid escape sequence in (*VERB) name</source>
        <translation>ogiltig escape-sekvens i (*VERB)-namn</translation>
    </message>
    <message>
        <source>unrecognized character after (?P</source>
        <translation>okänt tecken efter (?P</translation>
    </message>
    <message>
        <source>syntax error in subpattern name (missing terminator?)</source>
        <translation>syntaxfel i undermönsternamnet (saknar avslut?)</translation>
    </message>
    <message>
        <source>two named subpatterns have the same name (PCRE2_DUPNAMES not set)</source>
        <translation>två namngivna undermönster har samma namn (PCRE2_DUPNAMES inte inställt)</translation>
    </message>
    <message>
        <source>subpattern name must start with a non-digit</source>
        <translation>undermönstrets namn måste börja med en icke-siffra</translation>
    </message>
    <message>
        <source>this version of PCRE2 does not have support for \P, \p, or \X</source>
        <translation>denna version av PCRE2 har inte stöd för \P, \p, eller \X</translation>
    </message>
    <message>
        <source>malformed \P or \p sequence</source>
        <translation>felformaterad \P eller \p-sekvens</translation>
    </message>
    <message>
        <source>unknown property name after \P or \p</source>
        <translation>okänt egenskapsnamn efter \P eller \p</translation>
    </message>
    <message>
        <source>subpattern name is too long (maximum 32 code units)</source>
        <translation>undermönsternamn är för långt (maximalt 32 kodenheter)</translation>
    </message>
    <message>
        <source>too many named subpatterns (maximum 10000)</source>
        <translation>för många namngivna undermönster (maximalt 10000)</translation>
    </message>
    <message>
        <source>invalid range in character class</source>
        <translation>ogiltigt intervall i teckenklass</translation>
    </message>
    <message>
        <source>octal value is greater than \377 in 8-bit non-UTF-8 mode</source>
        <translation>oktalt värde är större än \377 i 8-bitars icke-UTF-8-läge</translation>
    </message>
    <message>
        <source>internal error: overran compiling workspace</source>
        <translation>internt fel: överskridit kompileringsarbetsytan</translation>
    </message>
    <message>
        <source>internal error: previously-checked referenced subpattern not found</source>
        <translation>internt fel: tidigare kontrollerat refererande undermönster hittades inte</translation>
    </message>
    <message>
        <source>DEFINE subpattern contains more than one branch</source>
        <translation>DEFINE-undermönster innehåller fler än en gren</translation>
    </message>
    <message>
        <source>missing opening brace after \o</source>
        <translation>saknar öppnande klammer efter \o</translation>
    </message>
    <message>
        <source>internal error: unknown newline setting</source>
        <translation>internt fel: okänd nyradsinställning</translation>
    </message>
    <message>
        <source>\g is not followed by a braced, angle-bracketed, or quoted name/number or by a plain number</source>
        <translation>\g följs inte av en klammer, vinkelparentes eller citerat namn/nummer eller av ett vanligt nummer</translation>
    </message>
    <message>
        <source>(?R (recursive pattern call) must be followed by a closing parenthesis</source>
        <translation>(?R (rekursivt mönsteranrop) måste efterföljas av en stängande parentes</translation>
    </message>
    <message>
        <source>obsolete error (should not occur)</source>
        <translation>föråldrat fel (ska inte inträffa)</translation>
    </message>
    <message>
        <source>(*VERB) not recognized or malformed</source>
        <translation>(*VERB) känns inte igen eller är felformaterat</translation>
    </message>
    <message>
        <source>subpattern number is too big</source>
        <translation>undermönsternummer är för stort</translation>
    </message>
    <message>
        <source>subpattern name expected</source>
        <translation>undermönstrets namn förväntades</translation>
    </message>
    <message>
        <source>internal error: parsed pattern overflow</source>
        <translation>internt fel: överflöde i tolkat mönster</translation>
    </message>
    <message>
        <source>non-octal character in \o{} (closing brace missing?)</source>
        <translation>icke-oktalt tecken i \o{} (avslutande klammerparentes saknas?)</translation>
    </message>
    <message>
        <source>different names for subpatterns of the same number are not allowed</source>
        <translation>olika namn för undermönster för samma antal tillåts inte</translation>
    </message>
    <message>
        <source>(*MARK) must have an argument</source>
        <translation>(*MARK) måste ha ett argument</translation>
    </message>
    <message>
        <source>non-hex character in \x{} (closing brace missing?)</source>
        <translation>icke-hexadecimalt tecken i \x{} (saknas stängande klammer?)</translation>
    </message>
    <message>
        <source>\c must be followed by a printable ASCII character</source>
        <translation>\c måste efterföljas av ett utskrivbart ASCII-tecken</translation>
    </message>
    <message>
        <source>\c must be followed by a letter or one of [\]^_?</source>
        <translation>\c måste efterföljas av en bokstav eller en av [\]^_?</translation>
    </message>
    <message>
        <source>\k is not followed by a braced, angle-bracketed, or quoted name</source>
        <translation>\k efterföljs inte av en klammer-, vinkelparentes eller citerat namn</translation>
    </message>
    <message>
        <source>internal error: unknown meta code in check_lookbehinds()</source>
        <translation>internt fel: okänd metakod i check_lookbehinds()</translation>
    </message>
    <message>
        <source>\N is not supported in a class</source>
        <translation>\N stöds inte i en klass</translation>
    </message>
    <message>
        <source>callout string is too long</source>
        <translation>callout-sträng är för lång</translation>
    </message>
    <message>
        <source>disallowed Unicode code point (&gt;= 0xd800 &amp;&amp; &lt;= 0xdfff)</source>
        <translation>otillåten Unicode-kodpunkt (&gt;= 0xd800 &amp;&amp; &lt;= 0xdfff)</translation>
    </message>
    <message>
        <source>using UTF is disabled by the application</source>
        <translation>användning av UTF är inaktiverat av programmet</translation>
    </message>
    <message>
        <source>using UCP is disabled by the application</source>
        <translation>användning av UDP är inaktiverat av programmet</translation>
    </message>
    <message>
        <source>name is too long in (*MARK), (*PRUNE), (*SKIP), or (*THEN)</source>
        <translation>namnet är för långt i (*MARK), (*PRUNE), (*SKIP), eller (*THEN)</translation>
    </message>
    <message>
        <source>character code point value in \u.... sequence is too large</source>
        <translation>värdet för teckenkodpunkt i \u....-sekvensen är för stort</translation>
    </message>
    <message>
        <source>digits missing in \x{} or \o{} or \N{U+}</source>
        <translation>siffror saknas i \x{} eller \o{} eller \N{U+}</translation>
    </message>
    <message>
        <source>syntax error or number too big in (?(VERSION condition</source>
        <translation>syntaxfel eller för antal för stort i villkoret (?(VERSION</translation>
    </message>
    <message>
        <source>internal error: unknown opcode in auto_possessify()</source>
        <translation>internt fel: okänd opcode i auto_possessify()</translation>
    </message>
    <message>
        <source>missing terminating delimiter for callout with string argument</source>
        <translation>saknar avslutande avgränsare för callout med strängargument</translation>
    </message>
    <message>
        <source>unrecognized string delimiter follows (?C</source>
        <translation>okänd strängavgränsare följer (?C</translation>
    </message>
    <message>
        <source>using \C is disabled by the application</source>
        <translation>användning av \C är inaktiverat av programmet</translation>
    </message>
    <message>
        <source>(?| and/or (?J: or (?x: parentheses are too deeply nested</source>
        <translation>(?| och/eller (?J: eller (?x: parentes är för djupt nästlad</translation>
    </message>
    <message>
        <source>using \C is disabled in this PCRE2 library</source>
        <translation>användning av \C är inaktiverat i detta PCRE2-bibliotek</translation>
    </message>
    <message>
        <source>regular expression is too complicated</source>
        <translation>reguljärt uttryck är för komplicerat</translation>
    </message>
    <message>
        <source>lookbehind assertion is too long</source>
        <translation>lookbehind-assertion är för lång</translation>
    </message>
    <message>
        <source>pattern string is longer than the limit set by the application</source>
        <translation>mönstersträng är längre än gränsen inställd av programmet</translation>
    </message>
    <message>
        <source>internal error: unknown code in parsed pattern</source>
        <translation>internt fel: okänd kod i tolkat mönster</translation>
    </message>
    <message>
        <source>internal error: bad code value in parsed_skip()</source>
        <translation>internt fel: felaktigt kodvärde i parsed_skip()</translation>
    </message>
    <message>
        <source>PCRE2_EXTRA_ALLOW_SURROGATE_ESCAPES is not allowed in UTF-16 mode</source>
        <translation>PCRE2_EXTRA_ALLOW_SURROGATE_ESCAPES tillåts inte i UTF-16-läge</translation>
    </message>
    <message>
        <source>invalid option bits with PCRE2_LITERAL</source>
        <translation>ogiltiga option-bitar med PCRE2_LITERAL</translation>
    </message>
    <message>
        <source>\N{U+dddd} is supported only in Unicode (UTF) mode</source>
        <translation>\N{U+dddd} stöds endast i Unicode-läge (UTF)</translation>
    </message>
    <message>
        <source>invalid hyphen in option setting</source>
        <translation>ogiltigt bindestreck i option-inställning</translation>
    </message>
    <message>
        <source>(*alpha_assertion) not recognized</source>
        <translation>(*alpha_assertion) kändes inte igen</translation>
    </message>
    <message>
        <source>script runs require Unicode support, which this version of PCRE2 does not have</source>
        <translation>skriptkörningar kräver Unicode-stöd, vilket denna version av PCRE2 inte har</translation>
    </message>
    <message>
        <source>too many capturing groups (maximum 65535)</source>
        <translation>för många fångade grupper (maximalt 65535)</translation>
    </message>
    <message>
        <source>atomic assertion expected after (?( or (?(?C)</source>
        <translation>atomic assertion förväntades efter (?( eller (?(?C)</translation>
    </message>
    <message>
        <source>no match</source>
        <translation>ingen matchning</translation>
    </message>
    <message>
        <source>partial match</source>
        <translation>delvis matchning</translation>
    </message>
    <message>
        <source>UTF-8 error: 1 byte missing at end</source>
        <translation>UTF-8-fel: 1 byte saknas på slutet</translation>
    </message>
    <message>
        <source>UTF-8 error: 2 bytes missing at end</source>
        <translation>UTF-8-fel: 2 bytes saknas på slutet</translation>
    </message>
    <message>
        <source>UTF-8 error: 3 bytes missing at end</source>
        <translation>UTF-8-fel: 3 bytes saknas på slutet</translation>
    </message>
    <message>
        <source>UTF-8 error: 4 bytes missing at end</source>
        <translation>UTF-8-fel: 4 bytes saknas på slutet</translation>
    </message>
    <message>
        <source>UTF-8 error: 5 bytes missing at end</source>
        <translation>UTF-8-fel: 5 bytes saknas på slutet</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 2 top bits not 0x80</source>
        <translation>UTF-8-fel: byte 2 top bits inte 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 3 top bits not 0x80</source>
        <translation>UTF-8-fel: byte 3 top bits inte 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 4 top bits not 0x80</source>
        <translation>UTF-8-fel: byte 4 top bits inte 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 5 top bits not 0x80</source>
        <translation>UTF-8-fel: byte 5 top bits inte 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 6 top bits not 0x80</source>
        <translation>UTF-8-fel: byte 6 top bits inte 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: 5-byte character is not allowed (RFC 3629)</source>
        <translation>UTF-8-fel: 5-byte-tecken tillåts inte (RFC 3629)</translation>
    </message>
    <message>
        <source>UTF-8 error: 6-byte character is not allowed (RFC 3629)</source>
        <translation>UTF-8-fel: 6-byte-tecken tillåts inte (RFC 3629)</translation>
    </message>
    <message>
        <source>UTF-8 error: code points greater than 0x10ffff are not defined</source>
        <translation>UTF-8-fel: kodpunkter större än 0x10ffff är inte definierade</translation>
    </message>
    <message>
        <source>UTF-8 error: code points 0xd800-0xdfff are not defined</source>
        <translation>UTF-8-fel: kodpunkterna 0xd800-0xdfff är inte definierade</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 2-byte sequence</source>
        <translation>UTF-8-fel: overlong 2-byte-sekvens</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 3-byte sequence</source>
        <translation>UTF-8-fel: overlong 3-byte-sekvens</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 4-byte sequence</source>
        <translation>UTF-8-fel: overlong 4-byte-sekvens</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 5-byte sequence</source>
        <translation>UTF-8-fel: overlong 5-byte-sekvens</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 6-byte sequence</source>
        <translation>UTF-8-fel: overlong 6-byte-sekvens</translation>
    </message>
    <message>
        <source>UTF-8 error: isolated byte with 0x80 bit set</source>
        <translation>UTF-8-fel: isolerad byte med 0x80 bit inställd</translation>
    </message>
    <message>
        <source>UTF-8 error: illegal byte (0xfe or 0xff)</source>
        <translation>UTF-8-fel: otillåten byte (0xfe eller 0xff)</translation>
    </message>
    <message>
        <source>UTF-16 error: missing low surrogate at end</source>
        <translation>UTF-16-fel: saknar låg surrogat på slutet</translation>
    </message>
    <message>
        <source>UTF-16 error: invalid low surrogate</source>
        <translation>UTF-16-fel: ogiltig låg surrogat</translation>
    </message>
    <message>
        <source>UTF-16 error: isolated low surrogate</source>
        <translation>UTF-16-fel: isolerad låg surrogat</translation>
    </message>
    <message>
        <source>UTF-32 error: code points 0xd800-0xdfff are not defined</source>
        <translation>UTF-32-fel: kodpunkterna 0xd800-0xdfff är inte definierade</translation>
    </message>
    <message>
        <source>UTF-32 error: code points greater than 0x10ffff are not defined</source>
        <translation>UTF-32-fel: kodpunkter större än 0x10ffff är inte definierade</translation>
    </message>
    <message>
        <source>bad data value</source>
        <translation>felaktigt datavärde</translation>
    </message>
    <message>
        <source>patterns do not all use the same character tables</source>
        <translation>mönstren använder inte alla samma teckentabeller</translation>
    </message>
    <message>
        <source>magic number missing</source>
        <translation>magic number saknas</translation>
    </message>
    <message>
        <source>pattern compiled in wrong mode: 8/16/32-bit error</source>
        <translation>mönstret kompilerat i felaktigt läge: 8/16/32-bitarsfel</translation>
    </message>
    <message>
        <source>bad offset value</source>
        <translation>felaktigt offset-värde</translation>
    </message>
    <message>
        <source>bad option value</source>
        <translation>felaktigt option-värde</translation>
    </message>
    <message>
        <source>invalid replacement string</source>
        <translation>ogiltig ersättningssträng</translation>
    </message>
    <message>
        <source>bad offset into UTF string</source>
        <translation>felaktig offset till UTF-sträng</translation>
    </message>
    <message>
        <source>callout error code</source>
        <translation>callout-felkod</translation>
    </message>
    <message>
        <source>invalid data in workspace for DFA restart</source>
        <translation>ogiltigt data i arbetsyta för DFA-omstart</translation>
    </message>
    <message>
        <source>too much recursion for DFA matching</source>
        <translation>för mycket rekursion för DFA-matchning</translation>
    </message>
    <message>
        <source>backreference condition or recursion test is not supported for DFA matching</source>
        <translation>backreference-villkor eller rekursionstest stöds inte för DFA-matchning</translation>
    </message>
    <message>
        <source>function is not supported for DFA matching</source>
        <translation>funktionen stöds inte för DFA-matchning</translation>
    </message>
    <message>
        <source>pattern contains an item that is not supported for DFA matching</source>
        <translation>mönster innehåller en post som inte stöds för DFA-matchning</translation>
    </message>
    <message>
        <source>workspace size exceeded in DFA matching</source>
        <translation>arbetsytans storlek överstigs i DFA-matchning</translation>
    </message>
    <message>
        <source>internal error - pattern overwritten?</source>
        <translation>internt fel - mönstret överskrivet?</translation>
    </message>
    <message>
        <source>bad JIT option</source>
        <translation>felaktigt JIT-alternativ</translation>
    </message>
    <message>
        <source>JIT stack limit reached</source>
        <translation>gräns för JIT-stack nåddes</translation>
    </message>
    <message>
        <source>match limit exceeded</source>
        <translation>matchningsgräns överstigen</translation>
    </message>
    <message>
        <source>no more memory</source>
        <translation>slut på minne</translation>
    </message>
    <message>
        <source>unknown substring</source>
        <translation>okänd understräng</translation>
    </message>
    <message>
        <source>non-unique substring name</source>
        <translation>icke-unikt understrängsnamn</translation>
    </message>
    <message>
        <source>NULL argument passed</source>
        <translation>NULL-argument skickades</translation>
    </message>
    <message>
        <source>nested recursion at the same subject position</source>
        <translation>nästlad rekursion på samma ämnesposition</translation>
    </message>
    <message>
        <source>matching depth limit exceeded</source>
        <translation>gräns för matchningsdjup överstigen</translation>
    </message>
    <message>
        <source>requested value is not available</source>
        <translation>begärt värde är inte tillgängligt</translation>
    </message>
    <message>
        <source>requested value is not set</source>
        <translation>begärt värde är inte inställt</translation>
    </message>
    <message>
        <source>offset limit set without PCRE2_USE_OFFSET_LIMIT</source>
        <translation>offset-gräns inställd utan PCRE2_USE_OFFSET_LIMIT</translation>
    </message>
    <message>
        <source>bad escape sequence in replacement string</source>
        <translation>felaktig escape-sekvens i ersättningssträng</translation>
    </message>
    <message>
        <source>expected closing curly bracket in replacement string</source>
        <translation>förväntade stängande klammerparentes i ersättningssträng</translation>
    </message>
    <message>
        <source>bad substitution in replacement string</source>
        <translation>felaktig ersättning i ersättningssträng</translation>
    </message>
    <message>
        <source>match with end before start or start moved backwards is not supported</source>
        <translation>matchning med slut före start eller start flyttad bakåt stöds inte</translation>
    </message>
    <message>
        <source>too many replacements (more than INT_MAX)</source>
        <translation>för många ersättningar (fler än INT_MAX)</translation>
    </message>
    <message>
        <source>bad serialized data</source>
        <translation>felaktigt serialiserat data</translation>
    </message>
    <message>
        <source>heap limit exceeded</source>
        <translation>heap-gräns överstegs</translation>
    </message>
    <message>
        <source>invalid syntax</source>
        <translation>ogiltig syntax</translation>
    </message>
    <message>
        <source>internal error - duplicate substitution match</source>
        <translation>internt fel - dubblett av ersättningsmatchning</translation>
    </message>
    <message>
        <source>PCRE2_MATCH_INVALID_UTF is not supported for DFA matching</source>
        <translation>PCRE2_MATCH_INVALID_UTF stöds inte för DFA-matchning</translation>
    </message>
    <message>
        <source>INTERNAL ERROR: invalid substring offset</source>
        <translation>INTERNT FEL: ogiltig substring-offset</translation>
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <source>Error opening database</source>
        <translation>Fel vid öppnade av databas</translation>
    </message>
    <message>
        <source>Error closing database</source>
        <translation>Fel vid stängning av databas</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Kunde inte påbörja transaktion</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Kunde inte verkställa transaktion</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Kunde inte rulla tillbaka transaktion</translation>
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <source>Unable to fetch row</source>
        <translation>Kunde inte hämta rad</translation>
    </message>
    <message>
        <source>No query</source>
        <translation>Ingen fråga</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Kunde inte köra villkor</translation>
    </message>
    <message>
        <source>Unable to execute multiple statements at a time</source>
        <translation>Kunde inte köra satsfråga på en gång</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>Kunde inte återställa villkor</translation>
    </message>
    <message>
        <source>Unable to bind parameters</source>
        <translation>Kunde inte binda parametrar</translation>
    </message>
    <message>
        <source>Parameter count mismatch</source>
        <translation>Parameterantal stämmer inte</translation>
    </message>
</context>
<context>
    <name>QSaveFile</name>
    <message>
        <source>Existing file %1 is not writable</source>
        <translation>Befintliga filen %1 är inte skrivbar</translation>
    </message>
    <message>
        <source>Filename refers to a directory</source>
        <translation>Filnamnet refererar till en katalog</translation>
    </message>
    <message>
        <source>QSaveFile cannot open &apos;%1&apos; without direct write fallback enabled.</source>
        <translation>QSaveFile kan inte öppna &quot;%1&quot; utan direktskrivning att falla tillbaka på är aktiverad.</translation>
    </message>
    <message>
        <source>Writing canceled by application</source>
        <translation>Skrivningen avbröts av programmet</translation>
    </message>
</context>
<context>
    <name>QScrollBar</name>
    <message>
        <source>Scroll here</source>
        <translation>Rulla här</translation>
    </message>
    <message>
        <source>Left edge</source>
        <translation>Vänsterkant</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Överkant</translation>
    </message>
    <message>
        <source>Right edge</source>
        <translation>Högerkant</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Nederkant</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Sida vänster</translation>
    </message>
    <message>
        <source>Page up</source>
        <translation>Sida uppåt</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Sida höger</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Sida nedåt</translation>
    </message>
    <message>
        <source>Scroll left</source>
        <translation>Rulla vänster</translation>
    </message>
    <message>
        <source>Scroll up</source>
        <translation>Rulla uppåt</translation>
    </message>
    <message>
        <source>Scroll right</source>
        <translation>Rulla höger</translation>
    </message>
    <message>
        <source>Scroll down</source>
        <translation>Rulla nedåt</translation>
    </message>
</context>
<context>
    <name>QSctpSocket</name>
    <message>
        <source>The remote host closed the connection</source>
        <translation>Fjärrvärden stängde anslutningen</translation>
    </message>
</context>
<context>
    <name>QSharedMemory</name>
    <message>
        <source>%1: unsupported key type</source>
        <translation>%1: nyckeltypen stöds inte</translation>
    </message>
    <message>
        <source>%1: unable to set key on lock (%2)</source>
        <translation>%1: kunde inte ställa in nyckel på låset (%2)</translation>
    </message>
    <message>
        <source>%1: create size is less then 0</source>
        <translation>%1: skapad storlek är mindre än 0</translation>
    </message>
    <message>
        <source>%1: unable to lock</source>
        <translation>%1: kunde inte låsa</translation>
    </message>
    <message>
        <source>%1: unable to unlock</source>
        <translation>%1: kunde inte låsa upp</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: behörighet nekad</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: finns redan</translation>
    </message>
    <message>
        <source>%1: doesn&apos;t exist</source>
        <translation>%1: finns inte</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: slut på resurser</translation>
    </message>
    <message>
        <source>%1: unknown error: %2</source>
        <translation>%1: okänt fel: %2</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: nyckeln är tom</translation>
    </message>
    <message>
        <source>%1: bad name</source>
        <translation>%1: felaktigt namn</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: kunde inte skapa nyckel</translation>
    </message>
    <message>
        <source>%1: system-imposed size restrictions</source>
        <translation>%1: storleksbegränsningar för systemet</translation>
    </message>
    <message>
        <source>%1: not attached</source>
        <translation>%1: inte ansluten</translation>
    </message>
    <message>
        <source>%1: invalid size</source>
        <translation>%1: ogiltig storlek</translation>
    </message>
    <message>
        <source>%1: key error</source>
        <translation>%1: nyckelfel</translation>
    </message>
    <message>
        <source>%1: size query failed</source>
        <translation>%1: storleksfråga misslyckades</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <source>Space</source>
        <extracomment>This and all following &quot;incomprehensible&quot; strings in QShortcut context are key names. Please use the localized names appearing on actual keyboards or whatever is commonly used.</extracomment>
        <translation>Mellanslag</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Tab</source>
        <translation>Tab</translation>
    </message>
    <message>
        <source>Backtab</source>
        <translation>Backtab</translation>
    </message>
    <message>
        <source>Backspace</source>
        <translation>Backsteg</translation>
    </message>
    <message>
        <source>Return</source>
        <translation>Return</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <source>Ins</source>
        <translation>Ins</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Print</translation>
    </message>
    <message>
        <source>SysReq</source>
        <translation>SysReq</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Hem</translation>
    </message>
    <message>
        <source>End</source>
        <translation>End</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Vänster</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Upp</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Höger</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Ned</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <source>CapsLock</source>
        <translation>CapsLock</translation>
    </message>
    <message>
        <source>NumLock</source>
        <translation>NumLock</translation>
    </message>
    <message>
        <source>ScrollLock</source>
        <translation>ScrollLock</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Bakåt</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Framåt</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <source>Volume Down</source>
        <translation>Sänk volym</translation>
    </message>
    <message>
        <source>Volume Mute</source>
        <translation>Volym tyst</translation>
    </message>
    <message>
        <source>Volume Up</source>
        <translation>Höj volym</translation>
    </message>
    <message>
        <source>Bass Boost</source>
        <translation>Förstärk bas</translation>
    </message>
    <message>
        <source>Bass Up</source>
        <translation>Höj bas</translation>
    </message>
    <message>
        <source>Bass Down</source>
        <translation>Sänk bas</translation>
    </message>
    <message>
        <source>Treble Up</source>
        <translation>Höj diskant</translation>
    </message>
    <message>
        <source>Treble Down</source>
        <translation>Sänk diskant</translation>
    </message>
    <message>
        <source>Media Play</source>
        <translation>Media spela upp</translation>
    </message>
    <message>
        <source>Media Stop</source>
        <translation>Media stopp</translation>
    </message>
    <message>
        <source>Media Previous</source>
        <translation>Media föregående</translation>
    </message>
    <message>
        <source>Media Next</source>
        <translation>Media nästa</translation>
    </message>
    <message>
        <source>Media Record</source>
        <translation>Media spela in</translation>
    </message>
    <message>
        <source>Media Pause</source>
        <extracomment>Media player pause button</extracomment>
        <translation>Pausa media</translation>
    </message>
    <message>
        <source>Toggle Media Play/Pause</source>
        <extracomment>Media player button to toggle between playing and paused</extracomment>
        <translation>Växla media spela upp/paus</translation>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Hemsida</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Favoriter</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <source>Standby</source>
        <translation>Avvakta</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation>Öppna url</translation>
    </message>
    <message>
        <source>Launch Mail</source>
        <translation>Starta e-post</translation>
    </message>
    <message>
        <source>Launch Media</source>
        <translation>Starta media</translation>
    </message>
    <message>
        <source>Launch (0)</source>
        <translation>Starta (0)</translation>
    </message>
    <message>
        <source>Launch (1)</source>
        <translation>Starta (1)</translation>
    </message>
    <message>
        <source>Launch (2)</source>
        <translation>Starta (2)</translation>
    </message>
    <message>
        <source>Launch (3)</source>
        <translation>Starta (3)</translation>
    </message>
    <message>
        <source>Launch (4)</source>
        <translation>Starta (4)</translation>
    </message>
    <message>
        <source>Launch (5)</source>
        <translation>Starta (5)</translation>
    </message>
    <message>
        <source>Launch (6)</source>
        <translation>Starta (6)</translation>
    </message>
    <message>
        <source>Launch (7)</source>
        <translation>Starta (7)</translation>
    </message>
    <message>
        <source>Launch (8)</source>
        <translation>Starta (8)</translation>
    </message>
    <message>
        <source>Launch (9)</source>
        <translation>Starta (9)</translation>
    </message>
    <message>
        <source>Launch (A)</source>
        <translation>Starta (A)</translation>
    </message>
    <message>
        <source>Launch (B)</source>
        <translation>Starta (B)</translation>
    </message>
    <message>
        <source>Launch (C)</source>
        <translation>Starta (C)</translation>
    </message>
    <message>
        <source>Launch (D)</source>
        <translation>Starta (D)</translation>
    </message>
    <message>
        <source>Launch (E)</source>
        <translation>Starta (E)</translation>
    </message>
    <message>
        <source>Launch (F)</source>
        <translation>Starta (F)</translation>
    </message>
    <message>
        <source>Launch (G)</source>
        <translation>Starta (G)</translation>
    </message>
    <message>
        <source>Launch (H)</source>
        <translation>Starta (H)</translation>
    </message>
    <message>
        <source>Monitor Brightness Up</source>
        <translation>Monitor ljusstyrka upp</translation>
    </message>
    <message>
        <source>Monitor Brightness Down</source>
        <translation>Monitor ljusstyrka ner</translation>
    </message>
    <message>
        <source>Keyboard Light On/Off</source>
        <translation>Tangentbord ljus på/av</translation>
    </message>
    <message>
        <source>Keyboard Brightness Up</source>
        <translation>Tangentbord ljusstyrka upp</translation>
    </message>
    <message>
        <source>Keyboard Brightness Down</source>
        <translation>Tangentbord ljusstyrka ner</translation>
    </message>
    <message>
        <source>Power Off</source>
        <translation>Stäng av</translation>
    </message>
    <message>
        <source>Wake Up</source>
        <translation>Vakna</translation>
    </message>
    <message>
        <source>Eject</source>
        <translation>Mata ut</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Skärmsläckare</translation>
    </message>
    <message>
        <source>WWW</source>
        <translation>WWW</translation>
    </message>
    <message>
        <source>Sleep</source>
        <translation>Sov</translation>
    </message>
    <message>
        <source>LightBulb</source>
        <translation>Glödlampa</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Affär</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historik</translation>
    </message>
    <message>
        <source>Add Favorite</source>
        <translation>Lägg till favorit</translation>
    </message>
    <message>
        <source>Hot Links</source>
        <translation>Bra länkar</translation>
    </message>
    <message>
        <source>Adjust Brightness</source>
        <translation>Justera ljusstyrka</translation>
    </message>
    <message>
        <source>Finance</source>
        <translation>Finans</translation>
    </message>
    <message>
        <source>Community</source>
        <translation>Gemenskap</translation>
    </message>
    <message>
        <source>Media Rewind</source>
        <translation>Media spola tillbaka</translation>
    </message>
    <message>
        <source>Back Forward</source>
        <translation>Bakåt framåt</translation>
    </message>
    <message>
        <source>Application Left</source>
        <translation>Program vänster</translation>
    </message>
    <message>
        <source>Application Right</source>
        <translation>Program höger</translation>
    </message>
    <message>
        <source>Book</source>
        <translation>Bok</translation>
    </message>
    <message>
        <source>CD</source>
        <translation>CD</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>Miniräknare</translation>
    </message>
    <message>
        <source>Calendar</source>
        <translation>Kalender</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Töm</translation>
    </message>
    <message>
        <source>Clear Grab</source>
        <translation>Töm fångst</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <source>Adjust contrast</source>
        <translation>Justera kontrast</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Klipp ut</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Skärm</translation>
    </message>
    <message>
        <source>DOS</source>
        <translation>DOS</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <source>Spreadsheet</source>
        <translation>Kalkylark</translation>
    </message>
    <message>
        <source>Browser</source>
        <translation>Webbläsare</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Spel</translation>
    </message>
    <message>
        <source>Go</source>
        <translation>Gå</translation>
    </message>
    <message>
        <source>iTouch</source>
        <translation>iTouch</translation>
    </message>
    <message>
        <source>Logoff</source>
        <translation>Logga ut</translation>
    </message>
    <message>
        <source>Market</source>
        <translation>Marknad</translation>
    </message>
    <message>
        <source>Meeting</source>
        <translation>Möte</translation>
    </message>
    <message>
        <source>Memo</source>
        <translation>Memo</translation>
    </message>
    <message>
        <source>Keyboard Menu</source>
        <translation>Tangentbordsmeny</translation>
    </message>
    <message>
        <source>Menu PB</source>
        <translation>Meny PB</translation>
    </message>
    <message>
        <source>My Sites</source>
        <translation>Mina platser</translation>
    </message>
    <message>
        <source>News</source>
        <translation>Nyheter</translation>
    </message>
    <message>
        <source>Home Office</source>
        <translation>Hemmakontor</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Klistra in</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>Svara</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <source>Rotate Windows</source>
        <translation>Rotera fönster</translation>
    </message>
    <message>
        <source>Rotation PB</source>
        <translation>Rotation PB</translation>
    </message>
    <message>
        <source>Rotation KB</source>
        <translation>Rotation KB</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Skicka</translation>
    </message>
    <message>
        <source>Spellchecker</source>
        <translation>Stavningskontroll</translation>
    </message>
    <message>
        <source>Split Screen</source>
        <translation>Delad skärm</translation>
    </message>
    <message>
        <source>Support</source>
        <translation>Support</translation>
    </message>
    <message>
        <source>Task Panel</source>
        <translation>Åtgärdspanel</translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation>Terminal</translation>
    </message>
    <message>
        <source>To-do list</source>
        <translation>Att-göra-lista</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Verktyg</translation>
    </message>
    <message>
        <source>Travel</source>
        <translation>Resa</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Word Processor</source>
        <translation>Ordbehandlare</translation>
    </message>
    <message>
        <source>XFer</source>
        <translation>XFer</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Zooma in</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Zooma ut</translation>
    </message>
    <message>
        <source>Away</source>
        <translation>Borta</translation>
    </message>
    <message>
        <source>Messenger</source>
        <translation>Messenger</translation>
    </message>
    <message>
        <source>WebCam</source>
        <translation>Webbkamera</translation>
    </message>
    <message>
        <source>Mail Forward</source>
        <translation>Vidarebefordra e-post</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Musik</translation>
    </message>
    <message>
        <source>Battery</source>
        <translation>Batteri</translation>
    </message>
    <message>
        <source>Bluetooth</source>
        <translation>Bluetooth</translation>
    </message>
    <message>
        <source>Wireless</source>
        <translation>Trådlös</translation>
    </message>
    <message>
        <source>Ultra Wide Band</source>
        <translation>Ultra Wide Band</translation>
    </message>
    <message>
        <source>Media Fast Forward</source>
        <translation>Media snabbspola</translation>
    </message>
    <message>
        <source>Audio Repeat</source>
        <translation>Ljud upprepa</translation>
    </message>
    <message>
        <source>Audio Random Play</source>
        <translation>Ljud slumpmässig uppspelning</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Undertext</translation>
    </message>
    <message>
        <source>Audio Cycle Track</source>
        <translation>Ljud växla spår</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Tid</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation>Viloläge</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Visa</translation>
    </message>
    <message>
        <source>Top Menu</source>
        <translation>Toppmeny</translation>
    </message>
    <message>
        <source>Power Down</source>
        <translation>Stäng ner</translation>
    </message>
    <message>
        <source>Suspend</source>
        <translation>Vänteläge</translation>
    </message>
    <message>
        <source>Microphone Mute</source>
        <translation>Mikrofon tyst</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Röd</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Grön</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Gul</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Blå</translation>
    </message>
    <message>
        <source>Channel Up</source>
        <translation>Kanal upp</translation>
    </message>
    <message>
        <source>Channel Down</source>
        <translation>Kanal ner</translation>
    </message>
    <message>
        <source>Guide</source>
        <translation>Guide</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <source>Microphone Volume Up</source>
        <translation>Mikrofon volym upp</translation>
    </message>
    <message>
        <source>Microphone Volume Down</source>
        <translation>Mikrofon volym ner</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation>Tangentbord</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Ny</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Sök</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Ångra</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Gör om</translation>
    </message>
    <message>
        <source>Print Screen</source>
        <translation>Print Screen</translation>
    </message>
    <message>
        <source>Page Up</source>
        <translation>Page Up</translation>
    </message>
    <message>
        <source>Page Down</source>
        <translation>Page Down</translation>
    </message>
    <message>
        <source>Caps Lock</source>
        <translation>Caps Lock</translation>
    </message>
    <message>
        <source>Num Lock</source>
        <translation>Num Lock</translation>
    </message>
    <message>
        <source>Number Lock</source>
        <translation>Number Lock</translation>
    </message>
    <message>
        <source>Scroll Lock</source>
        <translation>Scroll Lock</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Insert</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <source>System Request</source>
        <translation>System Request</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Välj</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <source>Context1</source>
        <translation>Sammanhang1</translation>
    </message>
    <message>
        <source>Context2</source>
        <translation>Sammanhang2</translation>
    </message>
    <message>
        <source>Context3</source>
        <translation>Sammanhang3</translation>
    </message>
    <message>
        <source>Context4</source>
        <translation>Sammanhang4</translation>
    </message>
    <message>
        <source>Call</source>
        <extracomment>Button to start a call (note: a separate button is used to end the call)</extracomment>
        <translation>Ring upp</translation>
    </message>
    <message>
        <source>Hangup</source>
        <extracomment>Button to end a call (note: a separate button is used to start the call)</extracomment>
        <translation>Lägg på</translation>
    </message>
    <message>
        <source>Toggle Call/Hangup</source>
        <extracomment>Button that will hang up if we&apos;re in call, or make a call if we&apos;re not.</extracomment>
        <translation>Växla ring upp/lägg på</translation>
    </message>
    <message>
        <source>Flip</source>
        <translation>Vänd</translation>
    </message>
    <message>
        <source>Voice Dial</source>
        <extracomment>Button to trigger voice dialing</extracomment>
        <translation>Ring röstsamtal</translation>
    </message>
    <message>
        <source>Last Number Redial</source>
        <extracomment>Button to redial the last number called</extracomment>
        <translation>Ring upp senaste nummer</translation>
    </message>
    <message>
        <source>Camera Shutter</source>
        <extracomment>Button to trigger the camera shutter (take a picture)</extracomment>
        <translation>Kameraslutare</translation>
    </message>
    <message>
        <source>Camera Focus</source>
        <extracomment>Button to focus the camera</extracomment>
        <translation>Kamerafokus</translation>
    </message>
    <message>
        <source>Kanji</source>
        <translation>Kanji</translation>
    </message>
    <message>
        <source>Muhenkan</source>
        <translation>Muhenkan</translation>
    </message>
    <message>
        <source>Henkan</source>
        <translation>Henkan</translation>
    </message>
    <message>
        <source>Romaji</source>
        <translation>Romaji</translation>
    </message>
    <message>
        <source>Hiragana</source>
        <translation>Hiragana</translation>
    </message>
    <message>
        <source>Katakana</source>
        <translation>Katakana</translation>
    </message>
    <message>
        <source>Hiragana Katakana</source>
        <translation>Hiragana Katakana</translation>
    </message>
    <message>
        <source>Zenkaku</source>
        <translation>Zenkaku</translation>
    </message>
    <message>
        <source>Hankaku</source>
        <translation>Hankaku</translation>
    </message>
    <message>
        <source>Zenkaku Hankaku</source>
        <translation>Zenkaku Hankaku</translation>
    </message>
    <message>
        <source>Touroku</source>
        <translation>Touroku</translation>
    </message>
    <message>
        <source>Massyo</source>
        <translation>Massyo</translation>
    </message>
    <message>
        <source>Kana Lock</source>
        <translation>Kana lås</translation>
    </message>
    <message>
        <source>Kana Shift</source>
        <translation>Kana skift</translation>
    </message>
    <message>
        <source>Eisu Shift</source>
        <translation>Eisu skift</translation>
    </message>
    <message>
        <source>Eisu toggle</source>
        <translation>Eisu växla</translation>
    </message>
    <message>
        <source>Code input</source>
        <translation>Kodinmatning</translation>
    </message>
    <message>
        <source>Multiple Candidate</source>
        <translation>Flera kandidat</translation>
    </message>
    <message>
        <source>Previous Candidate</source>
        <translation>Föregående kandidat</translation>
    </message>
    <message>
        <source>Hangul</source>
        <translation>Hangul</translation>
    </message>
    <message>
        <source>Hangul Start</source>
        <translation>Hangul Start</translation>
    </message>
    <message>
        <source>Hangul End</source>
        <translation>Hangul slut</translation>
    </message>
    <message>
        <source>Hangul Hanja</source>
        <translation>Hangul Hanja</translation>
    </message>
    <message>
        <source>Hangul Jamo</source>
        <translation>Hangul Jamo</translation>
    </message>
    <message>
        <source>Hangul Romaja</source>
        <translation>Hangul Romaja</translation>
    </message>
    <message>
        <source>Hangul Jeonja</source>
        <translation>Hangul Jeonja</translation>
    </message>
    <message>
        <source>Hangul Banja</source>
        <translation>Hangul Banja</translation>
    </message>
    <message>
        <source>Hangul PreHanja</source>
        <translation>Hangul PreHanja</translation>
    </message>
    <message>
        <source>Hangul PostHanja</source>
        <translation>Hangul PostHanja</translation>
    </message>
    <message>
        <source>Hangul Special</source>
        <translation>Hangul Special</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Skrivare</translation>
    </message>
    <message>
        <source>Execute</source>
        <translation>Kör</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Spela upp</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zooma</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Avsluta</translation>
    </message>
    <message>
        <source>Touchpad Toggle</source>
        <translation>Pekplatta växla</translation>
    </message>
    <message>
        <source>Touchpad On</source>
        <translation>Pekplatta på</translation>
    </message>
    <message>
        <source>Touchpad Off</source>
        <translation>Pekplatta av</translation>
    </message>
    <message>
        <source>Shift</source>
        <translation>Skift</translation>
    </message>
    <message>
        <source>Control</source>
        <translation>Control</translation>
    </message>
    <message>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <source>Num</source>
        <translation>Num</translation>
    </message>
    <message>
        <source>+</source>
        <extracomment>Key separator in shortcut string</extracomment>
        <translation>+</translation>
    </message>
    <message>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
</context>
<context>
    <name>QSocks5SocketEngine</name>
    <message>
        <source>Connection to proxy refused</source>
        <translation>Anslutning till proxyn nekades</translation>
    </message>
    <message>
        <source>Connection to proxy closed prematurely</source>
        <translation>Anslutning till proxyn stängdes i förtid</translation>
    </message>
    <message>
        <source>Proxy host not found</source>
        <translation>Proxyvärden hittades inte</translation>
    </message>
    <message>
        <source>Connection to proxy timed out</source>
        <translation>Anslutning till proxyn översteg tidsgränsen</translation>
    </message>
    <message>
        <source>Proxy authentication failed</source>
        <translation>Proxyautentisering misslyckades</translation>
    </message>
    <message>
        <source>Proxy authentication failed: %1</source>
        <translation>Proxyautentisering misslyckades: %1</translation>
    </message>
    <message>
        <source>SOCKS version 5 protocol error</source>
        <translation>Protokollfel i SOCKS version 5</translation>
    </message>
    <message>
        <source>General SOCKSv5 server failure</source>
        <translation>Allmänt serverfel för SOCKSv5</translation>
    </message>
    <message>
        <source>Connection not allowed by SOCKSv5 server</source>
        <translation>Anslutning tillåts inte av SOCKSv5-server</translation>
    </message>
    <message>
        <source>TTL expired</source>
        <translation>TTL överstegs</translation>
    </message>
    <message>
        <source>SOCKSv5 command not supported</source>
        <translation>SOCKSv5-kommando stöds inte</translation>
    </message>
    <message>
        <source>Address type not supported</source>
        <translation>Adresstypen stöds inte</translation>
    </message>
    <message>
        <source>Unknown SOCKSv5 proxy error code 0x%1</source>
        <translation>Okänd SOCKSv5-proxyfelkod 0x%1</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>Tidsgräns för nätverksåtgärd överstegs</translation>
    </message>
</context>
<context>
    <name>QSpiAccessibleBridge</name>
    <message>
        <source>invalid role</source>
        <extracomment>Role of an accessible object - the object is in an invalid state or could not be constructed</extracomment>
        <translation>ogiltig roll</translation>
    </message>
    <message>
        <source>title bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>titelrad</translation>
    </message>
    <message>
        <source>menu bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>menyrad</translation>
    </message>
    <message>
        <source>scroll bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>rullningslist</translation>
    </message>
    <message>
        <source>grip</source>
        <extracomment>Role of an accessible object - the grip is usually used for resizing another object</extracomment>
        <translation>grepp</translation>
    </message>
    <message>
        <source>sound</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>ljud</translation>
    </message>
    <message>
        <source>cursor</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>markör</translation>
    </message>
    <message>
        <source>text caret</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>insättningstecken</translation>
    </message>
    <message>
        <source>alert message</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>larmmeddelande</translation>
    </message>
    <message>
        <source>frame</source>
        <extracomment>Role of an accessible object: a window with frame and title</extracomment>
        <translation>ram</translation>
    </message>
    <message>
        <source>filler</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>utfyllnad</translation>
    </message>
    <message>
        <source>popup menu</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>popupmeny</translation>
    </message>
    <message>
        <source>menu item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>menypost</translation>
    </message>
    <message>
        <source>tool tip</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>verktygstips</translation>
    </message>
    <message>
        <source>application</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>program</translation>
    </message>
    <message>
        <source>document</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>dokument</translation>
    </message>
    <message>
        <source>panel</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>panel</translation>
    </message>
    <message>
        <source>chart</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>diagram</translation>
    </message>
    <message>
        <source>dialog</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>dialogruta</translation>
    </message>
    <message>
        <source>separator</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>avgränsare</translation>
    </message>
    <message>
        <source>tool bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>verktygsrad</translation>
    </message>
    <message>
        <source>status bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>statusrad</translation>
    </message>
    <message>
        <source>table</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>tabell</translation>
    </message>
    <message>
        <source>column header</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>kolumnhuvud</translation>
    </message>
    <message>
        <source>row header</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>radhuvud</translation>
    </message>
    <message>
        <source>column</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>kolumn</translation>
    </message>
    <message>
        <source>row</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>rad</translation>
    </message>
    <message>
        <source>cell</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>cell</translation>
    </message>
    <message>
        <source>link</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>länk</translation>
    </message>
    <message>
        <source>help balloon</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>hjälpballong</translation>
    </message>
    <message>
        <source>assistant</source>
        <extracomment>Role of an accessible object - a helper dialog</extracomment>
        <translation>assistent</translation>
    </message>
    <message>
        <source>list</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>lista</translation>
    </message>
    <message>
        <source>list item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>listpost</translation>
    </message>
    <message>
        <source>tree</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>träd</translation>
    </message>
    <message>
        <source>tree item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>trädpost</translation>
    </message>
    <message>
        <source>page tab</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>sidflik</translation>
    </message>
    <message>
        <source>property page</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>egenskapssida</translation>
    </message>
    <message>
        <source>indicator</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>indikator</translation>
    </message>
    <message>
        <source>graphic</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>grafik</translation>
    </message>
    <message>
        <source>label</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>etikett</translation>
    </message>
    <message>
        <source>text</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>text</translation>
    </message>
    <message>
        <source>push button</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>tryckknapp</translation>
    </message>
    <message>
        <source>check box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>kryssruta</translation>
    </message>
    <message>
        <source>switch</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>växel</translation>
    </message>
    <message>
        <source>radio button</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>radioknapp</translation>
    </message>
    <message>
        <source>combo box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>kombinationsruta</translation>
    </message>
    <message>
        <source>progress bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>förloppsmätare</translation>
    </message>
    <message>
        <source>dial</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>snurrbox</translation>
    </message>
    <message>
        <source>hotkey field</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>snabbtangentsfält</translation>
    </message>
    <message>
        <source>slider</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>draglist</translation>
    </message>
    <message>
        <source>spin box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>snurrbox</translation>
    </message>
    <message>
        <source>canvas</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>kanvas</translation>
    </message>
    <message>
        <source>animation</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>animering</translation>
    </message>
    <message>
        <source>equation</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation></translation>
    </message>
    <message>
        <source>button with drop down</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>knapp med rullgardin</translation>
    </message>
    <message>
        <source>button menu</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>knappmeny</translation>
    </message>
    <message>
        <source>button with drop down grid</source>
        <extracomment>Role of an accessible object - a button that expands a grid.</extracomment>
        <translation>knapp med rullgardinsrutnät</translation>
    </message>
    <message>
        <source>space</source>
        <extracomment>Role of an accessible object - blank space between other objects.</extracomment>
        <translation>tomrum</translation>
    </message>
    <message>
        <source>page tab list</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>sidflikslista</translation>
    </message>
    <message>
        <source>clock</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>klocka</translation>
    </message>
    <message>
        <source>splitter</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>delare</translation>
    </message>
    <message>
        <source>layered pane</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>skiktad panel</translation>
    </message>
    <message>
        <source>web document</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>webbdokument</translation>
    </message>
    <message>
        <source>paragraph</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>paragraf</translation>
    </message>
    <message>
        <source>section</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>sektion</translation>
    </message>
    <message>
        <source>color chooser</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>färgväljare</translation>
    </message>
    <message>
        <source>footer</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>sidfot</translation>
    </message>
    <message>
        <source>form</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>formulär</translation>
    </message>
    <message>
        <source>heading</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>rubrik</translation>
    </message>
    <message>
        <source>note</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>anteckning</translation>
    </message>
    <message>
        <source>complementary content</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>kompletterande innehåll</translation>
    </message>
    <message>
        <source>terminal</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>terminal</translation>
    </message>
    <message>
        <source>desktop</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>skrivbord</translation>
    </message>
    <message>
        <source>notification</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>avisering</translation>
    </message>
    <message>
        <source>block quote</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>blockcitat</translation>
    </message>
    <message>
        <source>unknown</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>okänt</translation>
    </message>
</context>
<context>
    <name>QSslDiffieHellmanParameter</name>
    <message>
        <source>No error</source>
        <translation>Inget fel</translation>
    </message>
    <message>
        <source>Invalid input data</source>
        <translation>Ogiltig inmatningsdata</translation>
    </message>
    <message>
        <source>The given Diffie-Hellman parameters are deemed unsafe</source>
        <translation>Angivna Diffie-Hellman-parametrar anses vara osäkra</translation>
    </message>
</context>
<context>
    <name>QSslSocket</name>
    <message>
        <source>No error</source>
        <translation>Inget fel</translation>
    </message>
    <message>
        <source>The issuer certificate could not be found</source>
        <translation>Utfärdarcertifikatet kunde inte hittas</translation>
    </message>
    <message>
        <source>The certificate signature could not be decrypted</source>
        <translation>Certifikatsignaturen kunde inte dekrypteras</translation>
    </message>
    <message>
        <source>The public key in the certificate could not be read</source>
        <translation>Publika nyckeln i certifikatet kunde inte läsas</translation>
    </message>
    <message>
        <source>The signature of the certificate is invalid</source>
        <translation>Signaturen för certifikatet är ogiltig</translation>
    </message>
    <message>
        <source>The certificate is not yet valid</source>
        <translation>Certifikatet är ännu inte giltigt</translation>
    </message>
    <message>
        <source>The certificate has expired</source>
        <translation>Certifikatet har gått ut</translation>
    </message>
    <message>
        <source>The certificate&apos;s notBefore field contains an invalid time</source>
        <translation>Certifikatets notBefore-fält innehåller en ogiltig tid</translation>
    </message>
    <message>
        <source>The certificate&apos;s notAfter field contains an invalid time</source>
        <translation>Certifikatets notAfter-fält innehåller en ogiltig tid</translation>
    </message>
    <message>
        <source>The certificate is self-signed, and untrusted</source>
        <translation>Certifikatet är självsignerat och inte pålitligt</translation>
    </message>
    <message>
        <source>The root certificate of the certificate chain is self-signed, and untrusted</source>
        <translation>Rotcertifikatet för certifikatskedjan är självsignerat och inte pålitligt</translation>
    </message>
    <message>
        <source>The issuer certificate of a locally looked up certificate could not be found</source>
        <translation>Utfärdarcertifikatet för ett lokalt uppslaget certifikat kunde inte hittas</translation>
    </message>
    <message>
        <source>No certificates could be verified</source>
        <translation>Inga certifikat kunde verifieras</translation>
    </message>
    <message>
        <source>One of the CA certificates is invalid</source>
        <translation>Ett av CA-certifikaten var ogiltigt</translation>
    </message>
    <message>
        <source>The basicConstraints path length parameter has been exceeded</source>
        <translation>Sökvägslängden för parametern basicConstraints har överstigits</translation>
    </message>
    <message>
        <source>The supplied certificate is unsuitable for this purpose</source>
        <translation>Angivet certifikat är inte lämpligt för detta syfte</translation>
    </message>
    <message>
        <source>The root CA certificate is not trusted for this purpose</source>
        <translation>Rot-CA-certifikatet är inte pålitligt för detta syfte</translation>
    </message>
    <message>
        <source>The root CA certificate is marked to reject the specified purpose</source>
        <translation>Rot-CA-certifikatet är markerat för att neka angivet syfte</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its subject name did not match the issuer name of the current certificate</source>
        <translation>Aktuellt kandidatutfärdarcertifikat nekades därför att dess ämnesrad inte matchade utfärdarnamnet för det aktuella certifikatet</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its issuer name and serial number was present and did not match the authority key identifier of the current certificate</source>
        <translation>Aktuella kandidatutfärdarens certifikat nekades därför att dess utfärdarnamn och serienummer fanns där och matchade inte utfärdarens nyckelidentifierare för det aktuella certifikatet</translation>
    </message>
    <message>
        <source>The peer did not present any certificate</source>
        <translation>Motparten presenterade inte något certifikat</translation>
    </message>
    <message>
        <source>The host name did not match any of the valid hosts for this certificate</source>
        <translation>Värdnamnet matchade inte någon av de giltiga värdar för detta certifikat</translation>
    </message>
    <message>
        <source>The peer certificate is blacklisted</source>
        <translation>Motpartens certifikat är svartlistat</translation>
    </message>
    <message>
        <source>No OCSP status response found</source>
        <translation>Inget OCSP-statussvar hittades</translation>
    </message>
    <message>
        <source>The OCSP status request had invalid syntax</source>
        <translation>Begäran om OCSP-status har en ogiltig syntax</translation>
    </message>
    <message>
        <source>OCSP response contains an unexpected number of SingleResponse structures</source>
        <translation>OCSP-svaret innehåller ett oväntat antal SingleResponse-strukturer</translation>
    </message>
    <message>
        <source>OCSP responder reached an inconsistent internal state</source>
        <translation>OCSP-besvararen nådde ett inkonsistent internt tillstånd</translation>
    </message>
    <message>
        <source>OCSP responder was unable to return a status for the requested certificate</source>
        <translation>OCSP-besvararen kunde inte returnera en status för det begärda certifikatet</translation>
    </message>
    <message>
        <source>The server requires the client to sign the OCSP request in order to construct a response</source>
        <translation>Servern kräver att klienten signerar OCSP-begäran för att kunna konstruera ett svar</translation>
    </message>
    <message>
        <source>The client is not authorized to request OCSP status from this server</source>
        <translation>Klienten är inte auktoriserad att begära OCSP-status från denna server</translation>
    </message>
    <message>
        <source>OCSP responder&apos;s identity cannot be verified</source>
        <translation>OCSP-besvararens identitet kan inte verifieras</translation>
    </message>
    <message>
        <source>The identity of a certificate in an OCSP response cannot be established</source>
        <translation>Identiteten för ett certifikat i ett OCSP-svar kan inte etableras</translation>
    </message>
    <message>
        <source>The certificate status response has expired</source>
        <translation>Certifikatets statussvar har gått över tidsgränsen</translation>
    </message>
    <message>
        <source>The certificate&apos;s status is unknown</source>
        <translation>Certifikatets status är okänt</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
    <message>
        <source>TLS initialization failed</source>
        <translation>TLS-initiering misslyckades</translation>
    </message>
    <message>
        <source>Attempted to use an unsupported protocol.</source>
        <translation>Försökte använda ett protokoll som inte stöds.</translation>
    </message>
    <message>
        <source>Error when setting the OpenSSL configuration (%1)</source>
        <translation>Fel vid inställning av OpenSSL-konfigurationen (%1)</translation>
    </message>
    <message>
        <source>Error when setting the elliptic curves (%1)</source>
        <translation>Fel vid inställning av elliptiska kurvor (%1)</translation>
    </message>
    <message>
        <source>Error creating SSL context (%1)</source>
        <translation>Fel vid skapandet av SSL-kontext (%1)</translation>
    </message>
    <message>
        <source>unsupported protocol</source>
        <translation>protokollet stöds inte</translation>
    </message>
    <message>
        <source>Error while setting the minimal protocol version</source>
        <translation>Fel vid inställning av minimum protokollversion</translation>
    </message>
    <message>
        <source>Error while setting the maximum protocol version</source>
        <translation>Fel vid inställning av minimal protokollversion</translation>
    </message>
    <message>
        <source>Invalid or empty cipher list (%1)</source>
        <translation>Ogiltig eller tom chifferlista (%1)</translation>
    </message>
    <message>
        <source>Cannot provide a certificate with no key</source>
        <translation>Kan inte tillhandahålla ett certifikat utan en nyckel</translation>
    </message>
    <message>
        <source>Error loading local certificate, %1</source>
        <translation>Fel vid inläsning av lokalt certifikat, %1</translation>
    </message>
    <message>
        <source>Error loading private key, %1</source>
        <translation>Fel vid inläsning av privat nyckel, %1</translation>
    </message>
    <message>
        <source>Private key does not certify public key, %1</source>
        <translation>Privat nyckel certifierar inte publika nyckeln, %1</translation>
    </message>
    <message>
        <source>Diffie-Hellman parameters are not valid</source>
        <translation>Diffie-Hellman-parametrar är inte giltiga</translation>
    </message>
    <message>
        <source>OpenSSL version with disabled elliptic curves</source>
        <translation>OpenSSL-version med inaktiverade elliptiska kurvor</translation>
    </message>
    <message>
        <source>Expecting QByteArray for %1</source>
        <translation>Förväntade QByteArray för %1</translation>
    </message>
    <message>
        <source>An error occurred attempting to set %1 to %2</source>
        <translation>Ett fel inträffade vid försök att ställa in %1 till %2</translation>
    </message>
    <message>
        <source>Wrong value for %1 (%2)</source>
        <translation>Fel värde för %1 (%2)</translation>
    </message>
    <message>
        <source>Unrecognized command %1 = %2</source>
        <translation>Kommandot känns inte igen %1 = %2</translation>
    </message>
    <message>
        <source>SSL_CONF_finish() failed</source>
        <translation>SSL_CONF_finish() misslyckades</translation>
    </message>
    <message>
        <source>SSL_CONF_CTX_new() failed</source>
        <translation>SSL_CONF_CTX_new() misslyckades</translation>
    </message>
    <message>
        <source>Unable to init SSL Context: %1</source>
        <translation>Kunde inte initiera SSL-kontext: %1</translation>
    </message>
    <message>
        <source>Unable to write data: %1</source>
        <translation>Kunde inte skriva data: %1</translation>
    </message>
    <message>
        <source>Unable to decrypt data: %1</source>
        <translation>Kunde inte dekryptera data: %1</translation>
    </message>
    <message>
        <source>TLS certificate unexpectedly changed during renegotiation!</source>
        <translation>TLS-certifikatet ändrades oväntat under omförhandlingen!</translation>
    </message>
    <message>
        <source>The TLS/SSL connection has been closed</source>
        <translation>TLS/SSL-anslutningen har stängts</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Fel vid läsning: %1</translation>
    </message>
    <message>
        <source>Error creating SSL session, %1</source>
        <translation>Fel vid skapandet av SSL-session, %1</translation>
    </message>
    <message>
        <source>Error creating SSL session: %1</source>
        <translation>Fel vid skapande av SSL-session: %1</translation>
    </message>
    <message>
        <source>Server-side QSslSocket does not support OCSP stapling</source>
        <translation>Serversidans QSslSocket har inte stöd för OCSP-häftning</translation>
    </message>
    <message>
        <source>Failed to enable OCSP stapling</source>
        <translation>Misslyckades med att aktivera OCSP-häftning</translation>
    </message>
    <message>
        <source>Client-side sockets do not send OCSP responses</source>
        <translation>Klientsidans uttag skickar inte OCSP-svar</translation>
    </message>
    <message>
        <source>Failed to decode OCSP response</source>
        <translation>Misslyckades med att avkoda OCSP-svar</translation>
    </message>
    <message>
        <source>Failed to extract basic OCSP response</source>
        <translation>Misslyckades med att extrahera grundläggande OCSP-svar</translation>
    </message>
    <message>
        <source>No certificate verification store, cannot verify OCSP response</source>
        <translation>Inget arkiv för certifikatverifiering, kan inte verifiera OCSP-svar</translation>
    </message>
    <message>
        <source>Failed to decode a SingleResponse from OCSP status response</source>
        <translation>Misslyckades med att avkoda en SingleResponse från OCSP-statussvar</translation>
    </message>
    <message>
        <source>Failed to extract &apos;this update time&apos; from the SingleResponse</source>
        <translation>Misslyckades med att extrahera &apos;this update time&apos; från SingleResponse</translation>
    </message>
    <message>
        <source>Error during SSL handshake: %1</source>
        <translation>Fel under SSL-handskakning: %1</translation>
    </message>
    <message>
        <source>Insufficient memory</source>
        <translation>Otillräckligt med minne</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation>Internt fel</translation>
    </message>
    <message>
        <source>An internal handle was invalid</source>
        <translation>Ett internt handtag var ogiltigt</translation>
    </message>
    <message>
        <source>An internal token was invalid</source>
        <translation>Ett internt token var ogiltigt</translation>
    </message>
    <message>
        <source>Access denied</source>
        <translation>Åtkomst nekad</translation>
    </message>
    <message>
        <source>No authority could be contacted for authorization</source>
        <translation>Ingen utfärdare kunde kontaktas för auktorisering</translation>
    </message>
    <message>
        <source>No credentials</source>
        <translation>Inga inloggningsuppgifter</translation>
    </message>
    <message>
        <source>The target is unknown or unreachable</source>
        <translation>Målet är okänt eller inte möjligt att nå</translation>
    </message>
    <message>
        <source>An unsupported function was requested</source>
        <translation>En funktion som inte stöds begärdes</translation>
    </message>
    <message>
        <source>The hostname provided does not match the one received from the peer</source>
        <translation>Värdnamnet som tillhandahölls matchar inte det som togs emot från motparten</translation>
    </message>
    <message>
        <source>No common protocol exists between the client and the server</source>
        <translation>Inget gemensamt protokoll finns mellan klient och servern</translation>
    </message>
    <message>
        <source>Unexpected or badly-formatted message received</source>
        <translation>Oväntat eller felaktigt formaterat meddelande togs emot</translation>
    </message>
    <message>
        <source>The data could not be encrypted</source>
        <translation>Detta data kunde inte krypteras</translation>
    </message>
    <message>
        <source>The data could not be decrypted</source>
        <translation>Datan kunde inte dekrypteras</translation>
    </message>
    <message>
        <source>No cipher suites in common</source>
        <translation>Inga chiffersviter gemensamt</translation>
    </message>
    <message>
        <source>The credentials were not recognized / Invalid argument</source>
        <translation>Inloggningsuppgifterna kändes inte igen / Ogiltigt argument</translation>
    </message>
    <message>
        <source>The message was tampered with, damaged or out of sequence.</source>
        <translation>Meddelandet har mixtrats med, skadats eller utanför sekvensen.</translation>
    </message>
    <message>
        <source>A message was received out of sequence.</source>
        <translation>Ett meddelande togs emot utanför sekvensen.</translation>
    </message>
    <message>
        <source>Unknown error occurred: %1</source>
        <translation>Okänt fel inträffade: %1</translation>
    </message>
    <message>
        <source>Invalid protocol chosen</source>
        <translation>Ogiltigt protkoll valt</translation>
    </message>
    <message>
        <source>Server did not accept any certificate we could present.</source>
        <translation>Servern accepterade inte något certifikat vi kunde presentera.</translation>
    </message>
    <message>
        <source>Algorithm mismatch</source>
        <translation>Algoritmen stämmer inte överens</translation>
    </message>
    <message>
        <source>Handshake failed: %1</source>
        <translation>Handskakningsfel: %1</translation>
    </message>
    <message>
        <source>Failed to query the TLS context: %1</source>
        <translation>Misslyckades med att fråga TLS-kontexten: %1</translation>
    </message>
    <message>
        <source>Did not get the required attributes for the connection.</source>
        <translation>Fick inte de nödvändiga attributen för anslutningen.</translation>
    </message>
    <message>
        <source>Unwanted protocol was negotiated</source>
        <translation>Oönskat protokoll förhandlades</translation>
    </message>
    <message>
        <source>Renegotiation was unsuccessful: %1</source>
        <translation>Omförhandling lyckades inte: %1</translation>
    </message>
    <message>
        <source>Schannel failed to encrypt data: %1</source>
        <translation>Schannel misslyckades att kryptera data: %1</translation>
    </message>
</context>
<context>
    <name>QStandardPaths</name>
    <message>
        <source>Desktop</source>
        <translation>Skrivbord</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Typsnitt</translation>
    </message>
    <message>
        <source>Applications</source>
        <translation>Program</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Musik</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filmer</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <source>Temporary Directory</source>
        <translation>Temporärkatalog</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Hem</translation>
    </message>
    <message>
        <source>Application Data</source>
        <translation>Programdata</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Tillstånd</translation>
    </message>
    <message>
        <source>Shared Data</source>
        <translation>Delat data</translation>
    </message>
    <message>
        <source>Runtime</source>
        <translation>Körtid</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Konfiguration</translation>
    </message>
    <message>
        <source>Shared Configuration</source>
        <translation>Delad konfiguration</translation>
    </message>
    <message>
        <source>Shared Cache</source>
        <translation>Delad cache</translation>
    </message>
    <message>
        <source>Shared State</source>
        <translation>Delat tillstånd</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Hämtningar</translation>
    </message>
    <message>
        <source>Application Configuration</source>
        <translation>Programkonfiguration</translation>
    </message>
    <message>
        <source>Public</source>
        <translation>Publik</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Mallar</translation>
    </message>
    <message>
        <source>Temporary Items</source>
        <extracomment>macOS: Temporary directory</extracomment>
        <translation>Temporära objekt</translation>
    </message>
</context>
<context>
    <name>QSystemSemaphore</name>
    <message>
        <source>%1: unsupported key type</source>
        <translation>%1: nyckeltypen stöds inte</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: Behörighet nekad</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: finns redan</translation>
    </message>
    <message>
        <source>%1: does not exist</source>
        <translation>%1: finns inte</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: slut på resurser</translation>
    </message>
    <message>
        <source>%1: key too long</source>
        <translation>%1: nyckeln är för lång</translation>
    </message>
    <message>
        <source>%1: unknown error: %2</source>
        <translation>%1: okänt fel: %2</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: nyckeln är tom</translation>
    </message>
    <message>
        <source>%1: System V semaphores are not available for sandboxed applications. Please build Qt with -feature-ipc_posix</source>
        <translation>%1: System V-semaforer är inte tillgängliga för sandboxade program. Bygg Qt med -feature-ipc_posix</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: kunde inte skapa nyckel</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation>%1: ftok misslyckades</translation>
    </message>
</context>
<context>
    <name>QTabBar</name>
    <message>
        <source>Scroll Left</source>
        <translation>Rulla vänster</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Rulla höger</translation>
    </message>
</context>
<context>
    <name>QTcpServer</name>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>Åtgärd på uttag stöds inte</translation>
    </message>
</context>
<context>
    <name>QTgaFile</name>
    <message>
        <source>Could not read image data</source>
        <translation>Kunde inte läsa bilddata</translation>
    </message>
    <message>
        <source>Sequential device (eg socket) for image read not supported</source>
        <translation>Sekventiell enhet (t.ex uttag) för bildläsning stöds inte</translation>
    </message>
    <message>
        <source>Seek file/device for image read failed</source>
        <translation>Spola i fil/enhet för bildläsning misslyckades</translation>
    </message>
    <message>
        <source>Image header read failed</source>
        <translation>Läsning av bildrubrik misslyckades</translation>
    </message>
    <message>
        <source>Image type not supported</source>
        <translation>Bildtypen stöds inte</translation>
    </message>
    <message>
        <source>Image depth not valid</source>
        <translation>Bilddjup inte giltigt</translation>
    </message>
    <message>
        <source>Image size exceeds limit</source>
        <translation>Bildstorleken överstiger gränsen</translation>
    </message>
    <message>
        <source>Could not seek to image read footer</source>
        <translation>Kunde inte spola till bildläsningsfot</translation>
    </message>
    <message>
        <source>Could not read footer</source>
        <translation>Kunde inte läsa sidfot</translation>
    </message>
    <message>
        <source>Image type (non-TrueVision 2.0) not supported</source>
        <translation>Bildtyp (icke-TrueVision 2.0) stöds inte</translation>
    </message>
    <message>
        <source>Could not reset to read data</source>
        <translation>Kunde inte nollställa för att läsa data</translation>
    </message>
    <message>
        <source>Invalid color map depth (%1)</source>
        <translation>Ogiltigt färgkartsdjup (%1)</translation>
    </message>
</context>
<context>
    <name>QUdpSocket</name>
    <message>
        <source>Unable to send a datagram</source>
        <translation>Kunde inte skicka ett datagram</translation>
    </message>
    <message>
        <source>No datagram available for reading</source>
        <translation>Ingen datagram tillgängligt för läsning</translation>
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <source>Undo %1</source>
        <translation>Ångra %1</translation>
    </message>
    <message>
        <source>Undo</source>
        <comment>Default text for undo action</comment>
        <translation>Ångra</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation>Gör om %1</translation>
    </message>
    <message>
        <source>Redo</source>
        <comment>Default text for redo action</comment>
        <translation>Gör om</translation>
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tom&gt;</translation>
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <source>Undo %1</source>
        <translation>Ångra %1</translation>
    </message>
    <message>
        <source>Undo</source>
        <comment>Default text for undo action</comment>
        <translation>Ångra</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation>Gör om %1</translation>
    </message>
    <message>
        <source>Redo</source>
        <comment>Default text for redo action</comment>
        <translation>Gör om</translation>
    </message>
</context>
<context>
    <name>QUnicodeControlCharacterMenu</name>
    <message>
        <source>LRM Left-to-right mark</source>
        <translation>U+200E</translation>
    </message>
    <message>
        <source>RLM Right-to-left mark</source>
        <translation>U+200F</translation>
    </message>
    <message>
        <source>ZWJ Zero width joiner</source>
        <translation>U+200D</translation>
    </message>
    <message>
        <source>ZWNJ Zero width non-joiner</source>
        <translation>U+200C</translation>
    </message>
    <message>
        <source>ZWSP Zero width space</source>
        <translation>U+200B</translation>
    </message>
    <message>
        <source>LRE Start of left-to-right embedding</source>
        <translation>U+202A</translation>
    </message>
    <message>
        <source>RLE Start of right-to-left embedding</source>
        <translation>U+202B</translation>
    </message>
    <message>
        <source>LRO Start of left-to-right override</source>
        <translation>U+202D</translation>
    </message>
    <message>
        <source>RLO Start of right-to-left override</source>
        <translation>U+202E</translation>
    </message>
    <message>
        <source>PDF Pop directional formatting</source>
        <translation>U+202C</translation>
    </message>
    <message>
        <source>LRI Left-to-right isolate</source>
        <translation>U+2066</translation>
    </message>
    <message>
        <source>RLI Right-to-left isolate</source>
        <translation>U+2067</translation>
    </message>
    <message>
        <source>FSI First strong isolate</source>
        <translation>U+2068</translation>
    </message>
    <message>
        <source>PDI Pop directional isolate</source>
        <translation>U+2069</translation>
    </message>
    <message>
        <source>Insert Unicode control character</source>
        <translation>Infoga unicode-kontrolltecken</translation>
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>Vad är det här?</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <source>*</source>
        <translation>*</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Ångra</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Gör om</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Klipp &amp;ut</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiera</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Kopiera &amp;länkplats</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>Klistra &amp;in</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
</context>
<context>
    <name>QWindowsDirect2DIntegration</name>
    <message>
        <source>Qt cannot load the direct2d platform plugin because the Direct2D version on this system is too old. The minimum system requirement for this platform plugin is Windows 7 SP1 with Platform Update.

The minimum Direct2D version required is %1. The Direct2D version on this system is %2.</source>
        <translation>Qt kan inte läsa in plattformsinsticksmodulen för direct2d därför att Direct2D-versionen på detta system är för gammal. Minsta systemkravet för denna plattformsinsticksmodul är Windows 7 SP1 med Platform Update.

Minsta Direct2D-versionen som krävs är %1. Direct2D-versionen på detta system är %2.</translation>
    </message>
    <message>
        <source>Cannot load direct2d platform plugin</source>
        <translation>Kan inte läsa in plattformsinsticksmodul för direct2d</translation>
    </message>
</context>
<context>
    <name>QWizard</name>
    <message>
        <source>Go Back</source>
        <translation>Gå bakåt</translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation>&lt; Till&amp;baka</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Fortsätt</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Nästa</translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Nästa &gt;</translation>
    </message>
    <message>
        <source>Commit</source>
        <translation>Verkställ</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Färdig</translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation>&amp;Färdig</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hjälp</translation>
    </message>
</context>
<context>
    <name>QXmlStream</name>
    <message>
        <source>Extra content at end of document.</source>
        <translation>Extra innehåll i slutet av dokumentet.</translation>
    </message>
    <message>
        <source>Invalid entity value.</source>
        <translation>Ogiltigt entitetsvärde.</translation>
    </message>
    <message>
        <source>Invalid XML character.</source>
        <translation>Ogiltigt XML-tecken.</translation>
    </message>
    <message>
        <source>Sequence &apos;]]&gt;&apos; not allowed in content.</source>
        <translation>Sekvensen &apos;]]&gt;&apos; tillåts inte i innehåll.</translation>
    </message>
    <message>
        <source>Encountered incorrectly encoded content.</source>
        <translation>Påträffade felaktigt enkodat innehåll.</translation>
    </message>
    <message>
        <source>Namespace prefix &apos;%1&apos; not declared</source>
        <translation>Namnrymdsprefixet &apos;%1&apos; är inte deklarerat</translation>
    </message>
    <message>
        <source>Illegal namespace declaration.</source>
        <translation>Ogiltig namnrymdsdeklaration.</translation>
    </message>
    <message>
        <source>Attribute &apos;%1&apos; redefined.</source>
        <translation>Attributet &apos;%1&apos; omdefinierat.</translation>
    </message>
    <message>
        <source>Unexpected character &apos;%1&apos; in public id literal.</source>
        <translation>Oväntat tecken &apos;%1&apos; i public id literal.</translation>
    </message>
    <message>
        <source>Invalid XML version string.</source>
        <translation>Ogiltig XML-versionssträng.</translation>
    </message>
    <message>
        <source>Unsupported XML version.</source>
        <translation>XML-versionen stöds inte.</translation>
    </message>
    <message>
        <source>The standalone pseudo attribute must appear after the encoding.</source>
        <translation>Pseudoattributet standalone måste synas efter enkodningen.</translation>
    </message>
    <message>
        <source>%1 is an invalid encoding name.</source>
        <translation>%1 är ett ogiltigt enkodningsnamn.</translation>
    </message>
    <message>
        <source>Encoding %1 is unsupported</source>
        <translation>Enkodningen %1 stöds inte</translation>
    </message>
    <message>
        <source>Standalone accepts only yes or no.</source>
        <translation>Standalone accepterar endast yes eller no.</translation>
    </message>
    <message>
        <source>Invalid attribute in XML declaration: %1 = %2</source>
        <translation>Ogiltigt attribut i XML-deklaration: %1 = %2</translation>
    </message>
    <message>
        <source>Premature end of document.</source>
        <translation>För tidigt slut på dokumentet.</translation>
    </message>
    <message>
        <source>Invalid document.</source>
        <translation>Ogiltigt dokument.</translation>
    </message>
    <message>
        <source>Length of XML attribute name exceeds implementation limits (4KiB characters).</source>
        <translation>Längd för XML-attributnamn överstiger implementationsgränser (4KiB tecken).</translation>
    </message>
    <message>
        <source>&apos;%1&apos;</source>
        <comment>expected</comment>
        <extracomment>&apos;&lt;first option&gt;&apos;</extracomment>
        <translation>&apos;%1&apos;</translation>
    </message>
    <message>
        <source>%1 or &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;first option&gt;, &apos;&lt;second option&gt;&apos;</extracomment>
        <translation>%1 eller &apos;%2&apos;</translation>
    </message>
    <message>
        <source>%1, &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;options so far&gt;, &apos;&lt;next option&gt;&apos;</extracomment>
        <translation>%1, &apos;%2&apos;</translation>
    </message>
    <message>
        <source>%1, or &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;options so far&gt;, or &apos;&lt;final option&gt;&apos;</extracomment>
        <translation>%1, eller &apos;%2&apos;</translation>
    </message>
    <message>
        <source>Expected %1, but got &apos;%2&apos;.</source>
        <translation>Förväntade %1, men fick &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Unexpected &apos;%1&apos;.</source>
        <translation>Förväntade &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>An I/O error occurred while writing</source>
        <translation>Ett in-/ut-fel inträffade under skrivning</translation>
    </message>
    <message>
        <source>An encoding error occurred while writing</source>
        <translation>Ett kodningsfel inträffade under skrivning</translation>
    </message>
    <message>
        <source>Encountered an invalid XML 1.0 character while writing</source>
        <translation>Påträffade ett ogiltigt XML 1.0-tecken under skrivning</translation>
    </message>
    <message>
        <source>An error occurred while writing</source>
        <translation>Ett fel inträffade vid skrivning</translation>
    </message>
    <message>
        <source>Unexpected token type %1 in %2.</source>
        <translation>Oväntad token-typ %1 i %2.</translation>
    </message>
    <message>
        <source>Found second DTD token in %1.</source>
        <translation>Hittade andra DTD-token i %1.</translation>
    </message>
    <message>
        <source>Self-referencing entity detected.</source>
        <translation>Självrefererande entitet upptäcktes.</translation>
    </message>
    <message>
        <source>Entity expands to more characters than the entity expansion limit.</source>
        <translation>Entiteten expanderar till fler tecken än entitetens expansionsgräns.</translation>
    </message>
    <message>
        <source>Start tag expected.</source>
        <translation>Starttagg förväntades.</translation>
    </message>
    <message>
        <source>NDATA in parameter entity declaration.</source>
        <translation>NDATA i parametern entitetsdeklaration.</translation>
    </message>
    <message>
        <source>XML declaration not at start of document.</source>
        <translation>XML-deklaration inte i början av dokumentet.</translation>
    </message>
    <message>
        <source>%1 is an invalid processing instruction name.</source>
        <translation>%1 är ett ogiltigt namn på behandlande instruktion.</translation>
    </message>
    <message>
        <source>Invalid processing instruction name.</source>
        <translation>Ogiltigt namn för behandlande instruktion.</translation>
    </message>
    <message>
        <source>%1 is an invalid PUBLIC identifier.</source>
        <translation>%1 är en ogiltig PUBLIC-identifierare.</translation>
    </message>
    <message>
        <source>Invalid XML name.</source>
        <translation>Ogiltigt XML-namn.</translation>
    </message>
    <message>
        <source>Opening and ending tag mismatch.</source>
        <translation>Öppnande och avslutande tagg stämmer inte överens.</translation>
    </message>
    <message>
        <source>Entity &apos;%1&apos; not declared.</source>
        <translation>Entiteten &apos;%1&apos; är inte deklarerad.</translation>
    </message>
    <message>
        <source>Reference to unparsed entity &apos;%1&apos;.</source>
        <translation>Referens till otolkad entitet &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Reference to external entity &apos;%1&apos; in attribute value.</source>
        <translation>Referens till extern entitet &apos;%1&apos; i attributvärdet.</translation>
    </message>
    <message>
        <source>Invalid character reference.</source>
        <translation>Ogiltig teckenreferens.</translation>
    </message>
</context>
<context>
    <name>quiaccessibilityelement</name>
    <message>
        <source>checked</source>
        <translation>markerad</translation>
    </message>
    <message>
        <source>unchecked</source>
        <translation>avmarkerad</translation>
    </message>
</context>
<context>
    <name>QMimeType</name>
    <message>
        <source>Empty document</source>
        <extracomment>application/x-zerosize</extracomment>
        <translation>Tomt dokument</translation>
    </message>
    <message>
        <source>Desktop file</source>
        <extracomment>application/x-desktop</extracomment>
        <translation>Skrivbordsfil</translation>
    </message>
    <message>
        <source>Qt Markup Language file</source>
        <extracomment>text/x-qml</extracomment>
        <translation>Qt Markup Language-fil</translation>
    </message>
    <message>
        <source>Compressed postscript</source>
        <extracomment>application/x-gzpostscript</extracomment>
        <translation>Komprimerad postscript</translation>
    </message>
    <message>
        <source>Core dump</source>
        <extracomment>application/x-core</extracomment>
        <translation>Minnesdump</translation>
    </message>
    <message>
        <source>BZip2 compressed tar file</source>
        <extracomment>application/x-bzip2-compressed-tar</extracomment>
        <translation>BZip2-komprimerad tar-fil</translation>
    </message>
    <message>
        <source>Directory</source>
        <extracomment>inode/directory</extracomment>
        <translation>Katalog</translation>
    </message>
    <message>
        <source>Windows Batch / Command File</source>
        <extracomment>application/x-bat</extracomment>
        <translation>Windows Batch / kommandofil</translation>
    </message>
    <message>
        <source>BizAgi Process Modeler</source>
        <extracomment>application/bizagi-modeler</extracomment>
        <translation>BizAgi Process Modeler</translation>
    </message>
    <message>
        <source>Concise Binary Object Representation container</source>
        <extracomment>application/cbor</extracomment>
        <translation>Concise Binary Object Representation-behållare</translation>
    </message>
    <message>
        <source>CorelDraw</source>
        <extracomment>application/coreldraw</extracomment>
        <translation>CorelDraw</translation>
    </message>
    <message>
        <source>DICOM medical imaging data</source>
        <extracomment>application/dicom</extracomment>
        <translation>DICOM medicinsk bilddata</translation>
    </message>
    <message>
        <source>Darwin Information Typing Architecture</source>
        <extracomment>application/dita+xml</extracomment>
        <translation>Darwin Information Typing Architecture</translation>
    </message>
    <message>
        <source>DVD information file</source>
        <extracomment>application/x-dvd-ifo</extracomment>
        <translation>DVD-informationsfil</translation>
    </message>
    <message>
        <source>EBU-STL subtitles</source>
        <extracomment>application/x-ebu-stl</extracomment>
        <translation>EBU-STL-undertexter</translation>
    </message>
    <message>
        <source>Electronic Publication</source>
        <extracomment>application/epub+zip</extracomment>
        <translation>Electronic Publication</translation>
    </message>
    <message>
        <source>Flexible Image Transport System</source>
        <extracomment>application/fits</extracomment>
        <translation>Flexible Image Transport System</translation>
    </message>
    <message>
        <source>Adobe Illustrator Artwork</source>
        <extracomment>application/illustrator</extracomment>
        <translation>Adobe Illustrator Artwork</translation>
    </message>
    <message>
        <source>Adobe Illustrator Artwork -- the older postscript based AI files</source>
        <extracomment>application/illustrator+ps</extracomment>
        <translation>Adobe Illustrator Artwork -- äldre postscript-baserade AI-filer</translation>
    </message>
    <message>
        <source>Windows setup INFormation</source>
        <extracomment>application/inf</extracomment>
        <translation>Windows setup INFormation</translation>
    </message>
    <message>
        <source>Java Archive</source>
        <extracomment>application/java-archive</extracomment>
        <translation>Java-arkiv</translation>
    </message>
    <message>
        <source>JavaScript Source Code</source>
        <extracomment>text/javascript</extracomment>
        <translation>JavaScript-källkod</translation>
    </message>
    <message>
        <source>Web Application Manifest file</source>
        <extracomment>application/manifest+json</extracomment>
        <translation>Web Application Manifest-fil</translation>
    </message>
    <message>
        <source>Java Class File</source>
        <extracomment>application/java-vm</extracomment>
        <translation>Java-klassfil</translation>
    </message>
    <message>
        <source>Mach-O Universal</source>
        <extracomment>application/x-mach-o-universal</extracomment>
        <translation>Mach-O Universal</translation>
    </message>
    <message>
        <source>Java Native Library for OSX</source>
        <extracomment>application/x-java-jnilib</extracomment>
        <translation>Java Native Library för OSX</translation>
    </message>
    <message>
        <source>Java hprof text file</source>
        <extracomment>application/vnd.java.hprof 
----------
application/vnd.java.hprof.text</extracomment>
        <translation>Java hprof-textfil</translation>
    </message>
    <message>
        <source>Wolfram Mathematica</source>
        <extracomment>application/mathematica</extracomment>
        <translation>Wolfram Mathematica</translation>
    </message>
    <message>
        <source>Wolfram Language</source>
        <extracomment>application/vnd.wolfram.wl</extracomment>
        <translation>Wolfram Language</translation>
    </message>
    <message>
        <source>Adobe MIF File</source>
        <extracomment>application/vnd.mif</extracomment>
        <translation>Adobe MIF-fil</translation>
    </message>
    <message>
        <source>QuickTime container format</source>
        <extracomment>application/quicktime</extracomment>
        <translation>QuickTime-containerformat</translation>
    </message>
    <message>
        <source>MP4 container format</source>
        <extracomment>application/mp4</extracomment>
        <translation>MP4-containerformat</translation>
    </message>
    <message>
        <source>Microsoft Word Document</source>
        <extracomment>application/msword</extracomment>
        <translation>Microsoft Word-dokument</translation>
    </message>
    <message>
        <source>Microsoft Word 2 Document</source>
        <extracomment>application/msword2</extracomment>
        <translation>Microsoft Word 2-dokument</translation>
    </message>
    <message>
        <source>Microsoft Word 5 Document</source>
        <extracomment>application/msword5</extracomment>
        <translation>Microsoft Word 5-dokument</translation>
    </message>
    <message>
        <source>OneNote Package</source>
        <extracomment>application/onenote; format=package</extracomment>
        <translation>OneNote-paket</translation>
    </message>
    <message>
        <source>Portable Document Format</source>
        <extracomment>application/pdf</extracomment>
        <translation>Portable Document Format</translation>
    </message>
    <message>
        <source>PostScript</source>
        <extracomment>application/postscript</extracomment>
        <translation>PostScript</translation>
    </message>
    <message>
        <source>Excel 2003 xml format, pre-ooxml</source>
        <extracomment>application/vnd.ms-spreadsheetml</extracomment>
        <translation>Excel 2003 xml-format, före ooxml</translation>
    </message>
    <message>
        <source>Word 2003 xml format, pre-ooxml</source>
        <extracomment>application/vnd.ms-wordml</extracomment>
        <translation>Word 2003 xml-format, före ooxml</translation>
    </message>
    <message>
        <source>Word 2006 xml format, pre-ooxml</source>
        <extracomment>application/vnd.ms-word2006ml</extracomment>
        <translation>Word 2006 xml-format, före ooxml</translation>
    </message>
    <message>
        <source>XML syntax for RDF graphs</source>
        <extracomment>application/rdf+xml</extracomment>
        <translation>XML-syntax för RDF-diagram</translation>
    </message>
    <message>
        <source>Rich Text Format File</source>
        <extracomment>application/rtf</extracomment>
        <translation>Rich Text Format-fil</translation>
    </message>
    <message>
        <source>Sereal binary serialization format</source>
        <extracomment>application/sereal</extracomment>
        <translation>Sereal binärt serialiseringsformat</translation>
    </message>
    <message>
        <source>SMIL Multimedia</source>
        <extracomment>application/smil+xml</extracomment>
        <translation>SMIL Multimedia</translation>
    </message>
    <message>
        <source>SolidWorks CAD program</source>
        <extracomment>application/sldworks</extracomment>
        <translation>SolidWorks CAD-program</translation>
    </message>
    <message>
        <source>Password Protected iWorks File</source>
        <extracomment>application/x-tika-iworks-protected</extracomment>
        <translation>Lösenordsskyddad iWorks-fil</translation>
    </message>
    <message>
        <source>web archive frictionless zip</source>
        <extracomment>application/x-wacz</extracomment>
        <translation>webbarkiv friktionsfritt zip</translation>
    </message>
    <message>
        <source>frictionless data package zip package</source>
        <extracomment>application/x-vnd.datapackage+zip</extracomment>
        <translation>friktionsfritt datapaket zip-paket</translation>
    </message>
    <message>
        <source>frictionless data package - standalong datapackage.json</source>
        <extracomment>application/x-vnd.datapackage+json</extracomment>
        <translation>friktionsfritt datapaket – fristående datapackage.json</translation>
    </message>
    <message>
        <source>frictionless data package - gzip of standalone datapackage.json</source>
        <extracomment>application/x-vnd.datapackage+gz</extracomment>
        <translation>friktionsfritt datapaket – gzip av fristående datapackage.json</translation>
    </message>
    <message>
        <source>digilite.eu Prolights configuration file</source>
        <extracomment>application/vnd.digilite.prolights</extracomment>
        <translation>digilite.eu Prolights konfigurationsfil</translation>
    </message>
    <message>
        <source>Extended Associated Signature Container</source>
        <extracomment>application/vnd.etsi.asic-e+zip</extracomment>
        <translation>Extended Associated Signature Container</translation>
    </message>
    <message>
        <source>Simple Associated Signature Container</source>
        <extracomment>application/vnd.etsi.asic-s+zip</extracomment>
        <translation>Simple Associated Signature Container</translation>
    </message>
    <message>
        <source>Forms Data Format</source>
        <extracomment>application/vnd.fdf</extracomment>
        <translation>Forms Data Format</translation>
    </message>
    <message>
        <source>Keyhole Markup Language</source>
        <extracomment>application/vnd.google-earth.kml+xml</extracomment>
        <translation>Keyhole Markup Language</translation>
    </message>
    <message>
        <source>XML syntax for IPTC NewsMessages</source>
        <extracomment>application/vnd.iptc.g2.newsmessage+xml</extracomment>
        <translation>XML-syntax för IPTC NewsMessages</translation>
    </message>
    <message>
        <source>KChart File</source>
        <extracomment>application/vnd.kde.kchart</extracomment>
        <translation>KChart-fil</translation>
    </message>
    <message>
        <source>KPresenter File</source>
        <extracomment>application/vnd.kde.kpresenter</extracomment>
        <translation>KPresenter-fil</translation>
    </message>
    <message>
        <source>KSpread File</source>
        <extracomment>application/vnd.kde.kspread</extracomment>
        <translation>KSpread-fil</translation>
    </message>
    <message>
        <source>KWord File</source>
        <extracomment>application/vnd.kde.kword</extracomment>
        <translation>KWord-fil</translation>
    </message>
    <message>
        <source>SSEYO Koan File</source>
        <extracomment>application/vnd.koan</extracomment>
        <translation>SSEYO Koan-fil</translation>
    </message>
    <message>
        <source>Lotus 1-2-3</source>
        <extracomment>application/vnd.lotus-1-2-3</extracomment>
        <translation>Lotus 1-2-3</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 1</source>
        <extracomment>application/vnd.lotus-1-2-3;version=1</extracomment>
        <translation>Lotus 1-2-3, version 1</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 2</source>
        <extracomment>application/vnd.lotus-1-2-3;version=2</extracomment>
        <translation>Lotus 1-2-3, version 2</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 3</source>
        <extracomment>application/vnd.lotus-1-2-3;version=3</extracomment>
        <translation>Lotus 1-2-3, version 3</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 4-5</source>
        <extracomment>application/vnd.lotus-1-2-3;version=4</extracomment>
        <translation>Lotus 1-2-3, version 4-5</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 97/9.x</source>
        <extracomment>application/vnd.lotus-1-2-3;version=97+9.x</extracomment>
        <translation>Lotus 1-2-3, version 97/9.x</translation>
    </message>
    <message>
        <source>FrameMaker Interchange Format</source>
        <extracomment>application/vnd.mif</extracomment>
        <translation>FrameMaker Interchange Format</translation>
    </message>
    <message>
        <source>MindManager</source>
        <extracomment>application/vnd.mindjet.mindmanager</extracomment>
        <translation>MindManager</translation>
    </message>
    <message>
        <source>Microsoft Excel Spreadsheet</source>
        <extracomment>application/vnd.ms-excel</extracomment>
        <translation>Microsoft Excel-kalkylark</translation>
    </message>
    <message>
        <source>Office Open XML Workbook Add-in (macro-enabled)</source>
        <extracomment>application/vnd.ms-excel.addin.macroenabled.12</extracomment>
        <translation>Office Open XML-arbetsbokstillägg (makroaktiverat)</translation>
    </message>
    <message>
        <source>Office Open XML Workbook (macro-enabled)</source>
        <extracomment>application/vnd.ms-excel.sheet.macroenabled.12</extracomment>
        <translation>Office Open XML-arbetsbok (makroaktiverad)</translation>
    </message>
    <message>
        <source>Microsoft Excel 2007 Binary Spreadsheet</source>
        <extracomment>application/vnd.ms-excel.sheet.binary.macroenabled.12</extracomment>
        <translation>Microsoft Excel 2007 binärt kalkylblad</translation>
    </message>
    <message>
        <source>Microsoft Excel 4 Worksheet</source>
        <extracomment>application/vnd.ms-excel.sheet.4</extracomment>
        <translation>Microsoft Excel 4-kalkylblad</translation>
    </message>
    <message>
        <source>Microsoft Excel 4 Workspace</source>
        <extracomment>application/vnd.ms-excel.workspace.4</extracomment>
        <translation>Microsoft Excel 4-arbetsyta</translation>
    </message>
    <message>
        <source>Microsoft Excel 3 Worksheet</source>
        <extracomment>application/vnd.ms-excel.sheet.3</extracomment>
        <translation>Microsoft Excel 3-kalkylblad</translation>
    </message>
    <message>
        <source>Microsoft Excel 3 Workspace</source>
        <extracomment>application/vnd.ms-excel.workspace.3</extracomment>
        <translation>Microsoft Excel 3-arbetsyta</translation>
    </message>
    <message>
        <source>Microsoft Excel 2 Worksheet</source>
        <extracomment>application/vnd.ms-excel.sheet.2</extracomment>
        <translation>Microsoft Excel 2-kalkylblad</translation>
    </message>
    <message>
        <source>Microsoft Outlook Message</source>
        <extracomment>application/vnd.ms-outlook</extracomment>
        <translation>Microsoft Outlook-meddelande</translation>
    </message>
    <message>
        <source>Outlook Personal Folders File Format</source>
        <extracomment>application/vnd.ms-outlook-pst</extracomment>
        <translation>Outlook filformat för personliga mappar</translation>
    </message>
    <message>
        <source>3D manufacturing format</source>
        <extracomment>application/vnd.ms-package.3dmanufacturing-3dmodel+xml</extracomment>
        <translation>3D manufacturing-format</translation>
    </message>
    <message>
        <source>Microsoft Powerpoint Presentation</source>
        <extracomment>application/vnd.ms-powerpoint</extracomment>
        <translation>Microsoft Powerpoint-presentation</translation>
    </message>
    <message>
        <source>Office Open XML Presentation Add-in (macro-enabled)</source>
        <extracomment>application/vnd.ms-powerpoint.addin.macroenabled.12</extracomment>
        <translation>Office Open XML-presentationstillägg (makroaktiverat)</translation>
    </message>
    <message>
        <source>Office Open XML Presentation (macro-enabled)</source>
        <extracomment>application/vnd.ms-powerpoint.presentation.macroenabled.12</extracomment>
        <translation>Office Open XML-presentation (makroaktiverad)</translation>
    </message>
    <message>
        <source>Office Open XML Presentation Slideshow (macro-enabled)</source>
        <extracomment>application/vnd.ms-powerpoint.slideshow.macroenabled.12</extracomment>
        <translation>Office Open XML-presentationsbildspel (makroaktiverat)</translation>
    </message>
    <message>
        <source>Office Open XML Document (macro-enabled)</source>
        <extracomment>application/vnd.ms-word.document.macroenabled.12</extracomment>
        <translation>Office Open XML-dokument (makroaktiverat)</translation>
    </message>
    <message>
        <source>Office Open XML Document Template (macro-enabled)</source>
        <extracomment>application/vnd.ms-word.template.macroenabled.12</extracomment>
        <translation>Office Open XML-dokumentmall (makroaktiverad)</translation>
    </message>
    <message>
        <source>Open XML Paper Specification</source>
        <extracomment>application/vnd.ms-xpsdocument</extracomment>
        <translation>Open XML-pappersspecifikation</translation>
    </message>
    <message>
        <source>Magic Shadow Archiver</source>
        <extracomment>application/vnd.msa-disk-image</extracomment>
        <translation>Magic Shadow Archiver</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Chart document</source>
        <extracomment>application/vnd.oasis.opendocument.chart</extracomment>
        <translation>OpenDocument v1.0: Chart-dokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Chart document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.chart-template</extracomment>
        <translation>OpenDocument v1.0: Chart-dokument som används som mall</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Formula document</source>
        <extracomment>application/vnd.oasis.opendocument.formula</extracomment>
        <translation>OpenDocument v1.0: Formula-dokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Formula document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.formula-template</extracomment>
        <translation>OpenDocument v1.0: Formeldokument som används som mall</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Graphics document (Drawing)</source>
        <extracomment>application/vnd.oasis.opendocument.graphics</extracomment>
        <translation>OpenDocument v1.0: Grafikdokument (Ritning)</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Graphics document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.graphics-template</extracomment>
        <translation>OpenDocument v1.0: Grafikdokument som används som mall</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Image document</source>
        <extracomment>application/vnd.oasis.opendocument.image</extracomment>
        <translation>OpenDocument v1.0: Bilddokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Image document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.image-template</extracomment>
        <translation>OpenDocument v1.0: Bilddokument som används som mall</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Presentation document</source>
        <extracomment>application/vnd.oasis.opendocument.presentation</extracomment>
        <translation>OpenDocument v1.0: Presentationsdokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Presentation document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.presentation-template</extracomment>
        <translation>OpenDocument v1.0: Presentationsdokument som används som mall</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Spreadsheet document</source>
        <extracomment>application/vnd.oasis.opendocument.spreadsheet</extracomment>
        <translation>OpenDocument v1.0: Kalkylbladsdokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Spreadsheet document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.spreadsheet-template</extracomment>
        <translation>OpenDocument v1.0: Kalkylbladsdokument som används som mall</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Text document</source>
        <extracomment>application/vnd.oasis.opendocument.text</extracomment>
        <translation>OpenDocument v1.0: Textdokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Flat Text document</source>
        <extracomment>application/vnd.oasis.opendocument.tika.flat.document
----------
application/vnd.oasis.opendocument.flat.text</extracomment>
        <translation>OpenDocument v1.0: Platt textdokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Flat Presentation document</source>
        <extracomment>application/vnd.oasis.opendocument.flat.presentation</extracomment>
        <translation>OpenDocument v1.0: Platt presentationsdokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Flat Spreadsheet document</source>
        <extracomment>application/vnd.oasis.opendocument.flat.spreadsheet</extracomment>
        <translation>OpenDocument v1.0: Platt kalkylbladsdokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Global Text document</source>
        <extracomment>application/vnd.oasis.opendocument.text-master</extracomment>
        <translation>OpenDocument v1.0: Globalt textdokument</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Text document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.text-template</extracomment>
        <translation>OpenDocument v1.0: Textdokument som används som mall</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Text document used as template for HTML documents</source>
        <extracomment>application/vnd.oasis.opendocument.text-web</extracomment>
        <translation>OpenDocument v1.0: Textdokument som används som mall för HTML-dokument</translation>
    </message>
    <message>
        <source>Office Open XML Presentation</source>
        <extracomment>application/vnd.openxmlformats-officedocument.presentationml.presentation</extracomment>
        <translation>Office Open XML-presentation</translation>
    </message>
    <message>
        <source>Office Open XML Presentation Template</source>
        <extracomment>application/vnd.openxmlformats-officedocument.presentationml.template</extracomment>
        <translation>Office Open XML-presentationsmall</translation>
    </message>
    <message>
        <source>Office Open XML Presentation Slideshow</source>
        <extracomment>application/vnd.openxmlformats-officedocument.presentationml.slideshow</extracomment>
        <translation>Office Open XML-presentationsbildspel</translation>
    </message>
    <message>
        <source>Office Open XML Workbook</source>
        <extracomment>application/vnd.openxmlformats-officedocument.spreadsheetml.sheet</extracomment>
        <translation>Office Open XML-arbetsbok</translation>
    </message>
    <message>
        <source>Office Open XML Workbook Template</source>
        <extracomment>application/vnd.openxmlformats-officedocument.spreadsheetml.template</extracomment>
        <translation>Office Open XML-arbetsboksmall</translation>
    </message>
    <message>
        <source>Office Open XML Workbook Template (macro-enabled)</source>
        <extracomment>application/vnd.ms-excel.template.macroenabled.12</extracomment>
        <translation>Office Open XML-arbetsboksmall (makroaktiverad)</translation>
    </message>
    <message>
        <source>Office Open XML Document</source>
        <extracomment>application/vnd.openxmlformats-officedocument.wordprocessingml.document</extracomment>
        <translation>Office Open XML-dokument</translation>
    </message>
    <message>
        <source>Office Open XML Document Template</source>
        <extracomment>application/vnd.openxmlformats-officedocument.wordprocessingml.template</extracomment>
        <translation>Office Open XML-dokumentmall</translation>
    </message>
    <message>
        <source>SubRip (srt) subtitles</source>
        <extracomment>application/x-subrip</extracomment>
        <translation>SubRip (srt) undertexter</translation>
    </message>
    <message>
        <source>OpenOffice v1.0: Writer Document</source>
        <extracomment>application/vnd.sun.xml.writer</extracomment>
        <translation>OpenOffice v1.0: Writer-dokument</translation>
    </message>
    <message>
        <source>TCPDump pcap packet capture</source>
        <extracomment>application/vnd.tcpdump.pcap</extracomment>
        <translation>TCPDump pcap-paketfångst</translation>
    </message>
    <message>
        <source>TCPDump next gen pcap packet capture</source>
        <extracomment>application/vnd.tcpdump.pcapng</extracomment>
        <translation>TCPDump nästa generations pcap-paketfångst</translation>
    </message>
    <message>
        <source>TMX Translation Memory</source>
        <extracomment>application/x-tmx</extracomment>
        <translation>TMX-översättningsminne</translation>
    </message>
    <message>
        <source>Microsoft Visio Diagram</source>
        <extracomment>application/vnd.visio</extracomment>
        <translation>Microsoft Visio-diagram</translation>
    </message>
    <message>
        <source>Office Open XML Visio Drawing (macro-free)</source>
        <extracomment>application/vnd.ms-visio.drawing</extracomment>
        <translation>Office Open XML Visio-ritning (makrofri)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Template (macro-free)</source>
        <extracomment>application/vnd.ms-visio.template</extracomment>
        <translation>Office Open XML Visio-mall (makrofri)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Stencil (macro-free)</source>
        <extracomment>application/vnd.ms-visio.stencil</extracomment>
        <translation>Office Open XML Visio-stencil (makrofri)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Drawing (macro-enabled)</source>
        <extracomment>application/vnd.ms-visio.drawing.macroEnabled.12</extracomment>
        <translation>Office Open XML Visio-ritning (makroaktiverad)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Template (macro-enabled)</source>
        <extracomment>application/vnd.ms-visio.template.macroEnabled.12</extracomment>
        <translation>Office Open XML Visio-mall (makroaktiverad)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Stencil (macro-enabled)</source>
        <extracomment>application/vnd.ms-visio.stencil.macroEnabled.12</extracomment>
        <translation>Office Open XML Visio-stencil (makroaktiverad)</translation>
    </message>
    <message>
        <source>Compiled WML Document</source>
        <extracomment>application/vnd.wap.wmlc</extracomment>
        <translation>Kompilerat WML-dokument</translation>
    </message>
    <message>
        <source>Compiled WML Script</source>
        <extracomment>application/vnd.wap.wmlscriptc</extracomment>
        <translation>Kompilerat WML-skript</translation>
    </message>
    <message>
        <source>WordPerfect - Corel Word Processing</source>
        <extracomment>application/vnd.wordperfect</extracomment>
        <translation>WordPerfect - Corel Word Processing</translation>
    </message>
    <message>
        <source>WARC</source>
        <extracomment>application/warc
----------
application/warc+gz</extracomment>
        <translation>WARC</translation>
    </message>
    <message>
        <source>Web Assembly</source>
        <extracomment>application/wasm</extracomment>
        <translation>Web Assembly</translation>
    </message>
    <message>
        <source>Targa image data</source>
        <extracomment>image/x-tga</extracomment>
        <translation>Targa-bilddata</translation>
    </message>
    <message>
        <source>AxCrypt</source>
        <extracomment>application/x-axcrypt</extracomment>
        <translation>AxCrypt</translation>
    </message>
    <message>
        <source>Adobe InDesign document</source>
        <extracomment>application/x-adobe-indesign</extracomment>
        <translation>Adobe InDesign-dokument</translation>
    </message>
    <message>
        <source>Flow Cytometry Standard File</source>
        <extracomment>application/vnd.isac.fcs</extracomment>
        <translation>Flow Cytometry Standard File</translation>
    </message>
    <message>
        <source>IDML</source>
        <extracomment>application/vnd.adobe.indesign-idml-package</extracomment>
        <translation>IDML</translation>
    </message>
    <message>
        <source>Adobe InDesign Interchange format</source>
        <extracomment>application/x-adobe-indesign-interchange</extracomment>
        <translation>Adobe InDesign Interchange-format</translation>
    </message>
    <message>
        <source>ASPRS Lidar Data Exchange Format</source>
        <extracomment>application/x-asprs</extracomment>
        <translation>ASPRS Lidar Data Exchange Format</translation>
    </message>
    <message>
        <source>Berkeley DB</source>
        <extracomment>application/x-berkeley-db</extracomment>
        <translation>Berkeley DB</translation>
    </message>
    <message>
        <source>CD Audio</source>
        <extracomment>application/x-cdf</extracomment>
        <translation>CD-ljud</translation>
    </message>
    <message>
        <source>GNU tar Compressed File Archive (GNU Tape Archive)</source>
        <extracomment>application/x-gtar</extracomment>
        <translation>GNU tar-komprimerat filarkiv (GNU Tape Archive)</translation>
    </message>
    <message>
        <source>Guitar Pro</source>
        <extracomment>application/x-guitar-pro</extracomment>
        <translation>Guitar Pro</translation>
    </message>
    <message>
        <source>Amiga Disk File</source>
        <extracomment>application/x-amiga-disk-format</extracomment>
        <translation>Amiga Disk File</translation>
    </message>
    <message>
        <source>Bzip 2 UNIX Compressed File</source>
        <extracomment>application/x-bzip2</extracomment>
        <translation>Bzip 2 UNIX-komprimerad fil</translation>
    </message>
    <message>
        <source>Virtual CD-ROM CD Image File</source>
        <extracomment>application/x-cdlink</extracomment>
        <translation>Virtuell CD-ROM cd-avbildningsfil</translation>
    </message>
    <message>
        <source>Chrome Extension Package</source>
        <extracomment>application/x-chrome-package</extracomment>
        <translation>Chrome-tilläggspaket</translation>
    </message>
    <message>
        <source>UNIX CPIO Archive</source>
        <extracomment>application/x-cpio</extracomment>
        <translation>UNIX CPIO-arkiv</translation>
    </message>
    <message>
        <source>Dalvik Executable Format</source>
        <extracomment>application/x-dex</extracomment>
        <translation>Dalvik Executable-format</translation>
    </message>
    <message>
        <source>Shockwave Movie</source>
        <extracomment>application/x-director</extracomment>
        <translation>Shockwave Movie</translation>
    </message>
    <message>
        <source>TeX Device Independent Document</source>
        <extracomment>application/x-dvi</extracomment>
        <translation>TeX Device Independent Document</translation>
    </message>
    <message>
        <source>Emacs Lisp bytecode</source>
        <extracomment>application/x-elc</extracomment>
        <translation>Emacs Lisp-bytekod</translation>
    </message>
    <message>
        <source>fat disk image; extensions: ima, img, dsk</source>
        <extracomment>application/x-fat-diskimage</extracomment>
        <translation>fat disk image; ändelser: ima, img, dsk</translation>
    </message>
    <message>
        <source>KIllustrator File</source>
        <extracomment>application/x-killustrator</extracomment>
        <translation>KIllustrator-fil</translation>
    </message>
    <message>
        <source>Modified Maximum Method Digisonde Portable Sounder File format</source>
        <extracomment>application/x-mmm-digisonde</extracomment>
        <translation>Filformat för Modified Maximum Method Digisonde bärbar ionosond</translation>
    </message>
    <message>
        <source>DOS/Windows executable (EXE)</source>
        <extracomment>application/x-dosexec</extracomment>
        <translation>DOS/Windows körbar fil (EXE)</translation>
    </message>
    <message>
        <source>FileMaker Pro 7</source>
        <extracomment>application/x-filemaker</extracomment>
        <translation>FileMaker Pro 7</translation>
    </message>
    <message>
        <source>OpenType Font</source>
        <extracomment>application/x-font-otf</extracomment>
        <translation>OpenType Font</translation>
    </message>
    <message>
        <source>TrueType Font</source>
        <extracomment>application/x-font-ttf</extracomment>
        <translation>TrueType Font</translation>
    </message>
    <message>
        <source>Adobe Font Metric</source>
        <extracomment>application/x-font-adobe-metric</extracomment>
        <translation>Adobe Font Metric</translation>
    </message>
    <message>
        <source>Printer Font Metric</source>
        <extracomment>application/x-font-printer-metric</extracomment>
        <translation>Printer Font Metric</translation>
    </message>
    <message>
        <source>Foxmail Email File</source>
        <extracomment>application/x-foxmail</extracomment>
        <translation>Foxmail-epostfil</translation>
    </message>
    <message>
        <source>Macromedia FutureSplash File</source>
        <extracomment>application/x-futuresplash</extracomment>
        <translation>Macromedia FutureSplash-fil</translation>
    </message>
    <message>
        <source>General Regularly-distributed Information in Binary form</source>
        <extracomment>application/x-grib</extracomment>
        <translation>General Regularly-distributed Information in Binary form</translation>
    </message>
    <message>
        <source>Gzip Compressed Archive</source>
        <extracomment>application/gzip</extracomment>
        <translation>Gzip-komprimerat arkiv</translation>
    </message>
    <message>
        <source>https://en.wikipedia.org/wiki/Zstandard</source>
        <extracomment>application/zstd</extracomment>
        <translation>https://en.wikipedia.org/wiki/Zstandard</translation>
    </message>
    <message>
        <source>ESRI Layer file</source>
        <extracomment>application/x-esri-layer</extracomment>
        <translation>ESRI Layer-fil</translation>
    </message>
    <message>
        <source>Hierarchical Data Format File</source>
        <extracomment>application/x-hdf</extracomment>
        <translation>Hierarchical Data Format-fil</translation>
    </message>
    <message>
        <source>Hangul Word Processor File</source>
        <extracomment>application/x-hwp</extracomment>
        <translation>Hangul Word Processor-fil</translation>
    </message>
    <message>
        <source>Hangul Word Processor File v5</source>
        <extracomment>application/x-hwp-v5</extracomment>
        <translation>Hangul Word Processor-fil v5</translation>
    </message>
    <message>
        <source>Hangul Word Processor File, zip based</source>
        <extracomment>application/hwp+zip</extracomment>
        <translation>Hangul Word Processor-fil, zip baserad</translation>
    </message>
    <message>
        <source>Apple iBooks Author publication format</source>
        <extracomment>application/x-ibooks+zip</extracomment>
        <translation>Apple iBooks Author-publiceringsformat</translation>
    </message>
    <message>
        <source>NV5 Geospatial Interactive Data Language Save File</source>
        <extracomment>application/x-idl-save-file</extracomment>
        <translation>NV5 Geospatial Interactive Data Language Save File</translation>
    </message>
    <message>
        <source>ARC</source>
        <extracomment>application/x-internet-archive</extracomment>
        <translation>ARC</translation>
    </message>
    <message>
        <source>ISA-Tab Investigation file</source>
        <extracomment>application/x-isatab-investigation</extracomment>
        <translation>ISA-Tab Investigation-fil</translation>
    </message>
    <message>
        <source>ISA-Tab Study file</source>
        <extracomment>application/x-isatab</extracomment>
        <translation>ISA-Tab Study-fil</translation>
    </message>
    <message>
        <source>ISA-Tab Assay file</source>
        <extracomment>application/x-isatab-assay</extracomment>
        <translation>ISA-Tab Assay-fil</translation>
    </message>
    <message>
        <source>ISO 9660 CD-ROM filesystem data</source>
        <extracomment>application/x-iso9660-image</extracomment>
        <translation>ISO 9660 CD-ROM-filsystemsdata</translation>
    </message>
    <message>
        <source>Apple iTunes Binary Property List</source>
        <extracomment>application/x-itunes-bplist</extracomment>
        <translation>Apple iTunes Binary Property List</translation>
    </message>
    <message>
        <source>Apple iOS IPA AppStore file</source>
        <extracomment>application/x-itunes-ipa</extracomment>
        <translation>Apple iOS IPA AppStore-fil</translation>
    </message>
    <message>
        <source>JDF NMR Spectroscopy</source>
        <extracomment>application/x-jeol-jdf</extracomment>
        <translation>JDF NMR Spectroscopy</translation>
    </message>
    <message>
        <source>Jigsaw Download</source>
        <extracomment>application/x-jigdo</extracomment>
        <translation>Jigsaw-hämtning</translation>
    </message>
    <message>
        <source>LaTeX Source Document</source>
        <extracomment>application/x-latex</extracomment>
        <translation>LaTeX-källdokument</translation>
    </message>
    <message>
        <source>First match LZ4 Frame</source>
        <extracomment>application/x-lz4</extracomment>
        <translation>First match LZ4 Frame</translation>
    </message>
    <message>
        <source>Lzip (LZMA) compressed archive</source>
        <extracomment>application/x-lzip</extracomment>
        <translation>Lzip-komprimerat arkiv (LZMA)</translation>
    </message>
    <message>
        <source>LZMA compressed archive</source>
        <extracomment>application/x-lzma</extracomment>
        <translation>LZMA-komprimerat arkiv</translation>
    </message>
    <message>
        <source>Mach-O</source>
        <extracomment>application/x-mach-o</extracomment>
        <translation>Mach-O</translation>
    </message>
    <message>
        <source>Mach-O relocatable object file</source>
        <extracomment>application/x-mach-o-object</extracomment>
        <translation>Mach-O flyttbar objektfil</translation>
    </message>
    <message>
        <source>Mach-O executable</source>
        <extracomment>application/x-mach-o-executable</extracomment>
        <translation>Mach-O körbar fil</translation>
    </message>
    <message>
        <source>Mach-O fixed VM shared library</source>
        <extracomment>application/x-mach-o-fvmlib</extracomment>
        <translation>Mach-O fast VM-delat bibliotek</translation>
    </message>
    <message>
        <source>Mach-O core file</source>
        <extracomment>application/x-mach-o-core</extracomment>
        <translation>Mach-O core file</translation>
    </message>
    <message>
        <source>Mach-O preloaded executable</source>
        <extracomment>application/x-mach-o-preload</extracomment>
        <translation>Mach-O förinläst körbar fil</translation>
    </message>
    <message>
        <source>Mach-O dynamic shared library</source>
        <extracomment>application/x-mach-o-dylib</extracomment>
        <translation>Mach-O dynamiskt delat bibliotek</translation>
    </message>
    <message>
        <source>Mach-O dynamic link editor</source>
        <extracomment>application/x-mach-o-dylinker</extracomment>
        <translation>Mach-O dynamic link editor</translation>
    </message>
    <message>
        <source>Mach-O dynamic bundle</source>
        <extracomment>application/x-mach-o-bundle</extracomment>
        <translation>Mach-O dynamic bundle</translation>
    </message>
    <message>
        <source>Mach-O shared library for static linking</source>
        <extracomment>application/x-mach-o-dylib-stub</extracomment>
        <translation>Mach-O-delat bibliotek för statisk länkning</translation>
    </message>
    <message>
        <source>Mach-O debug symbols file</source>
        <extracomment>application/x-mach-o-dsym</extracomment>
        <translation>Mach-O debug symbols file</translation>
    </message>
    <message>
        <source>Mach-O kext bundle</source>
        <extracomment>application/x-mach-o-kext-bundle</extracomment>
        <translation>Mach-O kext bundle</translation>
    </message>
    <message>
        <source>Apple Xcode Memgraph</source>
        <extracomment>application/x-memgraph</extracomment>
        <translation>Apple Xcode Memgraph</translation>
    </message>
    <message>
        <source>Mobipocket Ebook</source>
        <extracomment>application/x-mobipocket-ebook</extracomment>
        <translation>Mobipocket Ebook</translation>
    </message>
    <message>
        <source>MS-DOS compression szzd</source>
        <extracomment>application/x-ms-compress-szdd</extracomment>
        <translation>MS-DOS-komprimerad szzd</translation>
    </message>
    <message>
        <source>Temporary files created by MSOffice applications</source>
        <extracomment>application/x-ms-owner</extracomment>
        <translation>Temporärfiler skapade av MSOffice-applikationer</translation>
    </message>
    <message>
        <source>Microsoft National Language Support</source>
        <extracomment>application/x-ms-nls</extracomment>
        <translation>Microsoft National Language Support</translation>
    </message>
    <message>
        <source>Microsoft Windows Installer</source>
        <extracomment>application/x-ms-installer</extracomment>
        <translation>Microsoft Windows-installationsprogram</translation>
    </message>
    <message>
        <source>MySQL Table Definition (Format)</source>
        <extracomment>application/x-mysql-table-definition</extracomment>
        <translation>MySQL-tabelldefinition (Format)</translation>
    </message>
    <message>
        <source>MySQL MISAM Index</source>
        <extracomment>application/x-mysql-misam-index</extracomment>
        <translation>MySQL MISAM Index</translation>
    </message>
    <message>
        <source>MySQL MISAM Compressed Index</source>
        <extracomment>application/x-mysql-misam-compressed-index</extracomment>
        <translation>MySQL MISAM-komprimerat Index</translation>
    </message>
    <message>
        <source>MySQL MISAM Data</source>
        <extracomment>application/x-mysql-misam-data</extracomment>
        <translation>MySQL MISAM Data</translation>
    </message>
    <message>
        <source>Nintendo Entertainment System ROM</source>
        <extracomment>application/x-nesrom</extracomment>
        <translation>Nintendo Entertainment System ROM</translation>
    </message>
    <message>
        <source>Planetary Data System Version 3 format</source>
        <extracomment>application/x-pds</extracomment>
        <translation>Planetary Data System Version 3 format</translation>
    </message>
    <message>
        <source>Quattro Pro - Corel Spreadsheet (part of WordPerfect Office suite)</source>
        <extracomment>application/x-quattro-pro</extracomment>
        <translation>Quattro Pro - Corel Spreadsheet (del av WordPerfect Office-sviten)</translation>
    </message>
    <message>
        <source>Quattro Pro for DOS, version 1-4</source>
        <extracomment>application/x-quattro-pro;version=1-4</extracomment>
        <translation>Quattro Pro för DOS, version 1-4</translation>
    </message>
    <message>
        <source>Quattro Pro for DOS, version 5</source>
        <extracomment>application/x-quattro-pro;version=5</extracomment>
        <translation>Quattro Pro för DOS, version 5</translation>
    </message>
    <message>
        <source>Quattro Pro for Windows, version 1, 5</source>
        <extracomment>application/x-quattro-pro;version=1+5</extracomment>
        <translation>Quattro Pro för Windows, version 1, 5</translation>
    </message>
    <message>
        <source>Quattro Pro for Windows, version 6</source>
        <extracomment>application/x-quattro-pro;version=6</extracomment>
        <translation>Quattro Pro för Windows, version 6</translation>
    </message>
    <message>
        <source>XQuery source code</source>
        <extracomment>application/xquery</extracomment>
        <translation>XQuery-källkod</translation>
    </message>
    <message>
        <source>RAR archive</source>
        <extracomment>application/x-rar-compressed
----------
application/x-rar-compressed;version=4
----------
application/x-rar-compressed;version=5</extracomment>
        <translation>RAR-arkiv</translation>
    </message>
    <message>
        <source>RedHat Package Manager</source>
        <extracomment>application/x-rpm</extracomment>
        <translation>RedHat-pakethanterare</translation>
    </message>
    <message>
        <source>SAS Program</source>
        <extracomment>application/x-sas</extracomment>
        <translation>SAS Program</translation>
    </message>
    <message>
        <source>SAS Stored Program (DATA Step)</source>
        <extracomment>application/x-sas-program-data</extracomment>
        <translation>SAS Stored Program (DATA Step)</translation>
    </message>
    <message>
        <source>SAS Audit</source>
        <extracomment>application/x-sas-audit</extracomment>
        <translation>SAS Audit</translation>
    </message>
    <message>
        <source>SAS v6 Data Set</source>
        <extracomment>application/x-sas-data-v6</extracomment>
        <translation>SAS v6 Data Set</translation>
    </message>
    <message>
        <source>SAS Data Set</source>
        <extracomment>application/x-sas-data</extracomment>
        <translation>SAS Data Set</translation>
    </message>
    <message>
        <source>SAS Data Set View</source>
        <extracomment>application/x-sas-view</extracomment>
        <translation>SAS Data Set View</translation>
    </message>
    <message>
        <source>SAS Data Set Index</source>
        <extracomment>application/x-sas-data-index</extracomment>
        <translation>SAS Data Set Index</translation>
    </message>
    <message>
        <source>SAS Catalog</source>
        <extracomment>application/x-sas-catalog</extracomment>
        <translation>SAS Catalog</translation>
    </message>
    <message>
        <source>SAS Access Descriptor</source>
        <extracomment>application/x-sas-access</extracomment>
        <translation>SAS Access Descriptor</translation>
    </message>
    <message>
        <source>SAS FDB Consolidation Database File</source>
        <extracomment>application/x-sas-fdb</extracomment>
        <translation>SAS FDB Consolidation Database File</translation>
    </message>
    <message>
        <source>SAS MDDB Multi-Dimensional Database File</source>
        <extracomment>application/x-sas-mddb</extracomment>
        <translation>SAS MDDB Multi-Dimensional Database File</translation>
    </message>
    <message>
        <source>SAS DMDB Data Mining Database File</source>
        <extracomment>application/x-sas-dmdb</extracomment>
        <translation>SAS DMDB Data Mining Database File</translation>
    </message>
    <message>
        <source>SAS Item Store (ItemStor) File</source>
        <extracomment>application/x-sas-itemstor</extracomment>
        <translation>SAS Item Store (ItemStor) File</translation>
    </message>
    <message>
        <source>SAS Utility</source>
        <extracomment>application/x-sas-utility</extracomment>
        <translation>SAS Utility</translation>
    </message>
    <message>
        <source>SAS Permanent Utility</source>
        <extracomment>application/x-sas-putility</extracomment>
        <translation>SAS Permanent Utility</translation>
    </message>
    <message>
        <source>SAS Transport File</source>
        <extracomment>application/x-sas-transport</extracomment>
        <translation>SAS Transport File</translation>
    </message>
    <message>
        <source>SAS Backup</source>
        <extracomment>application/x-sas-backup</extracomment>
        <translation>SAS Backup</translation>
    </message>
    <message>
        <source>SAS XPORT Transfer File</source>
        <extracomment>application/x-sas-xport</extracomment>
        <translation>SAS XPORT Transfer File</translation>
    </message>
    <message>
        <source>SPSS Data File</source>
        <extracomment>application/x-spss-sav</extracomment>
        <translation>SPSS Data File</translation>
    </message>
    <message>
        <source>UNIX/LINUX Shell Script</source>
        <extracomment>application/x-sh</extracomment>
        <translation>UNIX/LINUX-skalskript</translation>
    </message>
    <message>
        <source>ESRI Shapefiles</source>
        <extracomment>application/x-shapefile</extracomment>
        <translation>ESRI Shapefiles</translation>
    </message>
    <message>
        <source>Adobe Flash</source>
        <extracomment>application/x-shockwave-flash</extracomment>
        <translation>Adobe Flash</translation>
    </message>
    <message>
        <source>Sibelius</source>
        <extracomment>application/x-sibelius</extracomment>
        <translation>Sibelius</translation>
    </message>
    <message>
        <source>Snappy Framed</source>
        <extracomment>application/x-snappy-framed</extracomment>
        <translation>Snappy Framed</translation>
    </message>
    <message>
        <source>Standard Formatted Data Units (SFDUs) data</source>
        <extracomment>application/x-sfdu</extracomment>
        <translation>Standard Formatted Data Units (SFDUs) data</translation>
    </message>
    <message>
        <source>TAP (ZX Spectrum)</source>
        <extracomment>application/x-spectrum-tzx</extracomment>
        <translation>TAP (ZX Spectrum)</translation>
    </message>
    <message>
        <source>Stata DTA Script</source>
        <extracomment>application/x-stata-do</extracomment>
        <translation>Stata DTA Script</translation>
    </message>
    <message>
        <source>Stata DTA Dataset</source>
        <extracomment>application/x-stata-dta</extracomment>
        <translation>Stata DTA Dataset</translation>
    </message>
    <message>
        <source>TeX Source</source>
        <extracomment>application/x-tex</extracomment>
        <translation>TeX-källa</translation>
    </message>
    <message>
        <source>TeX Virtual Font format</source>
        <extracomment>application/x-tex-virtual-font</extracomment>
        <translation>TeX Virtual Font-format</translation>
    </message>
    <message>
        <source>Pre-OLE2 (Old) Microsoft Excel Worksheets</source>
        <extracomment>application/x-tika-old-excel</extracomment>
        <translation>Före-OLE2 (Gammal) Microsoft Excel-arbetsblad</translation>
    </message>
    <message>
        <source>Password Protected OOXML File</source>
        <extracomment>application/x-tika-ooxml-protected</extracomment>
        <translation>Lösenordsskyddad OOXML-fil</translation>
    </message>
    <message>
        <source>Visio OOXML File</source>
        <extracomment>application/x-tika-visio-ooxml</extracomment>
        <translation>Visio OOXML-fil</translation>
    </message>
    <message>
        <source>Virtual PC Virtual Hard Disk</source>
        <extracomment>application/x-vhd</extracomment>
        <translation>Virtuell PC Virtuell hårddisk</translation>
    </message>
    <message>
        <source>Virtual Disk Format</source>
        <extracomment>application/x-vmdk</extracomment>
        <translation>Virtuellt diskformat</translation>
    </message>
    <message>
        <source>Java Keystore</source>
        <extracomment>application/x-java-keystore</extracomment>
        <translation>Java Keystore</translation>
    </message>
    <message>
        <source>XMind Pro</source>
        <extracomment>application/x-xmind</extracomment>
        <translation>XMind Pro</translation>
    </message>
    <message>
        <source>Zeno IMproved (ZIM)</source>
        <extracomment>application/x-zim</extracomment>
        <translation>Zeno IMproved (ZIM)</translation>
    </message>
    <message>
        <source>Extensible Markup Language</source>
        <extracomment>application/xml</extracomment>
        <translation>eXtensible Markup Language</translation>
    </message>
    <message>
        <source>XML Document Type Definition</source>
        <extracomment>application/xml-dtd</extracomment>
        <translation>XML Document Type Definition</translation>
    </message>
    <message>
        <source>XSL Format</source>
        <extracomment>application/xslfo+xml</extracomment>
        <translation>XSL Format</translation>
    </message>
    <message>
        <source>XSL Transformations</source>
        <extracomment>application/xslt+xml</extracomment>
        <translation>XSL Transformations</translation>
    </message>
    <message>
        <source>XML Shareable Playlist Format</source>
        <extracomment>application/xspf+xml</extracomment>
        <translation>XML Shareable Playlist Format</translation>
    </message>
    <message>
        <source>Compressed Archive File</source>
        <extracomment>application/zip</extracomment>
        <translation>Komprimerad arkivfil</translation>
    </message>
    <message>
        <source>ZLIB Compressed Data Format</source>
        <extracomment>application/zlib</extracomment>
        <translation>ZLIB-komprimerat dataformat</translation>
    </message>
    <message>
        <source>7-zip archive</source>
        <extracomment>application/x-7z-compressed</extracomment>
        <translation>7-zip-arkiv</translation>
    </message>
    <message>
        <source>Dolby Digital Audio Compression File</source>
        <extracomment>audio/ac3</extracomment>
        <translation>Dolby Digital Audio-komprimeringsfil</translation>
    </message>
    <message>
        <source>uLaw/AU Audio File</source>
        <extracomment>audio/basic</extracomment>
        <translation>uLaw/AU-ljudfil</translation>
    </message>
    <message>
        <source>Musical Instrument Digital Interface</source>
        <extracomment>audio/midi</extracomment>
        <translation>Musical Instrument Digital Interface</translation>
    </message>
    <message>
        <source>MPEG-1 Audio Layer 3</source>
        <extracomment>audio/mpeg</extracomment>
        <translation>MPEG-1 Audio Layer 3</translation>
    </message>
    <message>
        <source>Ogg Vorbis Audio</source>
        <extracomment>audio/ogg</extracomment>
        <translation>Ogg Vorbis Audio</translation>
    </message>
    <message>
        <source>Ogg Vorbis Codec Compressed WAV File</source>
        <extracomment>audio/vorbis</extracomment>
        <translation>Ogg Vorbis Codec-komprimerad WAV-fil</translation>
    </message>
    <message>
        <source>Portable Sound Format</source>
        <extracomment>audio/x-psf</extracomment>
        <translation>Portable Sound Format</translation>
    </message>
    <message>
        <source>Slight Atari Player</source>
        <extracomment>audio/x-sap</extracomment>
        <translation>Slight Atari Player</translation>
    </message>
    <message>
        <source>Ogg Packaged Free Lossless Audio Codec</source>
        <extracomment>audio/x-oggflac</extracomment>
        <translation>Ogg-paketerad Free Lossless Audio Codec</translation>
    </message>
    <message>
        <source>Ogg Packaged Unompressed WAV File</source>
        <extracomment>audio/x-oggpcm</extracomment>
        <translation>Ogg-paketerad okomprimerad WAV-fil</translation>
    </message>
    <message>
        <source>Ogg Opus Codec Compressed WAV File</source>
        <extracomment>audio/opus</extracomment>
        <translation>Ogg Opus Codec-komprimerad WAV-fil</translation>
    </message>
    <message>
        <source>Ogg Speex Codec Compressed WAV File</source>
        <extracomment>audio/speex</extracomment>
        <translation>Ogg Speex Codec-komprimerad WAV-fil</translation>
    </message>
    <message>
        <source>Audio Interchange File Format</source>
        <extracomment>audio/x-aiff</extracomment>
        <translation>Audio Interchange File Format</translation>
    </message>
    <message>
        <source>Core Audio Format</source>
        <extracomment>audio/x-caf</extracomment>
        <translation>Core Audio Format</translation>
    </message>
    <message>
        <source>Free Lossless Audio Codec</source>
        <extracomment>audio/x-flac</extracomment>
        <translation>Free Lossless Audio Codec</translation>
    </message>
    <message>
        <source>MP3 Playlist File</source>
        <extracomment>audio/x-mpegurl</extracomment>
        <translation>MP3-spellistefil</translation>
    </message>
    <message>
        <source>Real Audio</source>
        <extracomment>audio/x-pn-realaudio</extracomment>
        <translation>Real Audio</translation>
    </message>
    <message>
        <source>RealMedia Player Plug-in</source>
        <extracomment>audio/x-pn-realaudio-plugin</extracomment>
        <translation>RealMedia Player Plug-in</translation>
    </message>
    <message>
        <source>Brookhaven Protein Databank File</source>
        <extracomment>chemical/x-pdb</extracomment>
        <translation>Brookhaven Protein Databank File</translation>
    </message>
    <message>
        <source>3D Studio (V1)</source>
        <extracomment>image/x-3ds</extracomment>
        <translation>3D Studio (V1)</translation>
    </message>
    <message>
        <source>ACES Image Container File</source>
        <extracomment>image/aces</extracomment>
        <translation>ACES Image Container File</translation>
    </message>
    <message>
        <source>OS2 bitmap array</source>
        <extracomment>image/x-os2-graphics; charset=binary</extracomment>
        <translation>OS2 bitmap array</translation>
    </message>
    <message>
        <source>Windows bitmap</source>
        <extracomment>image/bmp</extracomment>
        <translation>Windows bitmap</translation>
    </message>
    <message>
        <source>Better Portable Graphics</source>
        <extracomment>image/x-bpg</extracomment>
        <translation>Better Portable Graphics</translation>
    </message>
    <message>
        <source>Computer Graphics Metafile</source>
        <extracomment>image/cgm</extracomment>
        <translation>Computer Graphics Metafile</translation>
    </message>
    <message>
        <source>Digital Picture Exchange from SMPTE</source>
        <extracomment>image/x-dpx</extracomment>
        <translation>Digital Picture Exchange från SMPTE</translation>
    </message>
    <message>
        <source>Enhanced Metafile</source>
        <extracomment>image/emf</extracomment>
        <translation>Enhanced Metafile</translation>
    </message>
    <message>
        <source>Compressed Enhanced Metafile</source>
        <extracomment>image/x-emf-compressed</extracomment>
        <translation>Compressed Enhanced Metafile</translation>
    </message>
    <message>
        <source>Graphics Interchange Format</source>
        <extracomment>image/gif</extracomment>
        <translation>Graphics Interchange Format</translation>
    </message>
    <message>
        <source>AV1 Image File</source>
        <extracomment>image/avif</extracomment>
        <translation>AV1 Image File</translation>
    </message>
    <message>
        <source>HEIF - High Efficiency Image File</source>
        <extracomment>image/heif</extracomment>
        <translation>HEIF - High Efficiency Image File</translation>
    </message>
    <message>
        <source>HEIF Sequence - High Efficiency Image Sequence</source>
        <extracomment>image/heif-sequence</extracomment>
        <translation>HEIF Sequence - High Efficiency Image Sequence</translation>
    </message>
    <message>
        <source>HEIF Image using HEVC Codec</source>
        <extracomment>image/heic</extracomment>
        <translation>HEIF Image med HEVC Codec</translation>
    </message>
    <message>
        <source>HEIF Sequence using HEVC Codec</source>
        <extracomment>image/heic-sequence</extracomment>
        <translation>HEIF Sequence med HEVC Codec</translation>
    </message>
    <message>
        <source>Apple Icon Image Format</source>
        <extracomment>image/icns</extracomment>
        <translation>Apple Icon Image Format</translation>
    </message>
    <message>
        <source>JPEG 2000 Part 1 (JP2)</source>
        <extracomment>image/jp2</extracomment>
        <translation>JPEG 2000 Part 1 (JP2)</translation>
    </message>
    <message>
        <source>Joint Photographic Experts Group</source>
        <extracomment>image/jpeg</extracomment>
        <translation>Joint Photographic Experts Group</translation>
    </message>
    <message>
        <source>JPEG 2000 Part 6 (JPM)</source>
        <extracomment>image/jpm</extracomment>
        <translation>JPEG 2000 Part 6 (JPM)</translation>
    </message>
    <message>
        <source>JPEG 2000 Part 2 (JPX)</source>
        <extracomment>image/jpx</extracomment>
        <translation>JPEG 2000 Part 2 (JPX)</translation>
    </message>
    <message>
        <source>Portable Network Graphics</source>
        <extracomment>image/png</extracomment>
        <translation>Portable Network Graphics</translation>
    </message>
    <message>
        <source>Scalable Vector Graphics</source>
        <extracomment>image/svg+xml</extracomment>
        <translation>Scalable Vector Graphics</translation>
    </message>
    <message>
        <source>Tagged Image File Format</source>
        <extracomment>image/tiff</extracomment>
        <translation>Tagged Image File Format</translation>
    </message>
    <message>
        <source>Photoshop Image</source>
        <extracomment>image/vnd.adobe.photoshop</extracomment>
        <translation>Photoshop-bild</translation>
    </message>
    <message>
        <source>MicroStation v7 drawing</source>
        <extracomment>image/vnd.dgn;version=7</extracomment>
        <translation>MicroStation v7 drawing</translation>
    </message>
    <message>
        <source>MicroStation v8 drawing; requires ole2 detector</source>
        <extracomment>image/vnd.dgn;version=8</extracomment>
        <translation>MicroStation v8 drawing; kräver ole2 detector</translation>
    </message>
    <message>
        <source>AutoCad Drawing</source>
        <extracomment>image/vnd.dwg</extracomment>
        <translation>AutoCad Drawing</translation>
    </message>
    <message>
        <source>AutoCAD DXF simplified Binary</source>
        <extracomment>image/vnd.dxb</extracomment>
        <translation>AutoCAD DXF förenklad binär</translation>
    </message>
    <message>
        <source>AutoCAD DXF</source>
        <extracomment>image/vnd.dxf</extracomment>
        <translation>AutoCAD DXF</translation>
    </message>
    <message>
        <source>Microsoft Document Imaging</source>
        <extracomment>image/vnd.ms-modi</extracomment>
        <translation>Microsoft Document Imaging</translation>
    </message>
    <message>
        <source>Wireless Bitmap File Format</source>
        <extracomment>image/vnd.wap.wbmp</extracomment>
        <translation>Wireless Bitmap File Format</translation>
    </message>
    <message>
        <source>ZSoft Multi-Page Paintbrush</source>
        <extracomment>image/vnd.zbrush.dcx</extracomment>
        <translation>ZSoft Multi-Page Paintbrush</translation>
    </message>
    <message>
        <source>ZSoft Paintbrush PiCture eXchange</source>
        <extracomment>image/vnd.zbrush.pcx</extracomment>
        <translation>ZSoft Paintbrush PiCture eXchange</translation>
    </message>
    <message>
        <source>Windows Metafile</source>
        <extracomment>image/wmf</extracomment>
        <translation>Windows Metafile</translation>
    </message>
    <message>
        <source>FreeHand image</source>
        <extracomment>image/x-freehand</extracomment>
        <translation>FreeHand-bild</translation>
    </message>
    <message>
        <source>A lossless image compression standard from the
      Joint Bi-level Image Experts Group.</source>
        <extracomment>image/x-jbig2</extracomment>
        <translation>En förlustfri bildkomprimeringsstandard från
      Joint Bi-level Image Experts Group.</translation>
    </message>
    <message>
        <source>JPEG 2000 Codestream</source>
        <extracomment>image/x-jp2-codestream</extracomment>
        <translation>JPEG 2000 Codestream</translation>
    </message>
    <message>
        <source>JPEG 2000 Container Format</source>
        <extracomment>image/x-jp2-container</extracomment>
        <translation>JPEG 2000 Container Format</translation>
    </message>
    <message>
        <source>JPEG XL</source>
        <extracomment>image/jxl</extracomment>
        <translation>JPEG XL</translation>
    </message>
    <message>
        <source>Navy Interchange File Format</source>
        <extracomment>image/x-niff</extracomment>
        <translation>Navy Interchange File Format</translation>
    </message>
    <message>
        <source>Apple Macintosh QuickDraw/PICT Format</source>
        <extracomment>image/x-pict</extracomment>
        <translation>Apple Macintosh QuickDraw/PICT Format</translation>
    </message>
    <message>
        <source>Portable Any Map</source>
        <extracomment>image/x-portable-anymap</extracomment>
        <translation>Portable Any Map</translation>
    </message>
    <message>
        <source>Portable Bit Map</source>
        <extracomment>image/x-portable-bitmap</extracomment>
        <translation>Portable Bit Map</translation>
    </message>
    <message>
        <source>Portable Graymap Graphic</source>
        <extracomment>image/x-portable-graymap</extracomment>
        <translation>Portable Graymap Graphic</translation>
    </message>
    <message>
        <source>UNIX Portable Bitmap Graphic</source>
        <extracomment>image/x-portable-pixmap</extracomment>
        <translation>UNIX Portable Bitmap Graphic</translation>
    </message>
    <message>
        <source>UNIX Portable Bitmap Graphic Arbitrary Map</source>
        <extracomment>image/x-portable-arbitrarymap</extracomment>
        <translation>UNIX Portable Bitmap Graphic Arbitrary Map</translation>
    </message>
    <message>
        <source>Adobe Digital Negative</source>
        <extracomment>image/x-raw-adobe</extracomment>
        <translation>Adobe Digital Negative</translation>
    </message>
    <message>
        <source>Hasselblad raw image</source>
        <extracomment>image/x-raw-hasselblad</extracomment>
        <translation>Hasselblad råbild</translation>
    </message>
    <message>
        <source>Fuji raw image</source>
        <extracomment>image/x-raw-fuji</extracomment>
        <translation>Fuji råbild</translation>
    </message>
    <message>
        <source>Canon raw image</source>
        <extracomment>image/x-raw-canon</extracomment>
        <translation>Canon råbild</translation>
    </message>
    <message>
        <source>Canon raw image, version 2, TIFF-based</source>
        <extracomment>image/x-canon-cr2</extracomment>
        <translation>Canon råbild, version 2, TIFF-baserad</translation>
    </message>
    <message>
        <source>Canon raw image, version 3, Quicktime-based</source>
        <extracomment>image/x-canon-cr3</extracomment>
        <translation>Canon råbild, version 3, Quicktime-baserad</translation>
    </message>
    <message>
        <source>Kodak raw image</source>
        <extracomment>image/x-raw-kodak</extracomment>
        <translation>Kodak råbild</translation>
    </message>
    <message>
        <source>Minolta raw image</source>
        <extracomment>image/x-raw-minolta</extracomment>
        <translation>Minolta råbild</translation>
    </message>
    <message>
        <source>Nikon raw image</source>
        <extracomment>image/x-raw-nikon</extracomment>
        <translation>Nikon råbild</translation>
    </message>
    <message>
        <source>Olympus raw image</source>
        <extracomment>image/x-raw-olympus</extracomment>
        <translation>Olympus råbild</translation>
    </message>
    <message>
        <source>Pentax raw image</source>
        <extracomment>image/x-raw-pentax</extracomment>
        <translation>Pentax råbild</translation>
    </message>
    <message>
        <source>Sony raw image</source>
        <extracomment>image/x-raw-sony</extracomment>
        <translation>Sony råbild</translation>
    </message>
    <message>
        <source>Sigma raw image</source>
        <extracomment>image/x-raw-sigma</extracomment>
        <translation>Sigma råbild</translation>
    </message>
    <message>
        <source>Epson raw image</source>
        <extracomment>image/x-raw-epson</extracomment>
        <translation>Epson råbild</translation>
    </message>
    <message>
        <source>Mamiya raw image</source>
        <extracomment>image/x-raw-mamiya</extracomment>
        <translation>Mamiya råbild</translation>
    </message>
    <message>
        <source>Leaf raw image</source>
        <extracomment>image/x-raw-leaf</extracomment>
        <translation>Leaf råbild</translation>
    </message>
    <message>
        <source>Panasonic raw image</source>
        <extracomment>image/x-raw-panasonic</extracomment>
        <translation>Panasonic råbild</translation>
    </message>
    <message>
        <source>Phase One raw image</source>
        <extracomment>image/x-raw-phaseone</extracomment>
        <translation>Phase One råbild</translation>
    </message>
    <message>
        <source>Red raw image</source>
        <extracomment>image/x-raw-red</extracomment>
        <translation>Red råbild</translation>
    </message>
    <message>
        <source>Imacon raw image</source>
        <extracomment>image/x-raw-imacon</extracomment>
        <translation>Imacon råbild</translation>
    </message>
    <message>
        <source>Logitech raw image</source>
        <extracomment>image/x-raw-logitech</extracomment>
        <translation>Logitech råbild</translation>
    </message>
    <message>
        <source>Casio raw image</source>
        <extracomment>image/x-raw-casio</extracomment>
        <translation>Casio råbild</translation>
    </message>
    <message>
        <source>Rawzor raw image</source>
        <extracomment>image/x-raw-rawzor</extracomment>
        <translation>Rawzor råbild</translation>
    </message>
    <message>
        <source>Silicon Graphics RGB Bitmap</source>
        <extracomment>image/x-rgb</extracomment>
        <translation>Silicon Graphics RGB Bitmap</translation>
    </message>
    <message>
        <source>GIMP Image File</source>
        <extracomment>image/x-xcf</extracomment>
        <translation>GIMP-bildfil</translation>
    </message>
    <message>
        <source>X Windows Dump</source>
        <extracomment>image/x-xwindowdump</extracomment>
        <translation>X Windows Dump</translation>
    </message>
    <message>
        <source>MIME Encapsulation of Aggregate HTML Documents</source>
        <extracomment>multipart/related</extracomment>
        <translation>MIME-inkapsling av aggregerade HTML-dokument</translation>
    </message>
    <message>
        <source>3d imaging data exchange</source>
        <extracomment>model/e57</extracomment>
        <translation>3d imaging data exchange</translation>
    </message>
    <message>
        <source>Initial Graphics Exchange Specification Format</source>
        <extracomment>model/iges</extracomment>
        <translation>Initial Graphics Exchange Specification Format</translation>
    </message>
    <message>
        <source>no magic available</source>
        <extracomment>model/x.stl-binary</extracomment>
        <translation>Ingen magic tillgänglig</translation>
    </message>
    <message>
        <source>AutoCAD Design Web Format</source>
        <extracomment>model/vnd.dwf
----------
model/vnd.dwfx+xps</extracomment>
        <translation>AutoCAD Design Web Format</translation>
    </message>
    <message>
        <source>ONline Information eXchange (ONIX) for books</source>
        <extracomment>application/onix-message+xml
----------
application/onix-message-short+xml</extracomment>
        <translation>ONline Information eXchange (ONIX) för böcker</translation>
    </message>
    <message>
        <source>ActionScript source code</source>
        <extracomment>text/x-actionscript</extracomment>
        <translation>ActionScript-källkod</translation>
    </message>
    <message>
        <source>Ada source code</source>
        <extracomment>text/x-ada</extracomment>
        <translation>Ada-källkod</translation>
    </message>
    <message>
        <source>AppleScript source code</source>
        <extracomment>text/x-applescript</extracomment>
        <translation>AppleScript-källkod</translation>
    </message>
    <message>
        <source>Active Server Page</source>
        <extracomment>text/asp</extracomment>
        <translation>Active Server Page</translation>
    </message>
    <message>
        <source>ASP .NET</source>
        <extracomment>text/aspdotnet</extracomment>
        <translation>ASP .NET</translation>
    </message>
    <message>
        <source>AspectJ source code</source>
        <extracomment>text/x-aspectj</extracomment>
        <translation>AspectJ-källkod</translation>
    </message>
    <message>
        <source>Assembler source code</source>
        <extracomment>text/x-assembly</extracomment>
        <translation>Assembler-källkod</translation>
    </message>
    <message>
        <source>Cascading Style Sheet</source>
        <extracomment>text/css</extracomment>
        <translation>CSS-stilmallar</translation>
    </message>
    <message>
        <source>HyperText Markup Language</source>
        <extracomment>text/html</extracomment>
        <translation>HyperText Markup Language</translation>
    </message>
    <message>
        <source>Makefile build file</source>
        <extracomment>text/x-makefile</extracomment>
        <translation>Makefile-byggfil</translation>
    </message>
    <message>
        <source>Roff/nroff/troff/groff Unformatted Manual Page (UNIX)</source>
        <extracomment>text/troff</extracomment>
        <translation>Roff/nroff/troff/groff oformaterad manualsida (UNIX)</translation>
    </message>
    <message>
        <source>Graphviz Graph Visualization Software</source>
        <extracomment>text/vnd.graphviz</extracomment>
        <translation>Graphviz Graph Visualization Software</translation>
    </message>
    <message>
        <source>American Newspaper Publishers Association Wire Feeds</source>
        <extracomment>text/vnd.iptc.anpa</extracomment>
        <translation>American Newspaper Publishers Association Wire Feeds</translation>
    </message>
    <message>
        <source>WML Script</source>
        <extracomment>text/vnd.wap.wmlscript</extracomment>
        <translation>WML-skript</translation>
    </message>
    <message>
        <source>Web Video Text Tracks Format</source>
        <extracomment>text/vtt</extracomment>
        <translation>Web Video Text Tracks Format</translation>
    </message>
    <message>
        <source>AWK script</source>
        <extracomment>text/x-awk</extracomment>
        <translation>AWK-skript</translation>
    </message>
    <message>
        <source>Basic source code</source>
        <extracomment>text/x-basic</extracomment>
        <translation>Basic-källkod</translation>
    </message>
    <message>
        <source>C++ source code header</source>
        <extracomment>text/x-c++hdr</extracomment>
        <translation>C++-källkodsheader</translation>
    </message>
    <message>
        <source>C++ source code</source>
        <extracomment>text/x-c++src</extracomment>
        <translation>C++-källkod</translation>
    </message>
    <message>
        <source>CGI script</source>
        <extracomment>text/x-cgi</extracomment>
        <translation>CGI-skript</translation>
    </message>
    <message>
        <source>C source code header</source>
        <extracomment>text/x-chdr</extracomment>
        <translation>C-källkodsheader</translation>
    </message>
    <message>
        <source>Clojure source code</source>
        <extracomment>text/x-clojure</extracomment>
        <translation>Clojure-källkod</translation>
    </message>
    <message>
        <source>CoffeeScript source code</source>
        <extracomment>text/x-coffeescript</extracomment>
        <translation>CoffeeScript-källkod</translation>
    </message>
    <message>
        <source>C source code</source>
        <extracomment>text/x-csrc</extracomment>
        <translation>C-källkod</translation>
    </message>
    <message>
        <source>C# source code</source>
        <extracomment>text/x-csharp</extracomment>
        <translation>C#-källkod</translation>
    </message>
    <message>
        <source>COBOL source code</source>
        <extracomment>text/x-cobol</extracomment>
        <translation>COBOL-källkod</translation>
    </message>
    <message>
        <source>ColdFusion source code</source>
        <extracomment>text/x-coldfusion</extracomment>
        <translation>ColdFusion-källkod</translation>
    </message>
    <message>
        <source>Common Lisp source code</source>
        <extracomment>text/x-common-lisp</extracomment>
        <translation>Common Lisp-källkod</translation>
    </message>
    <message>
        <source>Eiffel source code</source>
        <extracomment>text/x-eiffel</extracomment>
        <translation>Eiffel-källkod</translation>
    </message>
    <message>
        <source>Emacs Lisp source code</source>
        <extracomment>text/x-emacs-lisp</extracomment>
        <translation>Emacs Lisp-källkod</translation>
    </message>
    <message>
        <source>Erlang source code</source>
        <extracomment>text/x-erlang</extracomment>
        <translation>Erlang-källkod</translation>
    </message>
    <message>
        <source>Expect Script</source>
        <extracomment>text/x-expect</extracomment>
        <translation>Expect-skript</translation>
    </message>
    <message>
        <source>Forth source code</source>
        <extracomment>text/x-forth</extracomment>
        <translation>Forth-källkod</translation>
    </message>
    <message>
        <source>Fortran source code</source>
        <extracomment>text/x-fortran</extracomment>
        <translation>Fortran-källkod</translation>
    </message>
    <message>
        <source>Go source code</source>
        <extracomment>text/x-go</extracomment>
        <translation>Go-källkod</translation>
    </message>
    <message>
        <source>Groovy source code</source>
        <extracomment>text/x-groovy</extracomment>
        <translation>Groovy-källkod</translation>
    </message>
    <message>
        <source>Haskell source code</source>
        <extracomment>text/x-haskell</extracomment>
        <translation>Haskell-källkod</translation>
    </message>
    <message>
        <source>Interface Definition Language</source>
        <extracomment>text/x-idl</extracomment>
        <translation>Interface Definition Language</translation>
    </message>
    <message>
        <source>Configuration file</source>
        <extracomment>text/x-ini</extracomment>
        <translation>Konfigurationsfil</translation>
    </message>
    <message>
        <source>Java source code</source>
        <extracomment>text/x-java-source</extracomment>
        <translation>Java-källkod</translation>
    </message>
    <message>
        <source>Java Properties</source>
        <extracomment>text/x-java-properties</extracomment>
        <translation>Java Properties</translation>
    </message>
    <message>
        <source>Java Server Page</source>
        <extracomment>text/x-jsp</extracomment>
        <translation>Java Server Page</translation>
    </message>
    <message>
        <source>LESS source code</source>
        <extracomment>text/x-less</extracomment>
        <translation>LESS-källkod</translation>
    </message>
    <message>
        <source>Lex/Flex source code</source>
        <extracomment>text/x-lex</extracomment>
        <translation>Lex/Flex-källkod</translation>
    </message>
    <message>
        <source>application log</source>
        <extracomment>text/x-log</extracomment>
        <translation>applikationslogg</translation>
    </message>
    <message>
        <source>Lua source code</source>
        <extracomment>text/x-lua</extracomment>
        <translation>Lua-källkod</translation>
    </message>
    <message>
        <source>ML source code</source>
        <extracomment>text/x-ml</extracomment>
        <translation>ML-källkod</translation>
    </message>
    <message>
        <source>Matlab source code</source>
        <extracomment>text/x-matlab</extracomment>
        <translation>Matlab-källkod</translation>
    </message>
    <message>
        <source>MATLAB data file</source>
        <extracomment>application/x-matlab-data</extracomment>
        <translation>MATLAB-datafil</translation>
    </message>
    <message>
        <source>Modula source code</source>
        <extracomment>text/x-modula</extracomment>
        <translation>Modula-källkod</translation>
    </message>
    <message>
        <source>Objective-C source code</source>
        <extracomment>text/x-objcsrc</extracomment>
        <translation>Objective-C-källkod</translation>
    </message>
    <message>
        <source>Ocaml source code</source>
        <extracomment>text/x-ocaml</extracomment>
        <translation>Ocaml-källkod</translation>
    </message>
    <message>
        <source>Pascal source code</source>
        <extracomment>text/x-pascal</extracomment>
        <translation>Pascal-källkod</translation>
    </message>
    <message>
        <source>Perl script</source>
        <extracomment>text/x-perl</extracomment>
        <translation>Perl-skript</translation>
    </message>
    <message>
        <source>PHP script</source>
        <extracomment>text/x-php</extracomment>
        <translation>PHP-skript</translation>
    </message>
    <message>
        <source>Prolog source code</source>
        <extracomment>text/x-prolog</extracomment>
        <translation>Prolog-källkod</translation>
    </message>
    <message>
        <source>Python script</source>
        <extracomment>text/x-python</extracomment>
        <translation>Python-skript</translation>
    </message>
    <message>
        <source>reStructuredText source code</source>
        <extracomment>text/x-rst</extracomment>
        <translation>reStructuredText-källkod</translation>
    </message>
    <message>
        <source>Rexx source code</source>
        <extracomment>text/x-rexx</extracomment>
        <translation>Rexx-källkod</translation>
    </message>
    <message>
        <source>Ruby source code</source>
        <extracomment>text/x-ruby</extracomment>
        <translation>Ruby-källkod</translation>
    </message>
    <message>
        <source>Scala source code</source>
        <extracomment>text/x-scala</extracomment>
        <translation>Scala-källkod</translation>
    </message>
    <message>
        <source>Scheme source code</source>
        <extracomment>text/x-scheme</extracomment>
        <translation>Scheme-källkod</translation>
    </message>
    <message>
        <source>Sed code</source>
        <extracomment>text/x-sed</extracomment>
        <translation>Sed-kod</translation>
    </message>
    <message>
        <source>SQL code</source>
        <extracomment>text/x-sql</extracomment>
        <translation>SQL-kod</translation>
    </message>
    <message>
        <source>Smalltalk source code</source>
        <extracomment>text/x-stsrc</extracomment>
        <translation>Smalltalk-källkod</translation>
    </message>
    <message>
        <source>Tcl script</source>
        <extracomment>text/x-tcl</extracomment>
        <translation>Tcl-skript</translation>
    </message>
    <message>
        <source>Text-based (non-binary) Message</source>
        <extracomment>text/x-tika-text-based-message</extracomment>
        <translation>Textbaserat (icke-binärt) meddelande</translation>
    </message>
    <message>
        <source>Visual basic source code</source>
        <extracomment>text/x-vbasic</extracomment>
        <translation>Visual basic-källkod</translation>
    </message>
    <message>
        <source>VB.NET source code</source>
        <extracomment>text/x-vbdotnet</extracomment>
        <translation>VB.NET-källkod</translation>
    </message>
    <message>
        <source>VBScript source code</source>
        <extracomment>text/x-vbscript</extracomment>
        <translation>VBScript-källkod</translation>
    </message>
    <message>
        <source>Verilog source code</source>
        <extracomment>text/x-verilog</extracomment>
        <translation>Verilog-källkod</translation>
    </message>
    <message>
        <source>VHDL source code</source>
        <extracomment>text/x-vhdl</extracomment>
        <translation>VHDL-källkod</translation>
    </message>
    <message>
        <source>Markdown source code</source>
        <extracomment>text/x-web-markdown</extracomment>
        <translation>Markdown-källkod</translation>
    </message>
    <message>
        <source>Yacc/Bison source code</source>
        <extracomment>text/x-yacc</extracomment>
        <translation>Yacc/Bison-källkod</translation>
    </message>
    <message>
        <source>YAML source code</source>
        <extracomment>text/x-yaml</extracomment>
        <translation>YAML-källkod</translation>
    </message>
    <message>
        <source>JPEG 2000 Part 3 (Motion JPEG, MJ2)</source>
        <extracomment>video/mj2</extracomment>
        <translation>JPEG 2000 Part 3 (Motion JPEG, MJ2)</translation>
    </message>
    <message>
        <source>MPEG Movie Clip</source>
        <extracomment>video/mpeg</extracomment>
        <translation>MPEG-filmklipp</translation>
    </message>
    <message>
        <source>Ogg Vorbis Video</source>
        <extracomment>video/ogg</extracomment>
        <translation>Ogg Vorbis Video</translation>
    </message>
    <message>
        <source>Ogg Daala Video</source>
        <extracomment>video/daala</extracomment>
        <translation>Ogg Daala Video</translation>
    </message>
    <message>
        <source>Ogg Theora Video</source>
        <extracomment>video/theora</extracomment>
        <translation>Ogg Theora Video</translation>
    </message>
    <message>
        <source>Ogg Packaged Dirac Video</source>
        <extracomment>video/x-dirac</extracomment>
        <translation>Ogg Packaged Dirac Video</translation>
    </message>
    <message>
        <source>Ogg Packaged OGM Video</source>
        <extracomment>video/x-ogm</extracomment>
        <translation>Ogg Packaged OGM Video</translation>
    </message>
    <message>
        <source>Ogg Packaged Raw UVS Video</source>
        <extracomment>video/x-ogguvs</extracomment>
        <translation>Ogg Packaged Raw UVS Video</translation>
    </message>
    <message>
        <source>Ogg Packaged Raw YUV Video</source>
        <extracomment>video/x-oggyuv</extracomment>
        <translation>Ogg Packaged Raw YUV Video</translation>
    </message>
    <message>
        <source>Ogg Packaged Raw RGB Video</source>
        <extracomment>video/x-oggrgb</extracomment>
        <translation>Ogg Packaged Raw RGB Video</translation>
    </message>
    <message>
        <source>QuickTime Video</source>
        <extracomment>video/quicktime</extracomment>
        <translation>QuickTime Video</translation>
    </message>
    <message>
        <source>Windows Media Metafile</source>
        <extracomment>application/x-ms-asx</extracomment>
        <translation>Windows Media Metafile</translation>
    </message>
    <message>
        <source>Audio Video Interleave File</source>
        <extracomment>video/x-msvideo</extracomment>
        <translation>Audio Video Interleave File</translation>
    </message>
    <message>
        <source>Matroska Media Container</source>
        <extracomment>application/x-matroska</extracomment>
        <translation>Matroska Media Container</translation>
    </message>
    <message>
        <source>Cooltalk Audio</source>
        <extracomment>x-conference/x-cooltalk</extracomment>
        <translation>Cooltalk-ljud</translation>
    </message>
    <message>
        <source>FictionBook document</source>
        <extracomment>application/x-fictionbook+xml</extracomment>
        <translation>FictionBook-dokument</translation>
    </message>
    <message>
        <source>Asciidoc source code</source>
        <extracomment>text/x-asciidoc</extracomment>
        <translation>Asciidoc-källkod</translation>
    </message>
    <message>
        <source>D source code</source>
        <extracomment>text/x-d</extracomment>
        <translation>D-källkod</translation>
    </message>
    <message>
        <source>HAML source code</source>
        <extracomment>text/x-haml</extracomment>
        <translation>HAML-källkod</translation>
    </message>
    <message>
        <source>Haxe source code</source>
        <extracomment>text/x-haxe</extracomment>
        <translation>Haxe-källkod</translation>
    </message>
    <message>
        <source>XLIFF 1.2 document</source>
        <extracomment>application/x-xliff+xml</extracomment>
        <translation>XLIFF 1.2-dokument</translation>
    </message>
    <message>
        <source>XLZ Archive</source>
        <extracomment>application/x-xliff+zip</extracomment>
        <translation>XLZ-arkiv</translation>
    </message>
    <message>
        <source>R source code</source>
        <extracomment>text/x-rsrc</extracomment>
        <translation>R-källkod</translation>
    </message>
</context>
<context>
    <name></name>
    <message>
        <source>Cannot open %1 for input</source>
        <translation>Kan inte öppna %1 för inmatning</translation>
    </message>
    <message>
        <source>Cannot open for output: %1</source>
        <translation>Kan inte öppna för utmatning: %1</translation>
    </message>
    <message>
        <source>Could not copy to %1: %2</source>
        <translation>Kunde inte kopiera till %1: %2</translation>
    </message>
    <message>
        <source>Failure to write block: %1</source>
        <translation>Misslyckades med att skriva block: %1</translation>
    </message>
    <message>
        <source>Metadata parsing error: %1</source>
        <translation>Tolkningsfel av metadata: %1</translation>
    </message>
    <message>
        <source>Invalid metadata version</source>
        <translation>Ogiltig metadataversion</translation>
    </message>
    <message>
        <source>Unexpected metadata contents</source>
        <translation>Oväntat metadatainnehåll</translation>
    </message>
    <message>
        <source>Extra content at end of document.</source>
        <translation>Extra innehåll i slutet av dokumentet.</translation>
    </message>
    <message>
        <source>Unexpected token while reading raw inner data.</source>
        <translation>Oväntad token vid läsning av rå inre data.</translation>
    </message>
    <message>
        <source>Expected character data.</source>
        <translation>Förväntade teckendata.</translation>
    </message>
    <message>
        <source>QPA plugin. See QGuiApplication documentation for available options for each plugin.</source>
        <translation>QPA-insticksmodul. Se dokumentation för QGuiApplication för tillgängliga alternativ för varje insticksmodul.</translation>
    </message>
    <message>
        <source>Path to the platform plugins.</source>
        <translation>Sökväg till plattformens insticksmoduler.</translation>
    </message>
    <message>
        <source>Platform theme.</source>
        <translation>Plattformstema.</translation>
    </message>
    <message>
        <source>Additional plugins to load, can be specified multiple times.</source>
        <translation>Ytterligare insticksmoduler att läsa in, kan anges flera gånger.</translation>
    </message>
    <message>
        <source>Window geometry for the main window, using the X11-syntax, like 100x100+50+50.</source>
        <translation>Fönstergeometri för huvudfönstret, använder X11-syntax, som 100x100+50+50.</translation>
    </message>
    <message>
        <source>Default window icon.</source>
        <translation>Fönsterikon som standard.</translation>
    </message>
    <message>
        <source>Title of the first window.</source>
        <translation>Titel för första fönstret.</translation>
    </message>
    <message>
        <source>Sets the application&apos;s layout direction to Qt::RightToLeft (debugging helper).</source>
        <translation>Ställer in programmets layoutriktning till  Qt::RightToLeft (felsökningshjälpare).</translation>
    </message>
    <message>
        <source>Restores the application from an earlier session.</source>
        <translation>Återställer programmet från en tidigare session.</translation>
    </message>
    <message>
        <source>Display name, overrides $DISPLAY.</source>
        <translation>Skärmnamn, åsidosätter $DISPLAY.</translation>
    </message>
    <message>
        <source>Instance name according to ICCCM 4.1.2.5.</source>
        <translation>Instansnamn enligt ICCCM 4.1.2.5.</translation>
    </message>
    <message>
        <source>Disable mouse grabbing (useful in debuggers).</source>
        <translation>Inaktivera musfångst (användbart i felsökare).</translation>
    </message>
    <message>
        <source>Force mouse grabbing (even when running in a debugger).</source>
        <translation>Tvinga musfångst (även vid körning i en felsökare).</translation>
    </message>
    <message>
        <source>ID of the X11 Visual to use.</source>
        <translation>ID för X11 Visual att använda.</translation>
    </message>
    <message>
        <source>Alias for --qwindowgeometry.</source>
        <translation>Alias för --qwindowgeometry.</translation>
    </message>
    <message>
        <source>Alias for --qwindowicon.</source>
        <translation>Alias för --qwindowicon.</translation>
    </message>
    <message>
        <source>Alias for --qwindowtitle.</source>
        <translation>Alias för --qwindowtitle.</translation>
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message>
        <source>QHttp</source>
        <translation>QHttp</translation>
    </message>
</context>
<context>
    <name>QWindowsUiaMainProvider</name>
    <message>
        <source>blockquote</source>
        <translation>blockquote</translation>
    </message>
</context>
<context>
    <name>QAccessibleColorWellItem</name>
    <message>
        <source>RGB %1, %2, %3</source>
        <extracomment>Color specified via its 3 RGB components (red, green, blue)</extracomment>
        <translation>RGB %1, %2, %3</translation>
    </message>
</context>
<context>
    <name>QProgressBar</name>
    <message>
        <source>%p%</source>
        <extracomment>%p is the percent value, % is the percent sign. When translated to the identical %p%, then the second % symbol will be replaced by the percentage-symbol from the user&apos;s locale.</extracomment>
        <translation>%p%</translation>
    </message>
</context>
</TS>
