<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca_ES">
<context>
    <name>CloseButton</name>
    <message>
        <source>Close Tab</source>
        <translation>Tanca la pestanya</translation>
    </message>
</context>
<context>
    <name>MAC_APPLICATION_MENU</name>
    <message>
        <source>Services</source>
        <translation>Serveis</translation>
    </message>
    <message>
        <source>Hide %1</source>
        <translation>Oculta %1</translation>
    </message>
    <message>
        <source>Hide Others</source>
        <translation>Oculta altres</translation>
    </message>
    <message>
        <source>Show All</source>
        <translation>Mostra-ho tot</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferències...</translation>
    </message>
    <message>
        <source>Quit %1</source>
        <translation>Surt de %1</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Quant a %1</translation>
    </message>
</context>
<context>
    <name>Print Device Input Slot</name>
    <message>
        <source>Automatic</source>
        <translation>Automàtic</translation>
    </message>
</context>
<context>
    <name>Print Device Output Bin</name>
    <message>
        <source>Automatic</source>
        <translation>Automàtic</translation>
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <source>Socket operation timed out</source>
        <translation>L&apos;operació de sòcol ha excedit el temps</translation>
    </message>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>Operació no admesa al sòcol</translation>
    </message>
    <message>
        <source>Host not found</source>
        <translation>No s&apos;ha trobat el servidor</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>S&apos;ha rebutjat la connexió</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Temps de connexió excedit</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>S&apos;intenta connectar mentre la connexió és en curs</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>El sòcol no s&apos;ha connectat</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Xarxa no accessible</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Selecciona-ho tot</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>En&amp;davant</translation>
    </message>
    <message>
        <source>Step &amp;down</source>
        <translation>En&amp;rere</translation>
    </message>
</context>
<context>
    <name>QAccessibleActionInterface</name>
    <message>
        <source>Press</source>
        <translation>Prem</translation>
    </message>
    <message>
        <source>Increase</source>
        <translation>Augmenta</translation>
    </message>
    <message>
        <source>Decrease</source>
        <translation>Disminueix</translation>
    </message>
    <message>
        <source>ShowMenu</source>
        <translation>Mostra el menú</translation>
    </message>
    <message>
        <source>SetFocus</source>
        <translation>Estableix el focus</translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation>Commuta</translation>
    </message>
    <message>
        <source>Scroll Left</source>
        <translation>Desplaçament a l&apos;esquerra</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Desplaçament a la dreta</translation>
    </message>
    <message>
        <source>Scroll Up</source>
        <translation>Desplaçament cap amunt</translation>
    </message>
    <message>
        <source>Scroll Down</source>
        <translation>Desplaçament cap avall</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>Pàgina anterior</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Pàgina següent</translation>
    </message>
    <message>
        <source>Triggers the action</source>
        <translation>Activa l&apos;acció</translation>
    </message>
    <message>
        <source>Increase the value</source>
        <translation>Augmenta el valor</translation>
    </message>
    <message>
        <source>Decrease the value</source>
        <translation>Disminueix el valor</translation>
    </message>
    <message>
        <source>Shows the menu</source>
        <translation>Mostra el menú</translation>
    </message>
    <message>
        <source>Sets the focus</source>
        <translation>Estableix el focus</translation>
    </message>
    <message>
        <source>Toggles the state</source>
        <translation>Commuta l&apos;estat</translation>
    </message>
    <message>
        <source>Scrolls to the left</source>
        <translation>Desplaça a l&apos;esquerra</translation>
    </message>
    <message>
        <source>Scrolls to the right</source>
        <translation>Desplaça a la dreta</translation>
    </message>
    <message>
        <source>Scrolls up</source>
        <translation>Desplaça amunt</translation>
    </message>
    <message>
        <source>Scrolls down</source>
        <translation>Desplaça avall</translation>
    </message>
    <message>
        <source>Goes back a page</source>
        <translation>Retrocedeix una pàgina</translation>
    </message>
    <message>
        <source>Goes to the next page</source>
        <translation>Avança a la pàgina següent</translation>
    </message>
</context>
<context>
    <name>QAndroidPlatformTheme</name>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>Yes to All</source>
        <translation>Sí a tot</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>No to All</source>
        <translation>No a tot</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Executable &apos;%1&apos; requires Qt %2, found Qt %3.</source>
        <translation type="vanished">L&apos;executable «%1» requereix les Qt %2, s&apos;han trobat les Qt %3.</translation>
    </message>
    <message>
        <source>Application &quot;%1&quot; requires Qt %2, found Qt %3.</source>
        <translation>L&apos;aplicació «%1» requereix les Qt %2, s&apos;han trobat les Qt %3.</translation>
    </message>
    <message>
        <source>Incompatible Qt Library Error</source>
        <translation>Error de biblioteca Qt incompatible</translation>
    </message>
</context>
<context>
    <name>QCocoaMenuItem</name>
    <message>
        <source>About Qt</source>
        <translation>Quant a les Qt</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Quant a</translation>
    </message>
    <message>
        <source>Config</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <source>Preference</source>
        <translation>Preferències</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opcions</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Paràmetre</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Surt</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Surt</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Retalla</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
    <message>
        <source>Start Dictation...</source>
        <translation type="vanished">Inicia el dictat...</translation>
    </message>
    <message>
        <source>Emoji &amp;&amp; Symbols</source>
        <translation type="vanished">Emojis i símbols</translation>
    </message>
</context>
<context>
    <name>QCocoaTheme</name>
    <message>
        <source>Don&apos;t Save</source>
        <translation>No desis</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>Hu&amp;e:</source>
        <translation>&amp;To:</translation>
    </message>
    <message>
        <source>&amp;Sat:</source>
        <translation>&amp;Sat.:</translation>
    </message>
    <message>
        <source>&amp;Val:</source>
        <translation>&amp;Al.vert.:</translation>
    </message>
    <message>
        <source>&amp;Red:</source>
        <translation>&amp;Vermell:</translation>
    </message>
    <message>
        <source>&amp;Green:</source>
        <translation>V&amp;erd:</translation>
    </message>
    <message>
        <source>Bl&amp;ue:</source>
        <translation>Bla&amp;u:</translation>
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
        <translation>Canal a&amp;lfa:</translation>
    </message>
    <message>
        <source>&amp;HTML:</source>
        <translation>&amp;HTML:</translation>
    </message>
    <message>
        <source>Cursor at %1, %2
Press ESC to cancel</source>
        <translation>Cursor a %1, %2
Premeu ESC per a cancel·lar</translation>
    </message>
    <message>
        <source>&amp;Pick Screen Color</source>
        <translation>Selecció de color de la &amp;pantalla</translation>
    </message>
    <message>
        <source>Cursor at %1, %2, color: %3
Press ESC to cancel</source>
        <translation type="vanished">Cursor en %1, %2, color: %3
Premeu Esc per a cancel·lar</translation>
    </message>
    <message>
        <source>Select Color</source>
        <translation>Selecció de color</translation>
    </message>
    <message>
        <source>Pick Screen Color</source>
        <translation type="vanished">Selecció de color de la pantalla</translation>
    </message>
    <message>
        <source>&amp;Basic colors</source>
        <translation>Colors &amp;bàsics</translation>
    </message>
    <message>
        <source>&amp;Custom colors</source>
        <translation>&amp;Colors personalitzats</translation>
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
        <translation>&amp;Afegeix als colors personalitzats</translation>
    </message>
</context>
<context>
    <name>QComboBox</name>
    <message>
        <source>False</source>
        <translation>Fals</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Cert</translation>
    </message>
    <message>
        <source>Open the combo box selection popup</source>
        <translation>Obre el quadre combinat emergent</translation>
    </message>
</context>
<context>
    <name>QCommandLineParser</name>
    <message>
        <source>Displays version information.</source>
        <translation>Mostra la informació de la versió.</translation>
    </message>
    <message>
        <source>Displays this help.</source>
        <translation type="vanished">Mostra aquesta ajuda.</translation>
    </message>
    <message>
        <source>Displays help on commandline options.</source>
        <translation>Mostra l&apos;ajuda a les opcions de la línia d&apos;ordres.</translation>
    </message>
    <message>
        <source>Displays help including Qt specific options.</source>
        <translation type="vanished">Mostra l&apos;ajuda incloent les opcions específiques de les Qt.</translation>
    </message>
    <message>
        <source>Displays help, including generic Qt options.</source>
        <translation>Mostra l&apos;ajuda, incloent-hi les opcions genèriques de les Qt.</translation>
    </message>
    <message>
        <source>Unknown option &apos;%1&apos;.</source>
        <translation>Opció «%1» desconeguda.</translation>
    </message>
    <message>
        <source>Unknown options: %1.</source>
        <translation>Opcions desconegudes: «%1».</translation>
    </message>
    <message>
        <source>Missing value after &apos;%1&apos;.</source>
        <translation>Manca un valor després de «%1».</translation>
    </message>
    <message>
        <source>Unexpected value after &apos;%1&apos;.</source>
        <translation>Valor inesperat després de «%1».</translation>
    </message>
    <message>
        <source>[options]</source>
        <translation>[opcions]</translation>
    </message>
    <message>
        <source>Usage: %1</source>
        <translation>Ús: %1</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opcions:</translation>
    </message>
    <message>
        <source>Arguments:</source>
        <translation>Arguments:</translation>
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message>
        <source>%1: key is empty</source>
        <comment>QSystemSemaphore</comment>
        <translation type="vanished">%1: la clau és buida</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <comment>QSystemSemaphore</comment>
        <translation type="vanished">%1: no s&apos;ha pogut crear la clau</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <comment>QSystemSemaphore</comment>
        <translation type="vanished">%1: ha fallat el «ftok»</translation>
    </message>
    <message>
        <source>QHttp</source>
        <translation>QHttp</translation>
    </message>
</context>
<context>
    <name>QCupsJobWidget</name>
    <message>
        <source>Job</source>
        <translation>Treball</translation>
    </message>
    <message>
        <source>Job Control</source>
        <translation>Control de treballs</translation>
    </message>
    <message>
        <source>Scheduled printing:</source>
        <translation type="vanished">Impressió planificada:</translation>
    </message>
    <message>
        <source>Billing information:</source>
        <translation type="vanished">Informació de facturació:</translation>
    </message>
    <message>
        <source>Job priority:</source>
        <translation type="vanished">Prioritat del treball:</translation>
    </message>
    <message>
        <source>Banner Pages</source>
        <translation>Pàgines de bàner</translation>
    </message>
    <message>
        <source>End:</source>
        <comment>Banner page at end</comment>
        <translation type="vanished">Final:</translation>
    </message>
    <message>
        <source>Start:</source>
        <comment>Banner page at start</comment>
        <translation type="vanished">Inici:</translation>
    </message>
    <message>
        <source>Print Immediately</source>
        <translation>Imprimeix immediatament</translation>
    </message>
    <message>
        <source>Hold Indefinitely</source>
        <translation>Retén indefinidament</translation>
    </message>
    <message>
        <source>Day (06:00 to 17:59)</source>
        <translation>Diürn (06:00 a 17:59)</translation>
    </message>
    <message>
        <source>Night (18:00 to 05:59)</source>
        <translation>Nocturn (18:00 a 05:59)</translation>
    </message>
    <message>
        <source>Second Shift (16:00 to 23:59)</source>
        <translation>Segon torn (16:00 a 23:59)</translation>
    </message>
    <message>
        <source>Third Shift (00:00 to 07:59)</source>
        <translation>Tercer torn (00:00 a 07:59)</translation>
    </message>
    <message>
        <source>Weekend (Saturday to Sunday)</source>
        <translation>Cap de setmana (dissabte a diumenge)</translation>
    </message>
    <message>
        <source>Specific Time</source>
        <translation>Hora específica</translation>
    </message>
    <message>
        <source>None</source>
        <comment>CUPS Banner page</comment>
        <translation>Cap</translation>
    </message>
    <message>
        <source>Standard</source>
        <comment>CUPS Banner page</comment>
        <translation>Estàndard</translation>
    </message>
    <message>
        <source>Unclassified</source>
        <comment>CUPS Banner page</comment>
        <translation>Sense classificar</translation>
    </message>
    <message>
        <source>Confidential</source>
        <comment>CUPS Banner page</comment>
        <translation>Confidencial</translation>
    </message>
    <message>
        <source>Classified</source>
        <comment>CUPS Banner page</comment>
        <translation>Classificat</translation>
    </message>
    <message>
        <source>Secret</source>
        <comment>CUPS Banner page</comment>
        <translation>Secret</translation>
    </message>
    <message>
        <source>Top Secret</source>
        <comment>CUPS Banner page</comment>
        <translation>Alt secret</translation>
    </message>
    <message>
        <source>Scheduled &amp;printing:</source>
        <translation>Im&amp;pressió planificada:</translation>
    </message>
    <message>
        <source>&amp;Billing information:</source>
        <translation>Informació de &amp;facturació:</translation>
    </message>
    <message>
        <source>Job &amp;priority:</source>
        <translation>&amp;Prioritat del treball:</translation>
    </message>
    <message>
        <source>&amp;Start:</source>
        <comment>Banner page at start</comment>
        <translation>&amp;Inici:</translation>
    </message>
    <message>
        <source>&amp;End:</source>
        <comment>Banner page at end</comment>
        <translation>&amp;Final:</translation>
    </message>
</context>
<context>
    <name>QCupsPrinterSupport</name>
    <message>
        <source>Authentication Needed</source>
        <translation>Cal autenticació</translation>
    </message>
    <message>
        <source>Authentication needed to use %1.</source>
        <translation>Cal autenticació per a usar %1.</translation>
    </message>
    <message>
        <source>Authentication needed to use %1 on %2.</source>
        <translation>Cal autenticació per a usar %1 a %2.</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Nom d&apos;usuari:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Contrasenya:</translation>
    </message>
</context>
<context>
    <name>QDB2Driver</name>
    <message>
        <source>Unable to connect</source>
        <translation>No s&apos;ha pogut connectar</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No s&apos;ha pogut confirmar la transacció</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No s&apos;ha pogut desfer la transacció</translation>
    </message>
    <message>
        <source>Unable to set autocommit</source>
        <translation>No s&apos;ha pogut establir la pròpia confirmació</translation>
    </message>
</context>
<context>
    <name>QDB2Result</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>No s&apos;ha pogut executar la sentència</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No s&apos;ha pogut preparar la sentència</translation>
    </message>
    <message>
        <source>Unable to bind variable</source>
        <translation>No s&apos;ha pogut vincular la variable</translation>
    </message>
    <message>
        <source>Unable to fetch record %1</source>
        <translation>No s&apos;ha pogut recuperar el registre %1</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>No s&apos;ha pogut recuperar el següent</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>No s&apos;ha pogut recuperar el primer</translation>
    </message>
</context>
<context>
    <name>QDBusTrayIcon</name>
    <message>
        <source>OK</source>
        <translation>D&apos;acord</translation>
    </message>
</context>
<context>
    <name>QDateTimeEdit</name>
    <message>
        <source>AM</source>
        <translation type="vanished">AM</translation>
    </message>
    <message>
        <source>am</source>
        <translation type="vanished">am</translation>
    </message>
    <message>
        <source>PM</source>
        <translation type="vanished">PM</translation>
    </message>
    <message>
        <source>pm</source>
        <translation type="vanished">pm</translation>
    </message>
</context>
<context>
    <name>QDateTimeParser</name>
    <message>
        <source>AM</source>
        <translation type="vanished">AM</translation>
    </message>
    <message>
        <source>am</source>
        <translation type="vanished">am</translation>
    </message>
    <message>
        <source>PM</source>
        <translation type="vanished">PM</translation>
    </message>
    <message>
        <source>pm</source>
        <translation type="vanished">pm</translation>
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>Què és això?</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <source>OK</source>
        <translation>D&apos;acord</translation>
    </message>
</context>
<context>
    <name>QDirModel</name>
    <message>
        <source>Name</source>
        <translation type="vanished">Nom</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Mida</translation>
    </message>
    <message>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation type="vanished">Classe</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation type="vanished">Tipus</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation type="vanished">Data de modificació</translation>
    </message>
</context>
<context>
    <name>QDnsLookup</name>
    <message>
        <source>Operation cancelled</source>
        <translation>Operació cancel·lada</translation>
    </message>
    <message>
        <source>Invalid domain name</source>
        <translation>Nom de domini no vàlid</translation>
    </message>
    <message>
        <source>SSL/TLS support not present</source>
        <translation>No s&apos;admet l&apos;ús de SSL/TLS</translation>
    </message>
    <message>
        <source>Request timed out</source>
        <translation>S&apos;ha excedit el temps d&apos;espera de la sol·licitud</translation>
    </message>
    <message>
        <source>Server could not process query</source>
        <translation>El servidor no ha pogut processar la consulta</translation>
    </message>
    <message>
        <source>Server failure</source>
        <translation>Fallada del servidor</translation>
    </message>
    <message>
        <source>Non existent domain</source>
        <translation>Domini no existent</translation>
    </message>
    <message>
        <source>Server refused to answer</source>
        <translation>El servidor ha refusat respondre</translation>
    </message>
    <message>
        <source>Invalid reply received (rcode %1)</source>
        <translation>S&apos;ha rebut una resposta no vàlida (rcode %1)</translation>
    </message>
    <message>
        <source>Invalid reply received</source>
        <translation>S&apos;ha rebut una resposta no vàlida</translation>
    </message>
    <message>
        <source>Invalid reply received (%1)</source>
        <translation>S&apos;ha rebut una resposta no vàlida (%1)</translation>
    </message>
    <message>
        <source>IPv6 nameservers are currently not supported on this OS</source>
        <translation>Els servidors de noms IPv6 no estan implementats actualment en aquest SO</translation>
    </message>
    <message>
        <source>Reply was too large</source>
        <translation>La resposta era massa gran</translation>
    </message>
    <message>
        <source>Could not expand domain name</source>
        <translation>No s&apos;ha pogut expandir el nom de domini</translation>
    </message>
    <message>
        <source>Invalid IPv4 address record</source>
        <translation>Registre no vàlid d&apos;adreça IPv4</translation>
    </message>
    <message>
        <source>Invalid IPv6 address record</source>
        <translation>Registre no vàlid d&apos;adreça IPv6</translation>
    </message>
    <message>
        <source>Invalid canonical name record</source>
        <translation>Registre no vàlid de nom canònic</translation>
    </message>
    <message>
        <source>Invalid name server record</source>
        <translation>Registre no vàlid de servidor de noms</translation>
    </message>
    <message>
        <source>Invalid pointer record</source>
        <translation>Registre no vàlid de punter de noms</translation>
    </message>
    <message>
        <source>Invalid mail exchange record</source>
        <translation>Registre no vàlid d&apos;intercanvi de correu</translation>
    </message>
    <message>
        <source>Invalid service record</source>
        <translation>Registre no vàlid de servei</translation>
    </message>
    <message>
        <source>Invalid TLS association record</source>
        <translation>Registre d&apos;associació TLS no vàlid</translation>
    </message>
    <message>
        <source>Invalid text record</source>
        <translation>Registre no vàlid de text</translation>
    </message>
</context>
<context>
    <name>QDnsLookupRunnable</name>
    <message>
        <source>IPv6 addresses for nameservers are currently not supported</source>
        <translation type="vanished">Actualment les adreces IPv6 no estan admeses pels servidors de noms</translation>
    </message>
    <message>
        <source>Invalid domain name</source>
        <translation type="vanished">Nom de domini no vàlid</translation>
    </message>
    <message>
        <source>Not yet supported on Android</source>
        <translation type="vanished">Encara no està admès a l&apos;Android</translation>
    </message>
    <message>
        <source>Resolver functions not found</source>
        <translation type="vanished">No s&apos;han trobat les funcions del resolutor</translation>
    </message>
    <message>
        <source>Resolver initialization failed</source>
        <translation type="vanished">La inicialització del resolutor ha fallat</translation>
    </message>
    <message>
        <source>IPv6 addresses for nameservers is currently not supported</source>
        <translation type="vanished">Actualment les adreces IPv6 no són admeses pels servidors de noms</translation>
    </message>
    <message>
        <source>Server could not process query</source>
        <translation type="vanished">El servidor no ha pogut processar la consulta</translation>
    </message>
    <message>
        <source>Server failure</source>
        <translation type="vanished">Fallada del servidor</translation>
    </message>
    <message>
        <source>Non existent domain</source>
        <translation type="vanished">Domini no existent</translation>
    </message>
    <message>
        <source>Server refused to answer</source>
        <translation type="vanished">El servidor ha refusat respondre</translation>
    </message>
    <message>
        <source>Invalid reply received</source>
        <translation type="vanished">S&apos;ha rebut una resposta no vàlida</translation>
    </message>
    <message>
        <source>Could not expand domain name</source>
        <translation type="vanished">No s&apos;ha pogut expandir el nom de domini</translation>
    </message>
    <message>
        <source>Invalid IPv4 address record</source>
        <translation type="vanished">Registre no vàlid d&apos;adreça IPv4</translation>
    </message>
    <message>
        <source>Invalid IPv6 address record</source>
        <translation type="vanished">Registre no vàlid d&apos;adreça IPv6</translation>
    </message>
    <message>
        <source>Invalid canonical name record</source>
        <translation type="vanished">Registre no vàlid de nom canònic</translation>
    </message>
    <message>
        <source>Invalid name server record</source>
        <translation type="vanished">Registre no vàlid de servidor de noms</translation>
    </message>
    <message>
        <source>Invalid pointer record</source>
        <translation type="vanished">Registre no vàlid de punter de noms</translation>
    </message>
    <message>
        <source>Invalid mail exchange record</source>
        <translation type="vanished">Registre no vàlid d&apos;intercanvi de correu</translation>
    </message>
    <message>
        <source>Invalid service record</source>
        <translation type="vanished">Registre no vàlid de servei</translation>
    </message>
    <message>
        <source>Invalid text record</source>
        <translation type="vanished">Registre no vàlid de text</translation>
    </message>
    <message>
        <source>Resolver library can&apos;t be loaded: No runtime library loading support</source>
        <translation type="vanished">No s&apos;ha pogut carregar la biblioteca de resolució: No s&apos;admet la càrrega de biblioteques en execució</translation>
    </message>
    <message>
        <source>No hostname given</source>
        <translation type="vanished">No s&apos;ha indicat cap nom d&apos;ordinador</translation>
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation type="vanished">Nom d&apos;ordinador no vàlid</translation>
    </message>
    <message>
        <source>Host %1 could not be found.</source>
        <translation type="vanished">No s&apos;ha pogut trobar l&apos;ordinador %1.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Error desconegut</translation>
    </message>
    <message>
        <source>Not yet supported on this OS</source>
        <translation>Encara no està implementat en aquest SO</translation>
    </message>
</context>
<context>
    <name>QDockWidget</name>
    <message>
        <source>Float</source>
        <extracomment>Accessible name for button undocking a dock widget (floating state)</extracomment>
        <translation>Flotant</translation>
    </message>
    <message>
        <source>Undocks and re-attaches the dock widget</source>
        <translation>Desacobla i torna a enganxar el giny acoblador</translation>
    </message>
    <message>
        <source>Close</source>
        <extracomment>Accessible name for button closing a dock widget</extracomment>
        <translation>Tanca</translation>
    </message>
    <message>
        <source>Closes the dock widget</source>
        <translation>Tanca el giny acoblador</translation>
    </message>
</context>
<context>
    <name>QDomParser</name>
    <message>
        <source>Error occurred while processing XML declaration</source>
        <translation>Hi ha hagut un error en processar la declaració XML</translation>
    </message>
    <message>
        <source>Multiple DTD sections are not allowed</source>
        <translation>No es permeten seccions DTD múltiples</translation>
    </message>
    <message>
        <source>Error occurred while processing document type declaration</source>
        <translation>Hi ha hagut un error en processar la declaració del tipus de document</translation>
    </message>
    <message>
        <source>Error occurred while processing comment</source>
        <translation>Hi ha hagut un error en processar un comentari</translation>
    </message>
    <message>
        <source>Error occurred while processing a processing instruction</source>
        <translation>Hi ha hagut un error en processar una instrucció de processat</translation>
    </message>
    <message>
        <source>Error occurred while processing a start element</source>
        <translation>Hi ha hagut un error en processar un element d&apos;inici</translation>
    </message>
    <message>
        <source>Unexpected end element &apos;%1&apos;</source>
        <translation>Element de final «%1» no esperat</translation>
    </message>
    <message>
        <source>Error occurred while processing an end element</source>
        <translation>Hi ha hagut un error en processar un element de final</translation>
    </message>
    <message>
        <source>Error occurred while processing the element content</source>
        <translation>Hi ha hagut un error en processar el contingut d&apos;un element</translation>
    </message>
    <message>
        <source>Error occurred while processing comments</source>
        <translation>Hi ha hagut un error en processar els comentaris</translation>
    </message>
    <message>
        <source>Error occurred while processing an entity reference</source>
        <translation>Hi ha hagut un error en processar una referència d&apos;entitat</translation>
    </message>
    <message>
        <source>Unexpected token</source>
        <translation>Testimoni inesperat</translation>
    </message>
    <message>
        <source>Tag mismatch</source>
        <translation>L&apos;etiqueta no coincideix</translation>
    </message>
    <message>
        <source>Error occurred while processing entity declaration</source>
        <translation>Hi ha hagut un error en processar la declaració d&apos;entitat</translation>
    </message>
    <message>
        <source>Error occurred while processing notation declaration</source>
        <translation>Hi ha hagut un error en processar la declaració de notació</translation>
    </message>
</context>
<context>
    <name>QDtls</name>
    <message>
        <source>Invalid (empty) secret</source>
        <translation>Secret no vàlid (buit)</translation>
    </message>
    <message>
        <source>Multicast and broadcast addresses are not supported</source>
        <translation>No s&apos;admeten les adreces de multidifusió ni de difusió</translation>
    </message>
    <message>
        <source>Cannot set peer after handshake started</source>
        <translation>No s&apos;ha pogut establir el parell després d&apos;iniciar la conformitat de connexió</translation>
    </message>
    <message>
        <source>Invalid address</source>
        <translation>Adreça no vàlida</translation>
    </message>
    <message>
        <source>Cannot set verification name after handshake started</source>
        <translation>No s&apos;ha pogut establir el nom de verificació després d&apos;iniciar la conformitat de connexió</translation>
    </message>
    <message>
        <source>Cannot set configuration after handshake started</source>
        <translation>No s&apos;ha pogut establir la configuració després d&apos;iniciar la conformitat de connexió</translation>
    </message>
    <message>
        <source>Cannot start/continue handshake, invalid handshake state</source>
        <translation>No s&apos;ha pogut iniciar/continuar la conformitat de connexió, estat no vàlid de la conformitat de connexió</translation>
    </message>
    <message>
        <source>Invalid (nullptr) socket</source>
        <translation>Sòcol no vàlid («nullptr»)</translation>
    </message>
    <message>
        <source>To start a handshake you must set peer&apos;s address and port first</source>
        <translation>Per a iniciar una conformitat de connexió primer cal establir l&apos;adreça i el port del parell</translation>
    </message>
    <message>
        <source>To start a handshake, DTLS server requires non-empty datagram (client hello)</source>
        <translation>Per a iniciar una conformitat de connexió, el servidor DTLS requereix un datagrama no buit («client hello»)</translation>
    </message>
    <message>
        <source>Cannot start handshake, already done/in progress</source>
        <translation>No s&apos;ha pogut iniciar la conformitat de connexió, ja està feta/en curs</translation>
    </message>
    <message>
        <source>A valid QUdpSocket and non-empty datagram are needed to continue the handshake</source>
        <translation>Per a continuar la conformitat de connexió cal un «QUdpSocket» vàlid i un datagrama no buit</translation>
    </message>
    <message>
        <source>Cannot continue handshake, not in InProgress state</source>
        <translation>No s&apos;ha pogut continuar la conformitat de connexió, l&apos;estat no és «InProgress»</translation>
    </message>
    <message>
        <source>Cannot resume, not in VerificationError state</source>
        <translation>No s&apos;ha pogut continuar, l&apos;estat no és «VerificationError»</translation>
    </message>
    <message>
        <source>No handshake in progress, nothing to abort</source>
        <translation>No hi ha cap conformitat de connexió en curs, no hi ha res a interrompre</translation>
    </message>
    <message>
        <source>Cannot send shutdown alert, not encrypted</source>
        <translation>No s&apos;ha pogut enviar l&apos;alerta d&apos;aturada, no està encriptada</translation>
    </message>
    <message>
        <source>Cannot write a datagram, not in encrypted state</source>
        <translation>No s&apos;ha pogut escriure un datagrama, no està en estat encriptat</translation>
    </message>
    <message>
        <source>Cannot read a datagram, not in encrypted state</source>
        <translation>No s&apos;ha pogut llegir un datagrama, no està en estat encriptat</translation>
    </message>
    <message>
        <source>%1 failed</source>
        <extracomment>%1: Some function</extracomment>
        <translation>Ha fallat %1</translation>
    </message>
    <message>
        <source>Invalid SslMode, SslServerMode or SslClientMode expected</source>
        <translation>«SslMode» no vàlid, s&apos;esperava «SslServerMode» o «SslClientMode»</translation>
    </message>
    <message>
        <source>Invalid protocol version, DTLS protocol expected</source>
        <translation>Versió no vàlida del protocol, s&apos;esperava el protocol DTLS</translation>
    </message>
    <message>
        <source>BIO_ADD_new failed, cannot start handshake</source>
        <translation>Ha fallat «BIO_ADD_new», no s&apos;ha pogut iniciar la conformitat de connexió</translation>
    </message>
    <message>
        <source>Cannot start the handshake, verified client hello expected</source>
        <translation>No s&apos;ha pogut iniciar la conformitat de connexió, s&apos;esperava un «client hello» verificat</translation>
    </message>
    <message>
        <source>Peer verification failed</source>
        <translation>Ha fallat la verificació del parell</translation>
    </message>
    <message>
        <source>The DTLS connection has been closed</source>
        <translation>S&apos;ha tancat la connexió DTLS</translation>
    </message>
    <message>
        <source>Error while writing: %1</source>
        <translation>Error en escriure: %1</translation>
    </message>
    <message>
        <source>The DTLS connection has been shutdown</source>
        <translation>S&apos;ha tancat la connexió DTLS</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Error en llegir: %1</translation>
    </message>
</context>
<context>
    <name>QDtlsClientVerifier</name>
    <message>
        <source>A valid UDP socket, non-empty datagram, valid address/port were expected</source>
        <translation type="vanished">S&apos;esperava un sòcol UDP vàlid, un datagrama no buit, una adreça/port vàlids</translation>
    </message>
    <message>
        <source>BIO_ADDR_new failed, ignoring client hello</source>
        <translation>Ha fallat «BIO_ADDR_new», s&apos;ignora el «client hello»</translation>
    </message>
    <message>
        <source>A valid UDP socket, non-empty datagram, and valid address/port were expected</source>
        <translation>S&apos;esperava un sòcol UDP vàlid, un datagrama no buit i una adreça/port vàlids</translation>
    </message>
</context>
<context>
    <name>QErrorMessage</name>
    <message>
        <source>An error occurred</source>
        <translation>S&apos;ha produït un error</translation>
    </message>
    <message>
        <source>Debug Message:</source>
        <translation>Missatge de depuració:</translation>
    </message>
    <message>
        <source>Warning:</source>
        <translation>Avís:</translation>
    </message>
    <message>
        <source>Critical Error:</source>
        <translation>Error crític:</translation>
    </message>
    <message>
        <source>Fatal Error:</source>
        <translation>Error fatal:</translation>
    </message>
    <message>
        <source>Information:</source>
        <translation>Informació:</translation>
    </message>
    <message>
        <source>&amp;Show this message again</source>
        <translation>Torna a mo&amp;strar aquest missatge</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>D&apos;ac&amp;ord</translation>
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <source>Destination file is the same file.</source>
        <translation>El fitxer de destinació és el mateix fitxer.</translation>
    </message>
    <message>
        <source>Source file does not exist.</source>
        <translation>El fitxer d&apos;origen no existeix.</translation>
    </message>
    <message>
        <source>Destination file exists</source>
        <translation>El fitxer de destinació existeix</translation>
    </message>
    <message>
        <source>Cannot remove source file: %1</source>
        <translation>No s&apos;ha pogut eliminar el fitxer d&apos;origen: %1</translation>
    </message>
    <message>
        <source>Error while renaming.</source>
        <translation type="vanished">Error en canviar de nom.</translation>
    </message>
    <message>
        <source>Error while renaming: %1</source>
        <translation>Error en canviar de nom: %1</translation>
    </message>
    <message>
        <source>Unable to restore from %1: %2</source>
        <translation>No s&apos;ha pogut restaurar des de %1: %2</translation>
    </message>
    <message>
        <source>Will not rename sequential file using block copy</source>
        <translation>No es pot canviar de nom un fitxer seqüencial utilitzant la còpia de blocs</translation>
    </message>
    <message>
        <source>Cannot remove source file</source>
        <translation type="vanished">No s&apos;ha pogut eliminar el fitxer d&apos;origen</translation>
    </message>
    <message>
        <source>Cannot open destination file: %1</source>
        <translation type="vanished">No s&apos;ha pogut obrir el fitxer de destinació: %1</translation>
    </message>
    <message>
        <source>Cannot open %1 for input</source>
        <translation>No s&apos;ha pogut obrir %1 per entrada</translation>
    </message>
    <message>
        <source>Cannot open for output: %1</source>
        <translation>No s&apos;ha pogut obrir per sortida: %1</translation>
    </message>
    <message>
        <source>Could not copy to %1: %2</source>
        <translation>No s&apos;ha pogut copiar a %1: %2</translation>
    </message>
    <message>
        <source>Failure to write block: %1</source>
        <translation>Ha fallat en escriure un bloc: %1</translation>
    </message>
    <message>
        <source>Cannot create %1 for output: %2</source>
        <translation type="vanished">No s&apos;ha pogut crear %1 per sortida: %2</translation>
    </message>
    <message>
        <source>Cannot open for output</source>
        <translation type="vanished">No s&apos;ha pogut obrir per sortida</translation>
    </message>
    <message>
        <source>Failure to write block</source>
        <translation type="vanished">Ha fallat en escriure un bloc</translation>
    </message>
    <message>
        <source>Cannot create %1 for output</source>
        <translation type="vanished">No s&apos;ha pogut crear %1 per sortida</translation>
    </message>
</context>
<context>
    <name>QFileDevice</name>
    <message>
        <source>No file engine available or engine does not support UnMapExtension</source>
        <translation>No hi ha disponible cap motor de fitxers o el motor no accepta «UnMapExtension»</translation>
    </message>
    <message>
        <source>No file engine available</source>
        <translation>No hi ha disponible cap motor de fitxers</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Look in:</source>
        <translation type="vanished">Cerca a:</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Enrere</translation>
    </message>
    <message>
        <source>Go back</source>
        <translation>Retrocedeix</translation>
    </message>
    <message>
        <source>Alt+Left</source>
        <translation>Alt+Esquerra</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Endavant</translation>
    </message>
    <message>
        <source>Go forward</source>
        <translation>Avança</translation>
    </message>
    <message>
        <source>Alt+Right</source>
        <translation>Alt+Dreta</translation>
    </message>
    <message>
        <source>Parent Directory</source>
        <translation>Directori superior</translation>
    </message>
    <message>
        <source>Go to the parent directory</source>
        <translation>Va al directori superior</translation>
    </message>
    <message>
        <source>Alt+Up</source>
        <translation>Alt+Amunt</translation>
    </message>
    <message>
        <source>Create New Folder</source>
        <translation>Crea una carpeta nova</translation>
    </message>
    <message>
        <source>Create a New Folder</source>
        <translation>Crea una carpeta nova</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>Vista de llista</translation>
    </message>
    <message>
        <source>Change to list view mode</source>
        <translation>Canvia al mode de vista de llista</translation>
    </message>
    <message>
        <source>Detail View</source>
        <translation>Vista de detall</translation>
    </message>
    <message>
        <source>Change to detail view mode</source>
        <translation>Canvia al mode de vista de detall</translation>
    </message>
    <message>
        <source>Sidebar</source>
        <translation>Barra lateral</translation>
    </message>
    <message>
        <source>List of places and bookmarks</source>
        <translation>Llista de llocs i adreces d&apos;interès</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Fitxers</translation>
    </message>
    <message>
        <source>Files of type:</source>
        <translation type="vanished">Fitxers de tipus:</translation>
    </message>
    <message>
        <source>Find Directory</source>
        <translation>Cerca de directori</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>Desa com a</translation>
    </message>
    <message>
        <source>Directory:</source>
        <translation>Directori:</translation>
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation>&amp;Nom de fitxer:</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Obre</translation>
    </message>
    <message>
        <source>&amp;Choose</source>
        <translation>&amp;Tria</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>De&amp;sa</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Tots els fitxers (*)</translation>
    </message>
    <message>
        <source>Show </source>
        <translation>Mostra </translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation>Can&amp;via de nom</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Suprimeix</translation>
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation>Mostra fitxers &amp;ocults</translation>
    </message>
    <message>
        <source>&amp;New Folder</source>
        <translation>Carpeta &amp;nova</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation>Tots els fitxers (*)</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Directoris</translation>
    </message>
    <message>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1
No s&apos;ha trobat el directori.
Comproveu que s&apos;ha indicat el nom correcte del directori.</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 ja existeix.
El voleu substituir?</translation>
    </message>
    <message>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1
No s&apos;ha trobat el fitxer.
Comproveu que s&apos;ha indicat el nom correcte del fitxer.</translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation>Carpeta nova</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>«%1» està protegit contra escriptura.
El voleu suprimir igualment?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete &apos;%1&apos;?</source>
        <translation>Esteu segur que voleu suprimir «%1»?</translation>
    </message>
    <message>
        <source>Could not delete directory.</source>
        <translation>No s&apos;ha pogut suprimir el directori.</translation>
    </message>
    <message>
        <source>Recent Places</source>
        <translation>Llocs recents</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation type="vanished">El meu ordinador</translation>
    </message>
    <message>
        <source>Drive</source>
        <translation type="vanished">Controlador</translation>
    </message>
    <message>
        <source>%1 File</source>
        <extracomment>%1 is a file name suffix, for example txt</extracomment>
        <translation type="vanished">Fitxer %1</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="vanished">Fitxer</translation>
    </message>
    <message>
        <source>File Folder</source>
        <comment>Match Windows Explorer</comment>
        <translation type="vanished">Carpeta de fitxers</translation>
    </message>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation type="vanished">Carpeta</translation>
    </message>
    <message>
        <source>Alias</source>
        <comment>OS X Finder</comment>
        <translation type="vanished">Àlies</translation>
    </message>
    <message>
        <source>Alias</source>
        <comment>Mac OS X Finder</comment>
        <translation type="vanished">Àlies</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <comment>All other platforms</comment>
        <translation type="vanished">Drecera</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="vanished">Desconegut</translation>
    </message>
    <message>
        <source>&amp;Look in:</source>
        <translation>&amp;Cerca a:</translation>
    </message>
    <message>
        <source>Files of &amp;type:</source>
        <translation>Fitxers de &amp;tipus:</translation>
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <source>%1 TB</source>
        <translation type="vanished">%1 TB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation type="vanished">%1 GB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation type="vanished">%1 MB</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation type="vanished">%1 kB</translation>
    </message>
    <message>
        <source>%1 bytes</source>
        <translation type="vanished">%1 bytes</translation>
    </message>
    <message>
        <source>Invalid filename</source>
        <translation type="vanished">Nom de fitxer no vàlid</translation>
    </message>
    <message>
        <source>&lt;b&gt;The name &quot;%1&quot; can not be used.&lt;/b&gt;&lt;p&gt;Try using another name, with fewer characters or no punctuations marks.</source>
        <translation type="vanished">&lt;b&gt;No es pot usar el nom «%1».&lt;/b&gt;&lt;p&gt;Proveu-ho amb un altre nom, amb menys caràcters o sense signes de puntuació.</translation>
    </message>
    <message>
        <source>&lt;b&gt;The name &quot;%1&quot; cannot be used.&lt;/b&gt;&lt;p&gt;Try using another name, with fewer characters or no punctuation marks.</source>
        <translation type="vanished">&lt;b&gt;No es pot usar el nom «%1».&lt;/b&gt;&lt;p&gt;Proveu-ho amb un altre nom, amb menys caràcters o sense signes de puntuació.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation>Tipus</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Data de modificació</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>El meu ordinador</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Ordinador</translation>
    </message>
    <message>
        <source>%1 byte(s)</source>
        <translation type="vanished">%1 byte(s)</translation>
    </message>
</context>
<context>
    <name>QFontDatabase</name>
    <message>
        <source>Normal</source>
        <translation type="vanished">Normal</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Negreta</translation>
    </message>
    <message>
        <source>Demi Bold</source>
        <translation>Semi negreta</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Gruixut</translation>
    </message>
    <message>
        <source>Demi</source>
        <extracomment>The word for &quot;Demi&quot; as in &quot;Demi Bold&quot; used as a pattern for string searches</extracomment>
        <translation>Semi</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Fi</translation>
    </message>
    <message>
        <source>Normal</source>
        <comment>The Normal or Regular font weight</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Medium</source>
        <comment>The Medium font weight</comment>
        <translation>Mig</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>Fi</translation>
    </message>
    <message>
        <source>Extra Light</source>
        <translation>Extrafi</translation>
    </message>
    <message>
        <source>Extra Bold</source>
        <translation>Extranegreta</translation>
    </message>
    <message>
        <source>Extra</source>
        <extracomment>The word for &quot;Extra&quot; as in &quot;Extra Bold, Extra Thin&quot; used as a pattern for string searches</extracomment>
        <translation>Extra</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Cursiva</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Obliqua</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Qualsevol</translation>
    </message>
    <message>
        <source>Latin</source>
        <translation>Llatí</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Grec</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Ciríl·lic</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation>Armeni</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation>Hebreu</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Àrab</translation>
    </message>
    <message>
        <source>Syriac</source>
        <translation>Siríac</translation>
    </message>
    <message>
        <source>Thaana</source>
        <translation>Thaana</translation>
    </message>
    <message>
        <source>Devanagari</source>
        <translation>Devanagari</translation>
    </message>
    <message>
        <source>Bengali</source>
        <translation>Bengalí</translation>
    </message>
    <message>
        <source>Gurmukhi</source>
        <translation>Gurmukhi</translation>
    </message>
    <message>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <source>Tamil</source>
        <translation>Tàmil</translation>
    </message>
    <message>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <source>Kannada</source>
        <translation>Kanarès</translation>
    </message>
    <message>
        <source>Malayalam</source>
        <translation>Malaiàlam</translation>
    </message>
    <message>
        <source>Sinhala</source>
        <translation>Singalès</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation>Tai</translation>
    </message>
    <message>
        <source>Lao</source>
        <translation>Laosià</translation>
    </message>
    <message>
        <source>Tibetan</source>
        <translation>Tibetà</translation>
    </message>
    <message>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgià</translation>
    </message>
    <message>
        <source>Khmer</source>
        <translation>Khmer</translation>
    </message>
    <message>
        <source>Simplified Chinese</source>
        <translation>Xinès simplificat</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Xinès tradicional</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonès</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation>Coreà</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation>Vietnamita</translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation>Símbol</translation>
    </message>
    <message>
        <source>Ogham</source>
        <translation>Ogham</translation>
    </message>
    <message>
        <source>Runic</source>
        <translation>Rúnic</translation>
    </message>
    <message>
        <source>N&apos;Ko</source>
        <translation>Nko</translation>
    </message>
</context>
<context>
    <name>QFontDialog</name>
    <message>
        <source>Select Font</source>
        <translation>Seleccioneu la lletra</translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation>&amp;Lletra</translation>
    </message>
    <message>
        <source>Font st&amp;yle</source>
        <translation>Est&amp;il de la lletra</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Mida</translation>
    </message>
    <message>
        <source>Effects</source>
        <translation>Efectes</translation>
    </message>
    <message>
        <source>Stri&amp;keout</source>
        <translation>Ra&amp;tllat</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>&amp;Subratllat</translation>
    </message>
    <message>
        <source>Sample</source>
        <translation>Mostra</translation>
    </message>
    <message>
        <source>Wr&amp;iting System</source>
        <translation>Sistema d&apos;escr&amp;iptura</translation>
    </message>
</context>
<context>
    <name>QFtp</name>
    <message>
        <source>Not connected</source>
        <translation type="vanished">No connectat</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation type="vanished">No s&apos;ha trobat el servidor %1</translation>
    </message>
    <message>
        <source>Connection refused to host %1</source>
        <translation type="vanished">S&apos;ha rebutjat la connexió al servidor %1</translation>
    </message>
    <message>
        <source>Connection timed out to host %1</source>
        <translation type="vanished">Temps de connexió excedit al servidor %1</translation>
    </message>
    <message>
        <source>Connected to host %1</source>
        <translation type="vanished">S&apos;ha connectat al servidor %1</translation>
    </message>
    <message>
        <source>Data Connection refused</source>
        <translation type="vanished">S&apos;ha rebutjat la connexió de dades</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Error desconegut</translation>
    </message>
    <message>
        <source>Connecting to host failed:
%1</source>
        <translation type="vanished">La connexió al servidor ha fallat:
%1</translation>
    </message>
    <message>
        <source>Login failed:
%1</source>
        <translation type="vanished">Ha fallat l&apos;inici de sessió:
%1</translation>
    </message>
    <message>
        <source>Listing directory failed:
%1</source>
        <translation type="vanished">Ha fallat el llistat del directori:
%1</translation>
    </message>
    <message>
        <source>Changing directory failed:
%1</source>
        <translation type="vanished">Ha fallat el canvi de directori:
%1</translation>
    </message>
    <message>
        <source>Downloading file failed:
%1</source>
        <translation type="vanished">Ha fallat la baixada del fitxer:
%1</translation>
    </message>
    <message>
        <source>Uploading file failed:
%1</source>
        <translation type="vanished">Ha fallat la pujada del fitxer:
%1</translation>
    </message>
    <message>
        <source>Removing file failed:
%1</source>
        <translation type="vanished">Ha fallat l&apos;eliminació del fitxer:
%1</translation>
    </message>
    <message>
        <source>Creating directory failed:
%1</source>
        <translation type="vanished">Ha fallat la creació del directori:
%1</translation>
    </message>
    <message>
        <source>Removing directory failed:
%1</source>
        <translation type="vanished">Ha fallat l&apos;eliminació del directori:
%1</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation type="vanished">S&apos;ha tancat la connexió</translation>
    </message>
</context>
<context>
    <name>QGnomeTheme</name>
    <message>
        <source>&amp;OK</source>
        <translation>D&apos;ac&amp;ord</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Desa</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancel·la</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Tanca</translation>
    </message>
    <message>
        <source>Close without Saving</source>
        <translation>Tanca sense desar</translation>
    </message>
</context>
<context>
    <name>QGuiApplication</name>
    <message>
        <source>QT_LAYOUT_DIRECTION</source>
        <comment>Translate this string to the string &apos;LTR&apos; in left-to-right languages or to &apos;RTL&apos; in right-to-left languages (such as Hebrew and Arabic) to get proper widget layout.</comment>
        <translation>LTR</translation>
    </message>
    <message>
        <source>QPA plugin. See QGuiApplication documentation for available options for each plugin.</source>
        <translation>Connector QPA. Vegeu la documentació de QGuiApplication per a les opcions disponibles de cada connector.</translation>
    </message>
    <message>
        <source>Path to the platform plugins.</source>
        <translation>Camí als connectors de la plataforma.</translation>
    </message>
    <message>
        <source>Platform theme.</source>
        <translation>Tema de la plataforma.</translation>
    </message>
    <message>
        <source>Additional plugins to load, can be specified multiple times.</source>
        <translation>Connectors addicionals a carregar, es poden especificar diverses vegades.</translation>
    </message>
    <message>
        <source>Window geometry for the main window, using the X11-syntax, like 100x100+50+50.</source>
        <translation>Geometria de finestra de la finestra principal, usant la sintaxi X11, com 100x100+50+50.</translation>
    </message>
    <message>
        <source>Default window icon.</source>
        <translation>Icona predeterminada de la finestra.</translation>
    </message>
    <message>
        <source>Title of the first window.</source>
        <translation>Títol de la primera finestra.</translation>
    </message>
    <message>
        <source>Sets the application&apos;s layout direction to Qt::RightToLeft (debugging helper).</source>
        <translation>Estableix la direcció de la disposició de l&apos;aplicació a Qt::RightToLeft (ajudant de depuració).</translation>
    </message>
    <message>
        <source>Restores the application from an earlier session.</source>
        <translation>Restaura l&apos;aplicació d&apos;una sessió anterior.</translation>
    </message>
    <message>
        <source>Display name, overrides $DISPLAY.</source>
        <translation>Nom de la pantalla, sobreescriu $DISPLAY.</translation>
    </message>
    <message>
        <source>Instance name according to ICCCM 4.1.2.5.</source>
        <translation>Nom d&apos;instància d&apos;acord amb ICCCM 4.1.2.5.</translation>
    </message>
    <message>
        <source>Disable mouse grabbing (useful in debuggers).</source>
        <translation>Desactiva la captura del ratolí (útil als depuradors).</translation>
    </message>
    <message>
        <source>Force mouse grabbing (even when running in a debugger).</source>
        <translation>Força la captura del ratolí (inclús en executar a un depurador).</translation>
    </message>
    <message>
        <source>ID of the X11 Visual to use.</source>
        <translation>ID de la «Visual» X11 a usar.</translation>
    </message>
    <message>
        <source>Alias for --qwindowgeometry.</source>
        <translation>Àlies de --qwindowgeometry.</translation>
    </message>
    <message>
        <source>Alias for --qwindowicon.</source>
        <translation>Àlies de --qwindowicon.</translation>
    </message>
    <message>
        <source>Alias for --qwindowtitle.</source>
        <translation>Àlies de --qwindowtitle.</translation>
    </message>
    <message>
        <source>Alias for --windowgeometry.</source>
        <translation type="vanished">Àlies de --windowgeometry.</translation>
    </message>
    <message>
        <source>Alias for --windowicon.</source>
        <translation type="vanished">Àlies de --windowicon.</translation>
    </message>
    <message>
        <source>Alias for --windowtitle.</source>
        <translation type="vanished">Àlies de --windowtitle.</translation>
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <source>No host name given</source>
        <translation>No s&apos;ha proporcionat cap nom d&apos;ordinador</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <source>No host name given</source>
        <translation>No s&apos;ha proporcionat cap nom d&apos;ordinador</translation>
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation>Nom d&apos;ordinador no vàlid</translation>
    </message>
    <message>
        <source>Unknown address type</source>
        <translation>Tipus d&apos;adreça desconeguda</translation>
    </message>
    <message>
        <source>Host not found</source>
        <translation>No s&apos;ha trobat l&apos;ordinador</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Error desconegut</translation>
    </message>
    <message>
        <source>Unknown error (%1)</source>
        <translation type="vanished">Error desconegut (%1)</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>Host %1 not found</source>
        <translation>No s&apos;ha trobat el servidor %1</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>S&apos;ha rebutjat la connexió</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>S&apos;ha tancat la connexió</translation>
    </message>
    <message>
        <source>Proxy requires authentication</source>
        <translation>El servidor intermediari requereix autenticació</translation>
    </message>
    <message>
        <source>Host requires authentication</source>
        <translation>El servidor requereix autenticació</translation>
    </message>
    <message>
        <source>Data corrupted</source>
        <translation>Dades malmeses</translation>
    </message>
    <message>
        <source>Unknown protocol specified</source>
        <translation>Protocol especificat desconegut</translation>
    </message>
    <message>
        <source>SSL handshake failed</source>
        <translation>Ha fallat la conformitat de la connexió SSL</translation>
    </message>
    <message>
        <source>Too many redirects</source>
        <translation>Massa redireccions</translation>
    </message>
    <message>
        <source>Insecure redirect</source>
        <translation>Redirecció insegura</translation>
    </message>
    <message>
        <source>Unsupported content encoding: %1</source>
        <translation>La codificació del contingut no està admesa: %1</translation>
    </message>
    <message>
        <source>Failed to initialize the compression decoder.</source>
        <translation>La inicialització del descodificador de compressió ha fallat.</translation>
    </message>
    <message>
        <source>The decompressed output exceeds the limits specified by QNetworkRequest::decompressedSafetyCheckThreshold()</source>
        <translation>La sortida descomprimida excedeix els límits especificats per QNetworkRequest::decompressedSafetyCheckThreshold()</translation>
    </message>
    <message>
        <source>Brotli error: %1</source>
        <extracomment>Brotli (compression algorithm) decoding error, e.g. corrupted input or memory allocation problem.</extracomment>
        <translation>Error de Brotli: %1</translation>
    </message>
    <message>
        <source>ZStandard error: %1</source>
        <translation>Error de ZStandard: %1</translation>
    </message>
    <message>
        <source>Decompression failed: %1</source>
        <translation>Ha fallat la descompressió: %1</translation>
    </message>
    <message>
        <source>Data downloaded is too large to store</source>
        <translation>Les dades baixades són massa grans per a emmagatzemar</translation>
    </message>
    <message>
        <source>Failed to initialize decompression: %1</source>
        <translation>Ha fallat en inicialitzar la descompressió: %1</translation>
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <source>Did not receive HTTP response from proxy</source>
        <translation>No s&apos;ha rebut cap resposta HTTP del servidor intermediari</translation>
    </message>
    <message>
        <source>Error parsing authentication request from proxy</source>
        <translation>Error en analitzar la sol·licitud d&apos;autenticació del servidor intermediari</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation>Es requereix autenticació</translation>
    </message>
    <message>
        <source>Proxy denied connection</source>
        <translation>El servidor intermediari ha denegat la connexió</translation>
    </message>
    <message>
        <source>Error communicating with HTTP proxy</source>
        <translation>Error en comunicar amb el servidor intermediari HTTP</translation>
    </message>
    <message>
        <source>Proxy server not found</source>
        <translation>No s&apos;ha trobat el servidor intermediari</translation>
    </message>
    <message>
        <source>Proxy connection refused</source>
        <translation>S&apos;ha rebutjat la connexió al servidor intermediari</translation>
    </message>
    <message>
        <source>Proxy server connection timed out</source>
        <translation>Temps de connexió excedit al servidor intermediari</translation>
    </message>
    <message>
        <source>Proxy connection closed prematurely</source>
        <translation>La connexió al servidor intermediari s&apos;ha tancat abans d&apos;hora</translation>
    </message>
</context>
<context>
    <name>QIBaseDriver</name>
    <message>
        <source>failed to query time zone mapping from system table</source>
        <translation type="vanished">ha fallat en consultar el mapatge de la zona horària des de la taula del sistema</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Error en obrir la base de dades</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>No s&apos;ha pogut iniciar la transacció</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No s&apos;ha pogut confirmar la transacció</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No s&apos;ha pogut desfer la transacció</translation>
    </message>
    <message>
        <source>Could not subscribe to event notifications for %1.</source>
        <translation>No s&apos;ha pogut subscriure a les notificacions d&apos;esdeveniments per a %1.</translation>
    </message>
    <message>
        <source>Could not unsubscribe from event notifications for %1.</source>
        <translation>No s&apos;ha pogut cancel·lar la suscripció a les notificacions d&apos;esdeveniments per a %1.</translation>
    </message>
</context>
<context>
    <name>QIBaseResult</name>
    <message>
        <source>Unable to create BLOB</source>
        <translation>No s&apos;ha pogut crear un BLOB</translation>
    </message>
    <message>
        <source>Unable to write BLOB</source>
        <translation>No s&apos;ha pogut escriure el BLOB</translation>
    </message>
    <message>
        <source>Unable to open BLOB</source>
        <translation>No s&apos;ha pogut obrir el BLOB</translation>
    </message>
    <message>
        <source>Unable to read BLOB</source>
        <translation>No s&apos;ha pogut llegir el BLOB</translation>
    </message>
    <message>
        <source>Could not find array</source>
        <translation>No s&apos;ha pogut trobar la matriu</translation>
    </message>
    <message>
        <source>Could not get array data</source>
        <translation>No s&apos;han pogut obtenir les dades de la matriu</translation>
    </message>
    <message>
        <source>Array size mismatch. Field name: %3, expected size: %1. Supplied size: %2</source>
        <translation>La mida de la matriu no coincideix. Nom del camp: %3, mida esperada: %1. Mida subministrada: %2</translation>
    </message>
    <message>
        <source>Array dimensions mismatch. Field name: %1</source>
        <translation>Les dimensions de la matriu no coincideixen. Nom del camp: %1</translation>
    </message>
    <message>
        <source>Array size mismatch: size of %1 is %2, size of provided list is %3</source>
        <translation>La mida de la matriu no coincideix: la mida de %1 és %2, la mida de la llista proporcionada és %3</translation>
    </message>
    <message>
        <source>Could not get query info</source>
        <translation>No s&apos;ha pogut obtenir la informació de la consulta</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>No s&apos;ha pogut iniciar la transacció</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No s&apos;ha pogut confirmar la transacció</translation>
    </message>
    <message>
        <source>Could not allocate statement</source>
        <translation>No s&apos;ha pogut assignar la sentència</translation>
    </message>
    <message>
        <source>Could not prepare statement</source>
        <translation>No s&apos;ha pogut preparar la sentència</translation>
    </message>
    <message>
        <source>Could not describe input statement</source>
        <translation>No s&apos;ha pogut descriure la sentència d&apos;entrada</translation>
    </message>
    <message>
        <source>Could not describe statement</source>
        <translation>No s&apos;ha pogut descriure la sentència</translation>
    </message>
    <message>
        <source>Unable to close statement</source>
        <translation>No s&apos;ha pogut tancar la sentència</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>No s&apos;ha pogut executar la consulta</translation>
    </message>
    <message>
        <source>Could not fetch next item</source>
        <translation>No s&apos;ha pogut recuperar l&apos;element següent</translation>
    </message>
    <message>
        <source>Could not get statement info</source>
        <translation>No s&apos;ha pogut obtenir la informació de la sentència</translation>
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <source>Permission denied</source>
        <translation>S&apos;ha denegat el permís</translation>
    </message>
    <message>
        <source>Too many open files</source>
        <translation>Massa fitxers oberts</translation>
    </message>
    <message>
        <source>No such file or directory</source>
        <translation>Aquest fitxer o directori no existeix</translation>
    </message>
    <message>
        <source>No space left on device</source>
        <translation>No queda espai al dispositiu</translation>
    </message>
    <message>
        <source>file to open is a directory</source>
        <translation>el fitxer a obrir és un directori</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
</context>
<context>
    <name>QImageReader</name>
    <message>
        <source>Invalid device</source>
        <translation>Dispositiu no vàlid</translation>
    </message>
    <message>
        <source>File not found</source>
        <translation>No s&apos;ha trobat el fitxer</translation>
    </message>
    <message>
        <source>Unsupported image format</source>
        <translation>Format d&apos;imatge no admès</translation>
    </message>
    <message>
        <source>Unable to read image data</source>
        <translation>No s&apos;han pogut llegir les dades de la imatge</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
</context>
<context>
    <name>QImageWriter</name>
    <message>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
    <message>
        <source>Device is not set</source>
        <translation>No s&apos;ha definit cap dispositiu</translation>
    </message>
    <message>
        <source>Cannot open device for writing: %1</source>
        <translation>No s&apos;ha pogut obrir el dispositiu per escriptura: %1</translation>
    </message>
    <message>
        <source>Device not writable</source>
        <translation>No es pot escriure al dispositiu</translation>
    </message>
    <message>
        <source>Unsupported image format</source>
        <translation>Format d&apos;imatge no admès</translation>
    </message>
    <message>
        <source>Image is empty</source>
        <translation>La imatge és buida</translation>
    </message>
</context>
<context>
    <name>QInputDialog</name>
    <message>
        <source>Enter a value:</source>
        <translation>Introduïu un valor:</translation>
    </message>
</context>
<context>
    <name>QJsonParseError</name>
    <message>
        <source>no error occurred</source>
        <translation>sense errors</translation>
    </message>
    <message>
        <source>unterminated object</source>
        <translation>objecte sense finalitzar</translation>
    </message>
    <message>
        <source>missing name separator</source>
        <translation>manca separador de nom</translation>
    </message>
    <message>
        <source>unterminated array</source>
        <translation>matriu sense finalitzar</translation>
    </message>
    <message>
        <source>missing value separator</source>
        <translation>manca separador de valor</translation>
    </message>
    <message>
        <source>illegal value</source>
        <translation>valor il·legal</translation>
    </message>
    <message>
        <source>invalid termination by number</source>
        <translation>finalització no vàlida per nombre</translation>
    </message>
    <message>
        <source>illegal number</source>
        <translation>nombre il·legal</translation>
    </message>
    <message>
        <source>invalid escape sequence</source>
        <translation>seqüència d&apos;escapada no vàlida</translation>
    </message>
    <message>
        <source>invalid UTF8 string</source>
        <translation>cadena UTF8 no vàlida</translation>
    </message>
    <message>
        <source>unterminated string</source>
        <translation>cadena sense finalitzar</translation>
    </message>
    <message>
        <source>object is missing after a comma</source>
        <translation>manca un objecte després d&apos;una coma</translation>
    </message>
    <message>
        <source>too deeply nested document</source>
        <translation>document imbricat amb massa profunditat</translation>
    </message>
    <message>
        <source>too large document</source>
        <translation>document massa gran</translation>
    </message>
    <message>
        <source>garbage at the end of the document</source>
        <translation>brutícia al final del document</translation>
    </message>
</context>
<context>
    <name>QKeySequenceEdit</name>
    <message>
        <source>Press shortcut</source>
        <translation>Premeu drecera</translation>
    </message>
    <message>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation>%1,...</translation>
    </message>
</context>
<context>
    <name>QLibrary</name>
    <message>
        <source>&apos;%1&apos; is not an ELF object (%2)</source>
        <translation type="vanished">«%1» no és cap objecte ELF (%2)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not an ELF object</source>
        <translation type="vanished">«%1» no és cap objecte ELF</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is an invalid ELF object (%2)</source>
        <translation type="vanished">«%1» és un objecte ELF no vàlid (%2)</translation>
    </message>
    <message>
        <source>odd cpu architecture</source>
        <translation type="vanished">arquitectura estranya de la CPU</translation>
    </message>
    <message>
        <source>wrong cpu architecture</source>
        <translation type="vanished">arquitectura incorrecta de la CPU</translation>
    </message>
    <message>
        <source>odd endianness</source>
        <translation type="vanished">«endianness» estrany</translation>
    </message>
    <message>
        <source>unexpected e_shsize</source>
        <translation type="vanished">«e_shsize» inesperat</translation>
    </message>
    <message>
        <source>unexpected e_shentsize</source>
        <translation type="vanished">«e_shentsize» inesperat</translation>
    </message>
    <message numerus="yes">
        <source>announced %n section(s), each %1 byte(s), exceed file size</source>
        <translation type="vanished">
            <numerusform>s&apos;han anunciat %n secció, cada una de %1 byte, s&apos;ha excedit la mida del fitxer</numerusform>
            <numerusform>s&apos;han anunciat %n seccions, cada una de %1 bytes, s&apos;ha excedit la mida del fitxer</numerusform>
        </translation>
    </message>
    <message>
        <source>shstrtab section header seems to be at %1</source>
        <translation type="vanished">la capçalera de la secció «shstrtab» sembla que està a %1</translation>
    </message>
    <message>
        <source>string table seems to be at %1</source>
        <translation type="vanished">la taula de cadenes sembla que està a %1</translation>
    </message>
    <message>
        <source>section name %1 of %2 behind end of file</source>
        <translation type="vanished">la secció amb nom %1 de %2 està darrere del final del fitxer</translation>
    </message>
    <message>
        <source>empty .rodata. not a library.</source>
        <translation type="vanished">«.rodata» buit. No és cap biblioteca.</translation>
    </message>
    <message>
        <source>missing section data. This is not a library.</source>
        <translation type="vanished">manca la secció «data». Això no és cap biblioteca.</translation>
    </message>
    <message>
        <source>Plugin verification data mismatch in &apos;%1&apos;</source>
        <translation type="vanished">Error de verificació de dades del connector a «%1»</translation>
    </message>
    <message>
        <source>Failed to extract plugin meta data from &apos;%1&apos;</source>
        <translation type="vanished">Ha fallat en extreure les metadades del connector des de «%1»</translation>
    </message>
    <message>
        <source>Failed to extract plugin meta data from &apos;%1&apos;: %2</source>
        <translation>Ha fallat en extreure les metadades del connector des de «%1»: %2</translation>
    </message>
    <message>
        <source>The shared library was not found.</source>
        <translation>No s&apos;ha trobat la biblioteca compartida.</translation>
    </message>
    <message>
        <source>Could not resolve &apos;qt_plugin_instance&apos; function</source>
        <translation>No s&apos;ha pogut resoldre la funció «qt_plugin_instance»</translation>
    </message>
    <message>
        <source>metadata too small</source>
        <translation>metadades massa petites</translation>
    </message>
    <message>
        <source>entrypoint to query the plugin meta data not found</source>
        <translation>no s&apos;ha trobat punt d&apos;entrada per a consultar les metadades del connector</translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is not a valid Qt plugin.</source>
        <translation>El fitxer «%1» no és un connector vàlid de les Qt.</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (%2.%3.%4) [%5]</source>
        <translation>El connector «%1» usa una biblioteca Qt incompatible. (%2.%3.%4) [%5]</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (Cannot mix debug and release libraries.)</source>
        <translation>El connector «%1» usa una biblioteca Qt incompatible. (No es poden barrejar biblioteques de depuració i publicades)</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
    <message>
        <source>Cannot load library %1: %2</source>
        <translation>No s&apos;ha pogut carregar la biblioteca %1: %2</translation>
    </message>
    <message>
        <source>Cannot unload library %1: %2</source>
        <translation>No s&apos;ha pogut descarregar la biblioteca %1: %2</translation>
    </message>
    <message>
        <source>Cannot resolve symbol &quot;%1&quot; in %2: %3</source>
        <translation type="vanished">No s&apos;ha pogut resoldre el símbol «%1» en %2: %3</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid Mach-O binary (%2)</source>
        <translation>«%1» no és cap binari Mach-O vàlid (%2)</translation>
    </message>
    <message>
        <source>file is corrupt</source>
        <translation>el fitxer està malmès</translation>
    </message>
    <message>
        <source>file is for the wrong endianness</source>
        <translation>el fitxer és per a l&apos;«endianness» erroni</translation>
    </message>
    <message>
        <source>file has an unknown ELF version</source>
        <translation>el fitxer té una versió ELF desconeguda</translation>
    </message>
    <message>
        <source>file has an unexpected ABI</source>
        <translation>el fitxer té un ABI inesperat</translation>
    </message>
    <message>
        <source>file is not a shared object</source>
        <translation>el fitxer no és cap objecte compartit</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid ELF object (%2)</source>
        <translation>«%1» no és un objecte ELF vàlid (%2)</translation>
    </message>
    <message>
        <source>unimplemented: PN_XNUM program headers</source>
        <translation>sense implementar: capçaleres de programa PN_XNUM</translation>
    </message>
    <message>
        <source>program header table extends past the end of the file</source>
        <translation>la taula de capçalera del programa s&apos;estén més enllà del final del fitxer</translation>
    </message>
    <message>
        <source>a program header entry extends past the end of the file</source>
        <translation>una entrada de capçalera de programa s&apos;estén més enllà del final del fitxer</translation>
    </message>
    <message>
        <source>a note segment start is not properly aligned (offset 0x%1, alignment %2)</source>
        <translation>un inici de segment de nota no està correctament alineat (desplaçament 0x%1, alineació %2)</translation>
    </message>
    <message>
        <source>section table extends past the end of the file</source>
        <translation>la taula de seccions s&apos;estén més enllà del final del fitxer</translation>
    </message>
    <message>
        <source>section header string table extends past the end of the file</source>
        <translation>la taula de cadenes de capçalera de secció s&apos;estén més enllà del final del fitxer</translation>
    </message>
    <message>
        <source>a section name extends past the end of the file</source>
        <translation>un nom de secció s&apos;estén més enllà del final del fitxer</translation>
    </message>
    <message>
        <source>file too small</source>
        <translation>el fitxer és massa petit</translation>
    </message>
    <message>
        <source>unexpected program header entry size (%1)</source>
        <translation>mida inesperada de l&apos;entrada de la capçalera del programa (%1)</translation>
    </message>
    <message>
        <source>unexpected section entry size (%1)</source>
        <translation>mida inesperada d&apos;entrada de secció (%1)</translation>
    </message>
    <message>
        <source>e_shstrndx greater than the number of sections e_shnum (%1 &gt;= %2)</source>
        <translation>e_shstrndx més gran que el nombre de seccions e_shnum (%1 &gt;= %2)</translation>
    </message>
    <message>
        <source>no suitable architecture in fat binary</source>
        <translation>no hi ha cap arquitectura apropiada al «fat binary»</translation>
    </message>
    <message>
        <source>invalid magic %1</source>
        <translation>màgic %1 no vàlid</translation>
    </message>
    <message>
        <source>wrong architecture</source>
        <translation>arquitectura incorrecta</translation>
    </message>
    <message>
        <source>not a dynamic library</source>
        <translation>no és cap biblioteca dinàmica</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a Qt plugin</source>
        <translation>«%1» no és cap connector Qt</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid Windows DLL (%2)</source>
        <translation>«%1» no és una DLL vàlida del Windows (%2)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is too small</source>
        <translation>«%1» és massa petit</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a Qt plugin (%2)</source>
        <translation>«%1» no és cap connector Qt (%2)</translation>
    </message>
    <message>
        <source>metadata not found</source>
        <translation>no s&apos;han trobat les metadades</translation>
    </message>
    <message>
        <source>invalid signature</source>
        <translation>signatura no vàlida</translation>
    </message>
    <message>
        <source>file is for a different processor</source>
        <translation>el fitxer és per a un processador diferent</translation>
    </message>
    <message>
        <source>file has no sections</source>
        <translation>el fitxer no té seccions</translation>
    </message>
    <message>
        <source>wrong characteristics</source>
        <translation>característiques incorrectes</translation>
    </message>
    <message>
        <source>file is for a different word size</source>
        <translation>el fitxer és per a una mida diferent de paraula</translation>
    </message>
    <message>
        <source>file has no code</source>
        <translation>el fitxer no té codi</translation>
    </message>
    <message>
        <source>a section name is empty or extends past the end of the file</source>
        <translation>un nom de secció està buit o s&apos;estén més enllà del final del fitxer</translation>
    </message>
    <message>
        <source>section contents extend past the end of the file</source>
        <translation>el contingut de la secció s&apos;estén més enllà del final del fitxer</translation>
    </message>
    <message>
        <source>.qtmetadata section is too small</source>
        <translation>la secció «.qtmetadata» és massa petita</translation>
    </message>
    <message>
        <source>.qtmetadata section has incorrect magic</source>
        <translation>la secció «.qtmetadata» té un màgic incorrecte</translation>
    </message>
    <message>
        <source>.qtmetadata section is writable</source>
        <translation>la secció «.qtmetadata» s&apos;hi pot escriure</translation>
    </message>
    <message>
        <source>.qtmetadata section is executable</source>
        <translation>la secció «.qtmetadata» és executable</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Desfés</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Refés</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Re&amp;talla</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Enganxa</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
</context>
<context>
    <name>QLocalServer</name>
    <message>
        <source>%1: Name error</source>
        <translation>%1: Error al nom</translation>
    </message>
    <message>
        <source>%1: Permission denied</source>
        <translation>%1: S&apos;ha denegat el permís</translation>
    </message>
    <message>
        <source>%1: Address in use</source>
        <translation>%1: Adreça en ús</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Error desconegut %2</translation>
    </message>
</context>
<context>
    <name>QLocalSocket</name>
    <message>
        <source>%1: Connection refused</source>
        <translation>%1: S&apos;ha rebutjat la connexió</translation>
    </message>
    <message>
        <source>%1: Remote closed</source>
        <translation>%1: El remot ha tancat</translation>
    </message>
    <message>
        <source>%1: Invalid name</source>
        <translation>%1: Nom no vàlid</translation>
    </message>
    <message>
        <source>%1: Socket access error</source>
        <translation>%1: Error d&apos;accés al sòcol</translation>
    </message>
    <message>
        <source>%1: Socket resource error</source>
        <translation>%1: Error de recurs del sòcol</translation>
    </message>
    <message>
        <source>%1: Socket operation timed out</source>
        <translation>%1: L&apos;operació de sòcol ha excedit el temps</translation>
    </message>
    <message>
        <source>%1: Datagram too large</source>
        <translation>%1: El datagrama és massa gran</translation>
    </message>
    <message>
        <source>%1: Connection error</source>
        <translation>%1: Error de connexió</translation>
    </message>
    <message>
        <source>%1: The socket operation is not supported</source>
        <translation>%1: Operació no admesa al sòcol</translation>
    </message>
    <message>
        <source>%1: Operation not permitted when socket is in this state</source>
        <translation>%1: Operació no permesa quan el sòcol és en aquest estat</translation>
    </message>
    <message>
        <source>%1: Unknown error</source>
        <translation>%1: Error desconegut</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>S&apos;intenta connectar mentre la connexió és en curs</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Error desconegut %2</translation>
    </message>
    <message>
        <source>%1: Access denied</source>
        <translation>%1: S&apos;ha denegat l&apos;accés</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>El sòcol no s&apos;ha connectat</translation>
    </message>
    <message>
        <source>Remote closed</source>
        <translation>El remot ha tancat</translation>
    </message>
</context>
<context>
    <name>QMYSQLDriver</name>
    <message>
        <source>Unable to allocate a MYSQL object</source>
        <translation>No s&apos;ha pogut assignar un objecte MYSQL</translation>
    </message>
    <message>
        <source>Unable to open database &apos;%1&apos;</source>
        <translation>No s&apos;ha pogut obrir la base de dades «%1»</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>No s&apos;ha pogut connectar</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>La transacció no ha pogut començar</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No s&apos;ha pogut confirmar la transacció</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No s&apos;ha pogut desfer la transacció</translation>
    </message>
</context>
<context>
    <name>QMYSQLResult</name>
    <message>
        <source>Unable to fetch data</source>
        <translation>No s&apos;han pogut recuperar les dades</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>No s&apos;ha pogut executar la consulta</translation>
    </message>
    <message>
        <source>Unable to store result</source>
        <translation>No s&apos;ha pogut emmagatzemar el resultat</translation>
    </message>
    <message>
        <source>Unable to execute next query</source>
        <translation>No s&apos;ha pogut executar la consulta següent</translation>
    </message>
    <message>
        <source>Unable to store next result</source>
        <translation>No s&apos;ha pogut emmagatzemar el resultat següent</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No s&apos;ha pogut preparar la sentència</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>No s&apos;ha pogut reiniciar la sentència</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>No s&apos;ha pogut vincular el valor</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No s&apos;ha pogut executar la sentència</translation>
    </message>
    <message>
        <source>Unable to bind outvalues</source>
        <translation>No s&apos;han pogut vincular els valors excedits</translation>
    </message>
    <message>
        <source>Unable to store statement results</source>
        <translation>No s&apos;ha pogut emmagatzemar el resultat de la sentència</translation>
    </message>
</context>
<context>
    <name>QMdiArea</name>
    <message>
        <source>(Untitled)</source>
        <translation>(Sense títol)</translation>
    </message>
</context>
<context>
    <name>QMdiSubWindow</name>
    <message>
        <source>- [%1]</source>
        <translation>- [%1]</translation>
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimitza</translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation>Maximitza</translation>
    </message>
    <message>
        <source>Unshade</source>
        <translation>Desplega</translation>
    </message>
    <message>
        <source>Shade</source>
        <translation>Plega</translation>
    </message>
    <message>
        <source>Restore Down</source>
        <translation>Restaura avall</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Restaura</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menú</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Restaura</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Mou</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Mida</translation>
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation>Mi&amp;nimitza</translation>
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ximitza</translation>
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation>Queda&apos;t al damun&amp;t</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Tanca</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Show Details...</source>
        <translation>Mostra els detalls...</translation>
    </message>
    <message>
        <source>Hide Details...</source>
        <translation>Oculta els detalls...</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under multiple licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of GNU (L)GPL.&lt;/p&gt;&lt;p&gt;Qt licensed under GNU (L)GPL is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the respective licenses.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;https://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) The Qt Company Ltd. and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd. product developed as an open source project. See &lt;a href=&quot;https://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <extracomment>Leave this text untranslated or include a verbatim copy of it below and note that it is the authoritative version in case of doubt.</extracomment>
        <translation>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under multiple licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of GNU (L)GPL.&lt;/p&gt;&lt;p&gt;Qt licensed under GNU (L)GPL is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the respective licenses.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;https://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) The Qt Company Ltd. and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd. product developed as an open source project. See &lt;a href=&quot;https://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under multiple licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of GNU (L)GPL.&lt;/p&gt;&lt;p&gt;Qt licensed under GNU (L)GPL is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the respective licenses.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd product developed as an open source project. See &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <extracomment>Leave this text untranslated or include a verbatim copy of it below and note that it is the authoritative version in case of doubt.</extracomment>
        <translation type="vanished">&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under multiple licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of GNU (L)GPL.&lt;/p&gt;&lt;p&gt;Qt licensed under GNU (L)GPL is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the respective licenses.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd product developed as an open source project. See &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 3.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 3 is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the GNU LGPL version 3.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd product developed as an open source project. See &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation type="vanished">&lt;p&gt;Les Qt són un conjunt d&apos;eines C++ pel desenvolupament d&apos;aplicacions multiplataforma.&lt;/p&gt;&lt;p&gt;Les Qt proporcionen portabilitat amb un codi font únic entre els principals sistemes operatius. Les Qt també són disponibles per a Linux incrustat i sistemes operatius incrustats i mòbils.&lt;/p&gt;&lt;p&gt;Les Qt estan disponibles en tres opcions de llicència diferents dissenyades per a adaptar-se a les necessitats dels diversos usuaris.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota el nostre acord de llicència comercial són apropiades per al desenvolupament de programari propietari/comercial a on no voleu compartir cap codi font amb terceres parts o no podeu complir amb els termes de la versió 3 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota la versió 3 de la LGPL de la GNU són apropiades per al desenvolupament d&apos;aplicacions Qt quan podeu complir amb els termes i condicions de la versió 3 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Si us plau, vegeu a &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; un resum de les llicències de les Qt.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 The Qt Company Ltd i altres col·laboradors.&lt;/p&gt;&lt;p&gt;Les Qt i el logotip de les Qt són marques comercials de The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Les Qt són un producte de The Qt Company Ltd desenvolupat com un projecte de codi font obert. Vegeu &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; per a més informació.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">D&apos;acord</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="vanished">Ajuda</translation>
    </message>
    <message>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;&lt;p&gt;This program uses Qt version %1.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Quant a les Qt&lt;/h3&gt;&lt;p&gt;Aquest programa utilitza la versió %1 de les Qt.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 3 or GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 3 is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the GNU LGPL version 3.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd product developed as an open source project. See &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation type="vanished">&lt;p&gt;Les Qt són un conjunt d&apos;eines C++ pel desenvolupament d&apos;aplicacions multiplataforma.&lt;/p&gt;&lt;p&gt;Les Qt proporcionen portabilitat amb un codi font únic entre els principals sistemes operatius. Les Qt també són disponibles per a Linux incrustat i sistemes operatius incrustats i mòbils.&lt;/p&gt;&lt;p&gt;Les Qt estan disponibles en tres opcions de llicència diferents dissenyades per a adaptar-se a les necessitats dels diversos usuaris.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota el nostre acord de llicència comercial són apropiades per al desenvolupament de programari propietari/comercial a on no voleu compartir cap codi font amb terceres parts o no podeu complir amb els termes de la versió 3 de la LGPL de la GNU o de la versió 2.1 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota la versió 3 de la LGPL de la GNU són apropiades per al desenvolupament d&apos;aplicacions Qt quan podeu complir amb els termes i condicions de la versió 3 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota la versió 2.1 de la LGPL de la GNU són apropiades per al desenvolupament d&apos;aplicacions Qt perquè pugueu complir amb els termes i condicions de la versió 2.1 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Si us plau, vegeu a &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; un resum de les llicències de les Qt.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 The Qt Company Ltd i altres col·laboradors.&lt;/p&gt;&lt;p&gt;Les Qt i el logotip de les Qt són marques comercials de The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Les Qt són un producte de The Qt Company Ltd desenvolupat com un projecte de codi font obert. Vegeu &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; per a més informació.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 3 or GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 3 is appropriate for the development of Qt applications provided you can comply with the terms and conditions of the GNU LGPL version 3.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt applications provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 Digia Plc and/or its subsidiary(-ies) and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of Digia Plc and/or its subsidiary(-ies).&lt;/p&gt;&lt;p&gt;Qt is a Digia product developed as an open source project. See &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation type="vanished">&lt;p&gt;Les Qt són un conjunt d&apos;eines C++ pel desenvolupament d&apos;aplicacions multiplataforma.&lt;/p&gt;&lt;p&gt;Les Qt proporcionen portabilitat amb un codi font únic entre els principals sistemes operatius. Les Qt també són disponibles per a Linux incrustat i sistemes operatius incrustats i mòbils.&lt;/p&gt;&lt;p&gt;Les Qt estan disponibles en tres opcions de llicència diferents dissenyades per a adaptar-se a les necessitats dels diversos usuaris.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota el nostre acord de llicència comercial són apropiades per al desenvolupament de programari propietari/comercial a on no voleu compartir cap codi font amb terceres parts o no podeu complir amb els termes de la versió 3 de la LGPL de la GNU o de la versió 2.1 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota la versió 3 de la LGPL de la GNU són apropiades per al desenvolupament d&apos;aplicacions Qt quan podeu complir amb els termes i condicions de la versió 3 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota la versió 2.1 de la LGPL de la GNU són apropiades per al desenvolupament d&apos;aplicacions Qt perquè pugueu complir amb els termes i condicions de la versió 2.1 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Si us plau, vegeu a &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; un resum de les llicències de les Qt.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 Digia Plc i/o les seves filials i altres col·laboradors.&lt;/p&gt;&lt;p&gt;Les Qt i el logotip de les Qt són marques comercials de Digia Plc i/o les seves filials.&lt;/p&gt;&lt;p&gt;Les Qt són un producte de Digia desenvolupat com un projecte de codi font obert. Vegeu &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; per a més informació.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 2.1 or GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt applications provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU General Public License version 3.0 is appropriate for the development of Qt 
applications where you wish to use such applications in combination with software subject to the terms of the GNU GPL version 3.0 or where you are otherwise willing to comply with the terms of the GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://qt.io/licensing/&quot;&gt;qt.io/licensing&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) 2015 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of Digia Plc and/or its subsidiary(-ies).&lt;/p&gt;&lt;p&gt;Qt is developed as an open source project on &lt;a href=&quot;http://qt-project.org/&quot;&gt;qt-project.org&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Qt is a Digia product. See &lt;a href=&quot;http://qt.io/&quot;&gt;qt.io&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation type="vanished">&lt;p&gt;Les Qt són un conjunt d&apos;eines C++ pel desenvolupament d&apos;aplicacions multiplataforma.&lt;/p&gt;&lt;p&gt;Les Qt proporcionen portabilitat amb un codi font únic entre els principals sistemes operatius. Les Qt també són disponibles per a Linux incrustat i sistemes operatius incrustats i mòbils.&lt;/p&gt;&lt;p&gt;Les Qt estan disponibles en tres opcions de llicència diferents dissenyades per a adaptar-se a les necessitats dels diversos usuaris.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota el nostre acord de llicència comercial són apropiades per al desenvolupament de programari propietari/comercial a on no voleu compartir cap codi font amb terceres parts o no podeu complir amb els termes de la versió 2.1 de la LGPL de la GNU o la versió 3.0 de la GPL de la GNU.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota la versió 2.1 de la LGPL de la GNU són apropiades per al desenvolupament d&apos;aplicacions Qt perquè pugueu complir amb els termes i condicions de la versió 2.1 de la LGPL de la GNU.&lt;/p&gt;&lt;p&gt;Les Qt llicenciades sota la versió 3.0 de la Llicència Pública General de la GNU són apropiades per al desenvolupament d&apos;aplicacions Qt quan voleu utilitzar aquestes aplicacions en combinació amb programari sotmès als termes de la versió 3.0 de la GPL de la GNU o quan esteu disposat a complir amb els termes de la versió 3.0 de la GPL de la GNU.&lt;/p&gt;&lt;p&gt;Si us plau, vegeu a &lt;a href=&quot;http://qt.io/licensing/&quot;&gt;qt.io/licensing&lt;/a&gt; un resum de les llicències de les Qt.&lt;/p&gt;&lt;p&gt;Copyright (C) 2015 The Qt Company Ltd i altres col·laboradors.&lt;/p&gt;&lt;p&gt;Les Qt i el logotip de les Qt són marques comercials de Digia Plc i/o les seves filials.&lt;/p&gt;&lt;p&gt;Les Qt es desenvolupen com un projecte de codi font obert a &lt;a href=&quot;http://qt-project.org/&quot;&gt;qt-project.org&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Les Qt són un producte de Digia. Vegeu &lt;a href=&quot;http://qt.io/&quot;&gt;qt.io&lt;/a&gt; per a més informació.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Quant a les Qt</translation>
    </message>
</context>
<context>
    <name>QNativeSocketEngine</name>
    <message>
        <source>Unable to initialize non-blocking socket</source>
        <translation>No s&apos;ha pogut inicialitzar el sòcol no bloquejant</translation>
    </message>
    <message>
        <source>Unable to initialize broadcast socket</source>
        <translation>No s&apos;ha pogut inicialitzar el sòcol de difusió</translation>
    </message>
    <message>
        <source>Attempt to use IPv6 socket on a platform with no IPv6 support</source>
        <translation>S&apos;intenta usar un sòcol IPv6 en una plataforma que no admet IPv6</translation>
    </message>
    <message>
        <source>The remote host closed the connection</source>
        <translation>L&apos;ordinador remot ha tancat la connexió</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>L&apos;operació de xarxa ha excedit el temps</translation>
    </message>
    <message>
        <source>Out of resources</source>
        <translation>Sense recursos</translation>
    </message>
    <message>
        <source>Unsupported socket operation</source>
        <translation>Operació de sòcol no admesa</translation>
    </message>
    <message>
        <source>Protocol type not supported</source>
        <translation>Tipus de protocol no admès</translation>
    </message>
    <message>
        <source>Invalid socket descriptor</source>
        <translation>Descriptor de sòcol no vàlid</translation>
    </message>
    <message>
        <source>Host unreachable</source>
        <translation>Ordinador no accessible</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Xarxa no accessible</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>S&apos;ha denegat el permís</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Temps de connexió excedit</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>S&apos;ha rebutjat la connexió</translation>
    </message>
    <message>
        <source>The bound address is already in use</source>
        <translation>Ja s&apos;està usant l&apos;adreça vinculada</translation>
    </message>
    <message>
        <source>The address is not available</source>
        <translation>L&apos;adreça no és disponible</translation>
    </message>
    <message>
        <source>The address is protected</source>
        <translation>L&apos;adreça està protegida</translation>
    </message>
    <message>
        <source>Datagram was too large to send</source>
        <translation>El datagrama era massa gran per a enviar-lo</translation>
    </message>
    <message>
        <source>Unable to send a message</source>
        <translation>No s&apos;ha pogut enviar un missatge</translation>
    </message>
    <message>
        <source>Unable to receive a message</source>
        <translation>No s&apos;ha pogut rebre un missatge</translation>
    </message>
    <message>
        <source>Unable to write</source>
        <translation>No s&apos;ha pogut escriure</translation>
    </message>
    <message>
        <source>Network error</source>
        <translation>Error de xarxa</translation>
    </message>
    <message>
        <source>Another socket is already listening on the same port</source>
        <translation>Ja hi ha un altre sòcol escoltant al mateix port</translation>
    </message>
    <message>
        <source>Operation on non-socket</source>
        <translation>Operació sense sòcol</translation>
    </message>
    <message>
        <source>The proxy type is invalid for this operation</source>
        <translation>El tipus de servidor intermediari no és vàlid per a aquesta operació</translation>
    </message>
    <message>
        <source>Temporary error</source>
        <translation>Error temporal</translation>
    </message>
    <message>
        <source>Network dropped connection on reset</source>
        <translation>La xarxa ha tallat la connexió per un reinici</translation>
    </message>
    <message>
        <source>Connection reset by peer</source>
        <translation>La màquina remota ha reiniciat la connexió</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessCacheBackend</name>
    <message>
        <source>Error opening %1</source>
        <translation>Error en obrir %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDataBackend</name>
    <message>
        <source>Invalid URI: %1</source>
        <translation>URI no vàlid: %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDebugPipeBackend</name>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Error d&apos;escriptura en escriure a %1: %2</translation>
    </message>
    <message>
        <source>Socket error on %1: %2</source>
        <translation>Error de sòcol a %1: %2</translation>
    </message>
    <message>
        <source>Remote host closed the connection prematurely on %1</source>
        <translation>L&apos;ordinador remot ha tancat la connexió prematurament a %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFileBackend</name>
    <message>
        <source>Request for opening non-local file %1</source>
        <translation>Sol·licitud per a obrir el fitxer no local %1</translation>
    </message>
    <message>
        <source>Error opening %1: %2</source>
        <translation>Error en obrir %1: %2</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Error d&apos;escriptura en escriure a %1: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: Path is a directory</source>
        <translation>No es pot obrir %1: El camí és un directori</translation>
    </message>
    <message>
        <source>Read error reading from %1: %2</source>
        <translation>Error de lectura en llegir des de %1: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFtpBackend</name>
    <message>
        <source>No suitable proxy found</source>
        <translation type="vanished">No s&apos;ha trobat cap servidor intermediari adequat</translation>
    </message>
    <message>
        <source>Cannot open %1: is a directory</source>
        <translation type="vanished">No es pot obrir %1: És un directori</translation>
    </message>
    <message>
        <source>Logging in to %1 failed: authentication required</source>
        <translation type="vanished">La connexió a %1 ha fallat: Es requereix autenticació</translation>
    </message>
    <message>
        <source>Error while downloading %1: %2</source>
        <translation type="vanished">Error en baixar %1: %2</translation>
    </message>
    <message>
        <source>Error while uploading %1: %2</source>
        <translation type="vanished">Error en pujar %1: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessManager</name>
    <message>
        <source>Network access is disabled.</source>
        <translation type="vanished">L&apos;accés a la xarxa està desactivat.</translation>
    </message>
</context>
<context>
    <name>QNetworkReply</name>
    <message>
        <source>Error downloading %1 - server replied: %2</source>
        <translation type="vanished">Error en baixar %1 - El servidor ha respost: %2</translation>
    </message>
    <message>
        <source>Background request not allowed.</source>
        <translation type="vanished">Sol·licitud en segon pla no permesa.</translation>
    </message>
    <message>
        <source>Network session error.</source>
        <translation type="vanished">Error de sessió de xarxa.</translation>
    </message>
    <message>
        <source>backend start error.</source>
        <translation>error d&apos;inici del dorsal.</translation>
    </message>
    <message>
        <source>Temporary network failure.</source>
        <translation type="vanished">Fallada temporal de xarxa.</translation>
    </message>
    <message>
        <source>Protocol &quot;%1&quot; is unknown</source>
        <translation>El protocol «%1» és desconegut</translation>
    </message>
    <message>
        <source>Error transferring %1 - server replied: %2</source>
        <translation>Error en transferir %1 - el servidor ha respost: %2</translation>
    </message>
    <message>
        <source>Error transferring %1 - server replied with status code %2</source>
        <translation>Error en transferir %1 - el servidor ha respost amb el codi d&apos;estat %2</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyHttpImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Operació cancel·lada</translation>
    </message>
    <message>
        <source>Operation timed out</source>
        <translation>L&apos;operació ha excedit el temps</translation>
    </message>
    <message>
        <source>No suitable proxy found</source>
        <translation>No s&apos;ha trobat cap servidor intermediari adequat</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Operació cancel·lada</translation>
    </message>
</context>
<context>
    <name>QNetworkSession</name>
    <message>
        <source>Invalid configuration.</source>
        <translation type="vanished">Configuració no vàlida.</translation>
    </message>
</context>
<context>
    <name>QNetworkSessionPrivateImpl</name>
    <message>
        <source>Unknown session error.</source>
        <translation type="vanished">Error desconegut de sessió.</translation>
    </message>
    <message>
        <source>The session was aborted by the user or system.</source>
        <translation type="vanished">Sessió interrompuda per l&apos;usuari o el sistema.</translation>
    </message>
    <message>
        <source>The requested operation is not supported by the system.</source>
        <translation type="vanished">L&apos;operació sol·licitada no està admesa pel sistema.</translation>
    </message>
    <message>
        <source>The specified configuration cannot be used.</source>
        <translation type="vanished">No es pot utilitzar la configuració especificada.</translation>
    </message>
    <message>
        <source>Roaming was aborted or is not possible.</source>
        <translation type="vanished">S&apos;ha interromput la itinerància o no és possible.</translation>
    </message>
</context>
<context>
    <name>QOCIDriver</name>
    <message>
        <source>Unable to initialize</source>
        <comment>QOCIDriver</comment>
        <translation>No s&apos;ha pogut inicialitzar</translation>
    </message>
    <message>
        <source>Unable to logon</source>
        <translation>No s&apos;ha pogut connectar</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>La transacció no ha pogut començar</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No s&apos;ha pogut confirmar la transacció</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No s&apos;ha pogut desfer la transacció</translation>
    </message>
</context>
<context>
    <name>QOCIResult</name>
    <message>
        <source>Unable to bind column for batch execute</source>
        <translation>No s&apos;ha pogut vincular la columna per a una execució massiva</translation>
    </message>
    <message>
        <source>Unable to execute batch statement</source>
        <translation>No s&apos;ha pogut executar la sentència massiva</translation>
    </message>
    <message>
        <source>Unable to goto next</source>
        <translation>No s&apos;ha pogut anar al següent</translation>
    </message>
    <message>
        <source>Unable to alloc statement</source>
        <translation>No s&apos;ha pogut assignar la sentència</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No s&apos;ha pogut preparar la sentència</translation>
    </message>
    <message>
        <source>Unable to get statement type</source>
        <translation>No s&apos;ha pogut obtenir el tipus de sentència</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>No s&apos;ha pogut vincular el valor</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No s&apos;ha pogut executar la sentència</translation>
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <source>Unable to connect</source>
        <translation>No s&apos;ha pogut connectar</translation>
    </message>
    <message>
        <source>Unable to connect - Driver doesn&apos;t support all functionality required</source>
        <translation>No s&apos;ha pogut connectar - El controlador no admet totes les funcionalitats requerides</translation>
    </message>
    <message>
        <source>Unable to disable autocommit</source>
        <translation>No s&apos;ha pogut inhabilitar la confirmació automàtica</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No s&apos;ha pogut confirmar la transacció</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No s&apos;ha pogut desfer la transacció</translation>
    </message>
    <message>
        <source>Unable to enable autocommit</source>
        <translation>No s&apos;ha pogut habilitar la confirmació automàtica</translation>
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <source>Unable to fetch last</source>
        <translation>No s&apos;ha pogut recuperar l&apos;últim</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_CURSOR_STATIC&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: no s&apos;ha pogut establir «SQL_CURSOR_STATIC» com a atribut de sentència. Comproveu la configuració del controlador ODBC</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No s&apos;ha pogut executar la sentència</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_ATTR_CURSOR_TYPE&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: No s&apos;ha pogut establir «SQL_ATTR_CURSOR_TYPE» com a atribut de la sentència. Comproveu la vostra configuració del controlador ODBC</translation>
    </message>
    <message>
        <source>Unable to fetch</source>
        <translation>No s&apos;ha pogut recuperar</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>No s&apos;ha pogut recuperar el següent</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>No s&apos;ha pogut recuperar el primer</translation>
    </message>
    <message>
        <source>Unable to fetch previous</source>
        <translation>No s&apos;ha pogut recuperar l&apos;anterior</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No s&apos;ha pogut preparar la sentència</translation>
    </message>
    <message>
        <source>Unable to bind variable</source>
        <translation>No s&apos;ha pogut vincular la variable</translation>
    </message>
</context>
<context>
    <name>QPPDOptionsModel</name>
    <message>
        <source>Name</source>
        <translation type="vanished">Nom</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="vanished">Valor</translation>
    </message>
</context>
<context>
    <name>QPSQLDriver</name>
    <message>
        <source>Unable to connect</source>
        <translation>No s&apos;ha pogut connectar</translation>
    </message>
    <message>
        <source>Unable to set client encoding to &apos;UNICODE&apos;</source>
        <translation>No s&apos;ha pogut establir la codificació del client a «UNICODE»</translation>
    </message>
    <message>
        <source>Could not begin transaction</source>
        <translation>La transacció no ha pogut començar</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>La transacció no ha pogut confirmar-se</translation>
    </message>
    <message>
        <source>Could not rollback transaction</source>
        <translation>La transacció no ha pogut desfer-se</translation>
    </message>
    <message>
        <source>Unable to subscribe</source>
        <translation>No s&apos;ha pogut fer la subscripció</translation>
    </message>
    <message>
        <source>Unable to unsubscribe</source>
        <translation>No s&apos;ha pogut cancel·lar la subscripció</translation>
    </message>
</context>
<context>
    <name>QPSQLResult</name>
    <message>
        <source>Query results lost - probably discarded on executing another SQL query.</source>
        <translation>S&apos;han perdut els resultats de la consulta - probablement descartats en executar una altra consulta SQL.</translation>
    </message>
    <message>
        <source>Unable to create query</source>
        <translation>No s&apos;ha pogut crear la consulta</translation>
    </message>
    <message>
        <source>Unable to get result</source>
        <translation>No s&apos;ha pogut obtenir el resultat</translation>
    </message>
    <message>
        <source>Unable to send query</source>
        <translation>No s&apos;ha pogut enviar la consulta</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No s&apos;ha pogut preparar la sentència</translation>
    </message>
</context>
<context>
    <name>QPageSetupWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulari</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation>Paper</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Mida de pàgina:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Amplada:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Alçada:</translation>
    </message>
    <message>
        <source>Paper source:</source>
        <translation>Origen del paper:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientació</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Apaïsat</translation>
    </message>
    <message>
        <source>Reverse landscape</source>
        <translation>Apaïsat invertit</translation>
    </message>
    <message>
        <source>Reverse portrait</source>
        <translation>Vertical invertit</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>Marges</translation>
    </message>
    <message>
        <source>top margin</source>
        <translation>marge superior</translation>
    </message>
    <message>
        <source>left margin</source>
        <translation>marge esquerre</translation>
    </message>
    <message>
        <source>right margin</source>
        <translation>marge dret</translation>
    </message>
    <message>
        <source>bottom margin</source>
        <translation>marge inferior</translation>
    </message>
    <message>
        <source>Page Layout</source>
        <translation>Disposició de la pàgina</translation>
    </message>
    <message>
        <source>Page order:</source>
        <translation type="vanished">Ordre de les pàgines:</translation>
    </message>
    <message>
        <source>Pages per sheet:</source>
        <translation type="vanished">Pàgines per full:</translation>
    </message>
    <message>
        <source>Millimeters (mm)</source>
        <translation>Mil·límetres (mm)</translation>
    </message>
    <message>
        <source>Inches (in)</source>
        <translation>Polzades (in)</translation>
    </message>
    <message>
        <source>Points (pt)</source>
        <translation>Punts (pt)</translation>
    </message>
    <message>
        <source>Pica (P̸)</source>
        <translation>Pica (P̸)</translation>
    </message>
    <message>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalitzada</translation>
    </message>
    <message>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation>mm</translation>
    </message>
    <message>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation>pt</translation>
    </message>
    <message>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation>in</translation>
    </message>
    <message>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation>P̸</translation>
    </message>
    <message>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation>DD</translation>
    </message>
    <message>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation>CC</translation>
    </message>
    <message>
        <source>Page &amp;order:</source>
        <translation>&amp;Ordre de les pàgines:</translation>
    </message>
    <message>
        <source>Pages &amp;per sheet:</source>
        <translation>Pàgines &amp;per full:</translation>
    </message>
</context>
<context>
    <name>QPageSize</name>
    <message>
        <source>Custom (%1mm x %2mm)</source>
        <extracomment>Custom size name in millimeters</extracomment>
        <translation>Personalitzada (%1mm x %2mm)</translation>
    </message>
    <message>
        <source>Custom (%1pt x %2pt)</source>
        <extracomment>Custom size name in points</extracomment>
        <translation>Personalitzada (%1pt x %2pt)</translation>
    </message>
    <message>
        <source>Custom (%1in x %2in)</source>
        <extracomment>Custom size name in inches</extracomment>
        <translation>Personalitzada (%1in x %2in)</translation>
    </message>
    <message>
        <source>Custom (%1pc x %2pc)</source>
        <extracomment>Custom size name in picas</extracomment>
        <translation>Personalitzada (%1pc x %2pc)</translation>
    </message>
    <message>
        <source>Custom (%1DD x %2DD)</source>
        <extracomment>Custom size name in didots</extracomment>
        <translation>Personalitzada (%1DD x %2DD)</translation>
    </message>
    <message>
        <source>Custom (%1CC x %2CC)</source>
        <extracomment>Custom size name in ciceros</extracomment>
        <translation>Personalitzada (%1CC x %2CC)</translation>
    </message>
    <message>
        <source>%1 x %2 in</source>
        <extracomment>Page size in &apos;Inch&apos;.</extracomment>
        <translation>%1 x %2 in</translation>
    </message>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source>B6</source>
        <translation>B6</translation>
    </message>
    <message>
        <source>B7</source>
        <translation>B7</translation>
    </message>
    <message>
        <source>B8</source>
        <translation>B8</translation>
    </message>
    <message>
        <source>B9</source>
        <translation>B9</translation>
    </message>
    <message>
        <source>B10</source>
        <translation>B10</translation>
    </message>
    <message>
        <source>Executive (7.5 x 10 in)</source>
        <translation>Executiu (7,5 x 10 in)</translation>
    </message>
    <message>
        <source>Executive (7.25 x 10.5 in)</source>
        <translation>Executiu (7,25 x 10,5 in)</translation>
    </message>
    <message>
        <source>Folio (8.27 x 13 in)</source>
        <translation>Foli (8,27 x 13 in)</translation>
    </message>
    <message>
        <source>Legal</source>
        <translation>Legal</translation>
    </message>
    <message>
        <source>Letter / ANSI A</source>
        <translation>Carta / ANSI A</translation>
    </message>
    <message>
        <source>Tabloid / ANSI B</source>
        <translation>Tabloide / ANSI B</translation>
    </message>
    <message>
        <source>Ledger / ANSI B</source>
        <translation>Llibre major / ANSI B</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalitzada</translation>
    </message>
    <message>
        <source>A3 Extra</source>
        <translation>A3 extra</translation>
    </message>
    <message>
        <source>A4 Extra</source>
        <translation>A4 extra</translation>
    </message>
    <message>
        <source>A4 Plus</source>
        <translation>A4 plus</translation>
    </message>
    <message>
        <source>A4 Small</source>
        <translation>A4 petit</translation>
    </message>
    <message>
        <source>A5 Extra</source>
        <translation>A5 extra</translation>
    </message>
    <message>
        <source>B5 Extra</source>
        <translation>B5 extra</translation>
    </message>
    <message>
        <source>JIS B0</source>
        <translation>JIS B0</translation>
    </message>
    <message>
        <source>JIS B1</source>
        <translation>JIS B1</translation>
    </message>
    <message>
        <source>JIS B2</source>
        <translation>JIS B2</translation>
    </message>
    <message>
        <source>JIS B3</source>
        <translation>JIS B3</translation>
    </message>
    <message>
        <source>JIS B4</source>
        <translation>JIS B4</translation>
    </message>
    <message>
        <source>JIS B5</source>
        <translation>JIS B5</translation>
    </message>
    <message>
        <source>JIS B6</source>
        <translation>JIS B6</translation>
    </message>
    <message>
        <source>JIS B7</source>
        <translation>JIS B7</translation>
    </message>
    <message>
        <source>JIS B8</source>
        <translation>JIS B8</translation>
    </message>
    <message>
        <source>JIS B9</source>
        <translation>JIS B9</translation>
    </message>
    <message>
        <source>JIS B10</source>
        <translation>JIS B10</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <source>Legal Extra</source>
        <translation>Legal extra</translation>
    </message>
    <message>
        <source>Letter Extra</source>
        <translation>Carta extra</translation>
    </message>
    <message>
        <source>Letter Plus</source>
        <translation>Carta plus</translation>
    </message>
    <message>
        <source>Letter Small</source>
        <translation>Carta petita</translation>
    </message>
    <message>
        <source>Tabloid Extra</source>
        <translation>Tabloide extra</translation>
    </message>
    <message>
        <source>Architect A</source>
        <translation>Arquitecte A</translation>
    </message>
    <message>
        <source>Architect B</source>
        <translation>Arquitecte B</translation>
    </message>
    <message>
        <source>Architect C</source>
        <translation>Arquitecte C</translation>
    </message>
    <message>
        <source>Architect D</source>
        <translation>Arquitecte D</translation>
    </message>
    <message>
        <source>Architect E</source>
        <translation>Arquitecte E</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation>Quart</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation>Sentència</translation>
    </message>
    <message>
        <source>Super A</source>
        <translation>Super A</translation>
    </message>
    <message>
        <source>Super B</source>
        <translation>Super B</translation>
    </message>
    <message>
        <source>Postcard</source>
        <translation>Postal</translation>
    </message>
    <message>
        <source>Double Postcard</source>
        <translation>Postal doble</translation>
    </message>
    <message>
        <source>PRC 16K</source>
        <translation>PRC 16K</translation>
    </message>
    <message>
        <source>PRC 32K</source>
        <translation>PRC 32K</translation>
    </message>
    <message>
        <source>PRC 32K Big</source>
        <translation>PRC 32K gran</translation>
    </message>
    <message>
        <source>Fan-fold US (14.875 x 11 in)</source>
        <translation>Paper continu US (14,875 x 11 in)</translation>
    </message>
    <message>
        <source>Fan-fold German (8.5 x 12 in)</source>
        <translation>Paper continu alemany (8,5 x 12 in)</translation>
    </message>
    <message>
        <source>Fan-fold German Legal (8.5 x 13 in)</source>
        <translation>Paper continu alemany legal (8,5 x 13 in)</translation>
    </message>
    <message>
        <source>Envelope B4</source>
        <translation>Sobre B4</translation>
    </message>
    <message>
        <source>Envelope B5</source>
        <translation>Sobre B5</translation>
    </message>
    <message>
        <source>Envelope B6</source>
        <translation>Sobre B6</translation>
    </message>
    <message>
        <source>Envelope C0</source>
        <translation>Sobre C0</translation>
    </message>
    <message>
        <source>Envelope C1</source>
        <translation>Sobre C1</translation>
    </message>
    <message>
        <source>Envelope C2</source>
        <translation>Sobre C2</translation>
    </message>
    <message>
        <source>Envelope C3</source>
        <translation>Sobre C3</translation>
    </message>
    <message>
        <source>Envelope C4</source>
        <translation>Sobre C4</translation>
    </message>
    <message>
        <source>Envelope C5</source>
        <translation>Sobre C5</translation>
    </message>
    <message>
        <source>Envelope C6</source>
        <translation>Sobre C6</translation>
    </message>
    <message>
        <source>Envelope C65</source>
        <translation>Sobre C65</translation>
    </message>
    <message>
        <source>Envelope C7</source>
        <translation>Sobre C7</translation>
    </message>
    <message>
        <source>Envelope DL</source>
        <translation>Sobre DL</translation>
    </message>
    <message>
        <source>Envelope US 9</source>
        <translation>Sobre US 9</translation>
    </message>
    <message>
        <source>Envelope US 10</source>
        <translation>Sobre US 10</translation>
    </message>
    <message>
        <source>Envelope US 11</source>
        <translation>Sobre US 11</translation>
    </message>
    <message>
        <source>Envelope US 12</source>
        <translation>Sobre US 12</translation>
    </message>
    <message>
        <source>Envelope US 14</source>
        <translation>Sobre US 14</translation>
    </message>
    <message>
        <source>Envelope Monarch</source>
        <translation>Sobre monarca</translation>
    </message>
    <message>
        <source>Envelope Personal</source>
        <translation>Sobre personal</translation>
    </message>
    <message>
        <source>Envelope Chou 3</source>
        <translation>Sobre Chou 3</translation>
    </message>
    <message>
        <source>Envelope Chou 4</source>
        <translation>Sobre Chou 4</translation>
    </message>
    <message>
        <source>Envelope Invite</source>
        <translation>Sobre invitació</translation>
    </message>
    <message>
        <source>Envelope Italian</source>
        <translation>Sobre italià</translation>
    </message>
    <message>
        <source>Envelope Kaku 2</source>
        <translation>Sobre Kaku 2</translation>
    </message>
    <message>
        <source>Envelope Kaku 3</source>
        <translation>Sobre Kaku 3</translation>
    </message>
    <message>
        <source>Envelope PRC 1</source>
        <translation>Sobre PRC 1</translation>
    </message>
    <message>
        <source>Envelope PRC 2</source>
        <translation>Sobre PRC 2</translation>
    </message>
    <message>
        <source>Envelope PRC 3</source>
        <translation>Sobre PRC 3</translation>
    </message>
    <message>
        <source>Envelope PRC 4</source>
        <translation>Sobre PRC 4</translation>
    </message>
    <message>
        <source>Envelope PRC 5</source>
        <translation>Sobre PRC 5</translation>
    </message>
    <message>
        <source>Envelope PRC 6</source>
        <translation>Sobre PRC 6</translation>
    </message>
    <message>
        <source>Envelope PRC 7</source>
        <translation>Sobre PRC 7</translation>
    </message>
    <message>
        <source>Envelope PRC 8</source>
        <translation>Sobre PRC 8</translation>
    </message>
    <message>
        <source>Envelope PRC 9</source>
        <translation>Sobre PRC 9</translation>
    </message>
    <message>
        <source>Envelope PRC 10</source>
        <translation>Sobre PRC 10</translation>
    </message>
    <message>
        <source>Envelope You 4</source>
        <translation>Sobre You 4</translation>
    </message>
</context>
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Desa-ho tot</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Sí &amp;a tot</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;o a tot</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Interromp</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Reintenta</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignora</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descarta</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aplica</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reinicia</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Restaura les opcions per defecte</translation>
    </message>
</context>
<context>
    <name>QPluginLoader</name>
    <message>
        <source>The plugin was not loaded.</source>
        <translation>El connector no s&apos;ha carregat.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
</context>
<context>
    <name>QPrintDialog</name>
    <message>
        <source>Print</source>
        <translation>Imprimeix</translation>
    </message>
    <message>
        <source>Left to Right, Top to Bottom</source>
        <translation>D&apos;esquerra a dreta, de dalt a baix</translation>
    </message>
    <message>
        <source>Left to Right, Bottom to Top</source>
        <translation>D&apos;esquerra a dreta, de baix a dalt</translation>
    </message>
    <message>
        <source>Right to Left, Bottom to Top</source>
        <translation>De dreta a esquerra, de baix a dalt</translation>
    </message>
    <message>
        <source>Right to Left, Top to Bottom</source>
        <translation>De dreta a esquerra, de dalt a baix</translation>
    </message>
    <message>
        <source>Bottom to Top, Left to Right</source>
        <translation>De baix a dalt, d&apos;esquerra a dreta</translation>
    </message>
    <message>
        <source>Bottom to Top, Right to Left</source>
        <translation>De baix a dalt, de dreta a esquerra</translation>
    </message>
    <message>
        <source>Top to Bottom, Left to Right</source>
        <translation>De dalt a baix, d&apos;esquerra a dreta</translation>
    </message>
    <message>
        <source>Top to Bottom, Right to Left</source>
        <translation>De dalt a baix, de dreta a esquerra</translation>
    </message>
    <message>
        <source>1 (1x1)</source>
        <translation>1 (1x1)</translation>
    </message>
    <message>
        <source>2 (2x1)</source>
        <translation>2 (2x1)</translation>
    </message>
    <message>
        <source>4 (2x2)</source>
        <translation>4 (2x2)</translation>
    </message>
    <message>
        <source>6 (2x3)</source>
        <translation>6 (2x3)</translation>
    </message>
    <message>
        <source>9 (3x3)</source>
        <translation>9 (3x3)</translation>
    </message>
    <message>
        <source>16 (4x4)</source>
        <translation>16 (4x4)</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Totes les pàgines</translation>
    </message>
    <message>
        <source>Odd Pages</source>
        <translation>Pàgines senars</translation>
    </message>
    <message>
        <source>Even Pages</source>
        <translation>Pàgines parells</translation>
    </message>
    <message>
        <source>&amp;Options &gt;&gt;</source>
        <translation>&amp;Opcions &gt;&gt;</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>Im&amp;primeix</translation>
    </message>
    <message>
        <source>&amp;Options &lt;&lt;</source>
        <translation>&amp;Opcions &lt;&lt;</translation>
    </message>
    <message>
        <source>Invalid Pages Definition</source>
        <translation>Definició no vàlida de les pàgines</translation>
    </message>
    <message>
        <source>%1 does not follow the correct syntax. Please use &apos;,&apos; to separate ranges and pages, &apos;-&apos; to define ranges and make sure ranges do not intersect with each other.</source>
        <translation>%1 no segueix la sintaxi correcta. Useu «,» per a separar intervals i pàgines, «-» per a definir intervals, i assegureu-vos que els intervals no se sobreposen entre ells.</translation>
    </message>
    <message>
        <source>Duplex Settings Conflicts</source>
        <translation>Conflictes a la configuració d&apos;impressió a doble cara</translation>
    </message>
    <message>
        <source>There are conflicts in duplex settings. Do you want to fix them?</source>
        <translation>Hi ha conflictes a la configuració d&apos;impressió a doble cara. Els voleu corregir?</translation>
    </message>
    <message>
        <source>Print to File (PDF)</source>
        <translation>Imprimeix a un fitxer (PDF)</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Fitxer local</translation>
    </message>
    <message>
        <source>Write PDF file</source>
        <translation>Escriu a un fitxer PDF</translation>
    </message>
    <message>
        <source>Print To File ...</source>
        <translation>Imprimeix a un fitxer...</translation>
    </message>
    <message>
        <source>%1 is a directory.
Please choose a different file name.</source>
        <translation>%1 és un directori.
Si us plau, seleccioneu un nom de fitxer diferent.</translation>
    </message>
    <message>
        <source>File %1 is not writable.
Please choose a different file name.</source>
        <translation>No es pot escriure al fitxer %1.
Si us plau, seleccioneu un nom de fitxer diferent.</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to overwrite it?</source>
        <translation>%1 ja existeix.
Voleu sobreescriure&apos;l?</translation>
    </message>
    <message>
        <source>Options &apos;Pages Per Sheet&apos; and &apos;Page Set&apos; cannot be used together.
Please turn one of those options off.</source>
        <translation>Les opcions «Pàgines per full» i «Disposició de la pàgina» no es poden usar conjuntament.
Desactiveu una de les dues opcions.</translation>
    </message>
    <message>
        <source>The &apos;From&apos; value cannot be greater than the &apos;To&apos; value.</source>
        <translation>El valor «Des de» no pot ser més gran que el valor «A».</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">D&apos;acord</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation type="vanished">Automàtic</translation>
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
        <source>Page Setup</source>
        <translation>Configuració de pàgina</translation>
    </message>
    <message>
        <source>%1%</source>
        <extracomment>Zoom factor percentage value, % is the percent sign</extracomment>
        <translation>%1%</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Vista prèvia d&apos;impressió</translation>
    </message>
    <message>
        <source>Next page</source>
        <translation>Pàgina següent</translation>
    </message>
    <message>
        <source>Previous page</source>
        <translation>Pàgina anterior</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>Primera pàgina</translation>
    </message>
    <message>
        <source>Last page</source>
        <translation>Última pàgina</translation>
    </message>
    <message>
        <source>Fit width</source>
        <translation>Ajusta a l&apos;amplada</translation>
    </message>
    <message>
        <source>Fit page</source>
        <translation>Ajusta a la pàgina</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation>Amplia</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation>Redueix</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Apaïsat</translation>
    </message>
    <message>
        <source>Show single page</source>
        <translation>Mostra només una pàgina</translation>
    </message>
    <message>
        <source>Show facing pages</source>
        <translation>Mostra pàgines oposades</translation>
    </message>
    <message>
        <source>Show overview of all pages</source>
        <translation>Mostra un resum de totes les pàgines</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimeix</translation>
    </message>
    <message>
        <source>Page setup</source>
        <translation>Configuració de pàgina</translation>
    </message>
    <message>
        <source>Export to PDF</source>
        <translation>Exporta a PDF</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesDialog</name>
    <message>
        <source>Printer Properties</source>
        <translation>Propietats de la impressora</translation>
    </message>
    <message>
        <source>Job Options</source>
        <translation>Opcions del treball</translation>
    </message>
    <message>
        <source>Page Setup Conflicts</source>
        <translation>Conflictes de configuració de pàgina</translation>
    </message>
    <message>
        <source>There are conflicts in page setup options. Do you want to fix them?</source>
        <translation>Hi ha conflictes a les opcions de configuració de pàgina. Els voleu solucionar?</translation>
    </message>
    <message>
        <source>Advanced Option Conflicts</source>
        <translation>Conflictes d&apos;opcions avançades</translation>
    </message>
    <message>
        <source>There are conflicts in some advanced options. Do you want to fix them?</source>
        <translation>Hi ha conflictes a les opcions avançades. Els voleu solucionar?</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulari</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Pàgina</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avançat</translation>
    </message>
    <message>
        <source>There are conflicts in some options. Please fix them.</source>
        <translation>Hi ha conflictes a diverses opcions. Si us plau, solucioneu-los.</translation>
    </message>
</context>
<context>
    <name>QPrintSettingsOutput</name>
    <message>
        <source>Form</source>
        <translation>Formulari</translation>
    </message>
    <message>
        <source>Copies</source>
        <translation>Còpies</translation>
    </message>
    <message>
        <source>Print range</source>
        <translation>Imprimeix interval</translation>
    </message>
    <message>
        <source>Print all</source>
        <translation>Imprimeix tot</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Pàgines des de</translation>
    </message>
    <message>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Pàgina actual</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Selecció</translation>
    </message>
    <message>
        <source>Page Set:</source>
        <translation type="vanished">Disposició de la pàgina:</translation>
    </message>
    <message>
        <source>Output Settings</source>
        <translation>Configuració de la sortida</translation>
    </message>
    <message>
        <source>Copies:</source>
        <translation>Còpies:</translation>
    </message>
    <message>
        <source>Collate</source>
        <translation>Encadena</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation>Inverteix</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opcions</translation>
    </message>
    <message>
        <source>Color Mode</source>
        <translation>Mode de color</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <source>Grayscale</source>
        <translation>Escala de grisos</translation>
    </message>
    <message>
        <source>Duplex Printing</source>
        <translation type="vanished">Impressió doble</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">Cap</translation>
    </message>
    <message>
        <source>Long side</source>
        <translation type="vanished">Vora llarga</translation>
    </message>
    <message>
        <source>Short side</source>
        <translation type="vanished">Vora curta</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Pàgines</translation>
    </message>
    <message>
        <source>Specify pages or ranges separated by commas. Ranges are specified by two numbers separated by a hyphen. E.g: 3,5-7,9 prints pages 3, 5, 6, 7 and 9.</source>
        <translation>Especifiqueu les pàgines o intervals separats per comes. Els intervals s&apos;especifiquen amb dos nombres separats per un guió. P. ex: 3,5-7,9 imprimeix les pàgines 3, 5, 6, 7 i 9.</translation>
    </message>
    <message>
        <source>Double Sided Printing</source>
        <translation>Impressió a doble cara</translation>
    </message>
    <message>
        <source>Off</source>
        <translation>Inactiva</translation>
    </message>
    <message>
        <source>Long side binding</source>
        <translation>Enquadernació per la vora llarga</translation>
    </message>
    <message>
        <source>Short side binding</source>
        <translation>Enquadernació per la vora curta</translation>
    </message>
    <message>
        <source>Page &amp;Set:</source>
        <translation>Di&amp;sposició de la pàgina:</translation>
    </message>
</context>
<context>
    <name>QPrintWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulari</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Impressora</translation>
    </message>
    <message>
        <source>&amp;Name:</source>
        <translation>&amp;Nom:</translation>
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation>P&amp;ropietats</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Ubicació:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista prèvia</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipus:</translation>
    </message>
    <message>
        <source>Output &amp;file:</source>
        <translation>&amp;Fitxer de sortida:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>QProcess</name>
    <message>
        <source>Process failed to start</source>
        <translation>El procés ha fallat en iniciar</translation>
    </message>
    <message>
        <source>Error reading from process</source>
        <translation>Error en llegir des del procés</translation>
    </message>
    <message>
        <source>Error writing to process</source>
        <translation>Error en escriure al procés</translation>
    </message>
    <message>
        <source>Process crashed</source>
        <translation>El procés ha fallat</translation>
    </message>
    <message>
        <source>Process failed to start (spawned process exited with code 127)</source>
        <translation type="vanished">El procés ha fallat en iniciar (el procés engendrat ha sortit amb el codi 127)</translation>
    </message>
    <message>
        <source>No program defined</source>
        <translation>No s&apos;ha definit cap programa</translation>
    </message>
    <message>
        <source>Could not open input redirection for reading</source>
        <translation>No s&apos;ha pogut obrir la redirecció d&apos;entrada per lectura</translation>
    </message>
    <message>
        <source>Child process modifier threw an exception: %1</source>
        <translation>El modificador del procés fill ha generat una excepció: %1</translation>
    </message>
    <message>
        <source>Child process modifier reported error: %1</source>
        <translation>El modificador del procés fill ha informat un error: %1</translation>
    </message>
    <message>
        <source>Child process modifier reported error: %1: %2</source>
        <translation>El modificador del procés fill ha informat un error: %1: %2</translation>
    </message>
    <message>
        <source>Child process set up failed: %1: %2</source>
        <translation>Ha fallat la configuració del procés fill: %1: %2</translation>
    </message>
    <message>
        <source>Could not open output redirection for writing</source>
        <translation>No s&apos;ha pogut obrir la redirecció d&apos;entrada per escriptura</translation>
    </message>
    <message>
        <source>Resource error (fork failure): %1</source>
        <translation>Error de recurs (ha fallat la bifurcació): %1</translation>
    </message>
    <message>
        <source>Process operation timed out</source>
        <translation>L&apos;operació del procés ha excedit el temps</translation>
    </message>
    <message>
        <source>Process failed to start: %1</source>
        <translation>El procés ha fallat en iniciar: %1</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
</context>
<context>
    <name>QQnxFileDialogHelper</name>
    <message>
        <source>All files (*.*)</source>
        <translation type="vanished">Tots els fitxers (*.*)</translation>
    </message>
    <message>
        <source>CANCEL</source>
        <translation type="vanished">Cancel·la</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">D&apos;acord</translation>
    </message>
</context>
<context>
    <name>QQnxFilePicker</name>
    <message>
        <source>Pick a file</source>
        <translation type="vanished">Tria un fitxer</translation>
    </message>
</context>
<context>
    <name>QRegExp</name>
    <message>
        <source>no error occurred</source>
        <translation type="vanished">sense errors</translation>
    </message>
    <message>
        <source>disabled feature used</source>
        <translation type="vanished">s&apos;ha usat una funcionalitat desactivada</translation>
    </message>
    <message>
        <source>bad char class syntax</source>
        <translation type="vanished">caràcter incorrecte de sintaxi de classe</translation>
    </message>
    <message>
        <source>bad lookahead syntax</source>
        <translation type="vanished">sintaxi incorrecta de preplanificació</translation>
    </message>
    <message>
        <source>lookbehinds not supported, see QTBUG-2371</source>
        <translation type="vanished">«lookbehinds» no està implementat, veieu QTBUG-2371</translation>
    </message>
    <message>
        <source>bad repetition syntax</source>
        <translation type="vanished">sintaxi de repetició incorrecta</translation>
    </message>
    <message>
        <source>invalid octal value</source>
        <translation type="vanished">valor octal no vàlid</translation>
    </message>
    <message>
        <source>missing left delim</source>
        <translation type="vanished">manca el delimitador esquerre</translation>
    </message>
    <message>
        <source>unexpected end</source>
        <translation type="vanished">final inesperat</translation>
    </message>
    <message>
        <source>met internal limit</source>
        <translation type="vanished">s&apos;ha trobat un límit intern</translation>
    </message>
    <message>
        <source>invalid interval</source>
        <translation type="vanished">interval no vàlid</translation>
    </message>
    <message>
        <source>invalid category</source>
        <translation type="vanished">categoria no vàlida</translation>
    </message>
</context>
<context>
    <name>QRegularExpression</name>
    <message>
        <source>no error</source>
        <translation>sense error</translation>
    </message>
    <message>
        <source>\ at end of pattern</source>
        <translation>\ al final de patró</translation>
    </message>
    <message>
        <source>\c at end of pattern</source>
        <translation>\c al final de patró</translation>
    </message>
    <message>
        <source>unrecognized character follows \</source>
        <translation>caràcter no reconegut després de \</translation>
    </message>
    <message>
        <source>numbers out of order in {} quantifier</source>
        <translation>nombres fora de l&apos;interval al quantificador {}</translation>
    </message>
    <message>
        <source>number too big in {} quantifier</source>
        <translation>nombre massa gran al quantificador {}</translation>
    </message>
    <message>
        <source>missing terminating ] for character class</source>
        <translation>manca la terminació ] a la classe caràcter</translation>
    </message>
    <message>
        <source>invalid escape sequence in character class</source>
        <translation type="vanished">seqüència d&apos;escapada no vàlida en la classe caràcter</translation>
    </message>
    <message>
        <source>range out of order in character class</source>
        <translation>fora d&apos;interval a la classe caràcter</translation>
    </message>
    <message>
        <source>nothing to repeat</source>
        <translation type="vanished">res a repetir</translation>
    </message>
    <message>
        <source>internal error: unexpected repeat</source>
        <translation>error intern: repetició inesperada</translation>
    </message>
    <message>
        <source>unrecognized character after (? or (?-</source>
        <translation>caràcter no reconegut després de (? o (?-</translation>
    </message>
    <message>
        <source>POSIX named classes are supported only within a class</source>
        <translation>només es permeten les classes amb nom POSIX dins una classe</translation>
    </message>
    <message>
        <source>missing )</source>
        <translation type="vanished">manca )</translation>
    </message>
    <message>
        <source>reference to non-existent subpattern</source>
        <translation>referència a un subpatró inexistent</translation>
    </message>
    <message>
        <source>erroffset passed as NULL</source>
        <translation type="vanished">«erroffset» passat com a NULL</translation>
    </message>
    <message>
        <source>unknown option bit(s) set</source>
        <translation type="vanished">opció desconeguda «bit(s) set»</translation>
    </message>
    <message>
        <source>missing ) after comment</source>
        <translation type="vanished">manca ) després d&apos;un comentari</translation>
    </message>
    <message>
        <source>regular expression is too large</source>
        <translation>l&apos;expressió regular és massa gran</translation>
    </message>
    <message>
        <source>failed to get memory</source>
        <translation type="vanished">ha fallat en demanar memòria</translation>
    </message>
    <message>
        <source>unmatched parentheses</source>
        <translation type="vanished">parèntesi sense parella</translation>
    </message>
    <message>
        <source>internal error: code overflow</source>
        <translation>error intern: desbordament de codi</translation>
    </message>
    <message>
        <source>unrecognized character after (?&lt;</source>
        <translation type="vanished">caràcter no reconegut després de (?&lt;</translation>
    </message>
    <message>
        <source>lookbehind assertion is not fixed length</source>
        <translation>l&apos;asserció «lookbehind» no té longitud fixa</translation>
    </message>
    <message>
        <source>malformed number or name after (?(</source>
        <translation type="vanished">nombre o nom amb format incorrecte després de (?(</translation>
    </message>
    <message>
        <source>conditional group contains more than two branches</source>
        <translation type="vanished">un grup condicional conté més de dues branques</translation>
    </message>
    <message>
        <source>assertion expected after (?(</source>
        <translation type="vanished">asserció esperada després de (?(</translation>
    </message>
    <message>
        <source>(?R or (?[+-]digits must be followed by )</source>
        <translation type="vanished">(?R o (?[+-]digits ha d&apos;anar seguit per )</translation>
    </message>
    <message>
        <source>unknown POSIX class name</source>
        <translation>nom desconegut de classe POSIX</translation>
    </message>
    <message>
        <source>POSIX collating elements are not supported</source>
        <translation>no es poden utilitzar els elements d&apos;ordenació POSIX</translation>
    </message>
    <message>
        <source>this version of PCRE is not compiled with PCRE_UTF8 support</source>
        <translation type="vanished">aquesta versió del PCRE no està compilada amb compatibilitat PCRE_UTF8</translation>
    </message>
    <message>
        <source>character value in \x{...} sequence is too large</source>
        <translation type="vanished">el valor del caràcter en la seqüència \x{...} és massa gran</translation>
    </message>
    <message>
        <source>invalid condition (?(0)</source>
        <translation type="vanished">condició no vàlida (?(0)</translation>
    </message>
    <message>
        <source>\C not allowed in lookbehind assertion</source>
        <translation type="vanished">\C no permès en l&apos;asserció «lookbehind»</translation>
    </message>
    <message>
        <source>PCRE does not support \L, \l, \N{name}, \U, or \u</source>
        <translation type="vanished">PCRE no accepta \L, \l, \N{nom}, \U, ni \u</translation>
    </message>
    <message>
        <source>number after (?C is &gt; 255</source>
        <translation type="vanished">el nombre després de (?C és &gt; 255</translation>
    </message>
    <message>
        <source>closing ) for (?C expected</source>
        <translation type="vanished">s&apos;esperava un tancament ) per (?C</translation>
    </message>
    <message>
        <source>recursive call could loop indefinitely</source>
        <translation type="vanished">la invocació recursiva pot repetir-se indefinidament</translation>
    </message>
    <message>
        <source>unrecognized character after (?P</source>
        <translation>caràcter no reconegut després de (?P</translation>
    </message>
    <message>
        <source>syntax error in subpattern name (missing terminator)</source>
        <translation type="vanished">error de sintaxi en nom de subpatró (manca terminació)</translation>
    </message>
    <message>
        <source>two named subpatterns have the same name</source>
        <translation type="vanished">dos subpatrons amb nom tenen el mateix nom</translation>
    </message>
    <message>
        <source>invalid UTF-8 string</source>
        <translation type="vanished">cadena UTF-8 no vàlida</translation>
    </message>
    <message>
        <source>support for \P, \p, and \X has not been compiled</source>
        <translation type="vanished">no s&apos;ha compilat amb implementació per \P, \p, ni \X</translation>
    </message>
    <message>
        <source>malformed \P or \p sequence</source>
        <translation>seqüència \P o \p incorrecta</translation>
    </message>
    <message>
        <source>unknown property name after \P or \p</source>
        <translation>nom de propietat desconeguda després de \P o \p</translation>
    </message>
    <message>
        <source>subpattern name is too long (maximum 32 characters)</source>
        <translation type="vanished">el nom de subpatró és massa llarg (màxim 32 caràcters)</translation>
    </message>
    <message>
        <source>too many named subpatterns (maximum 10000)</source>
        <translation>hi ha massa subpatrons amb nom (màxim 10000)</translation>
    </message>
    <message>
        <source>octal value is greater than \377 (not in UTF-8 mode)</source>
        <translation type="vanished">el valor octal és més gran que \377 (no en mode UTF-8)</translation>
    </message>
    <message>
        <source>internal error: overran compiling workspace</source>
        <translation>error intern: desbordament en compilar l&apos;espai de treball</translation>
    </message>
    <message>
        <source>internal error: previously-checked referenced subpattern not found</source>
        <translation>error intern: no s&apos;ha trobat el patró referenciat verificat prèviament</translation>
    </message>
    <message>
        <source>DEFINE group contains more than one branch</source>
        <translation type="vanished">el grup DEFINE conté més d&apos;una branca</translation>
    </message>
    <message>
        <source>repeating a DEFINE group is not allowed</source>
        <translation type="vanished">no es permet repetir un grup DEFINE</translation>
    </message>
    <message>
        <source>inconsistent NEWLINE options</source>
        <translation type="vanished">opcions «NEWLINE» incoherents</translation>
    </message>
    <message>
        <source>\g is not followed by a braced, angle-bracketed, or quoted name/number or by a plain number</source>
        <translation>\g no és seguit per un nom/nombre entre claus, claus angulars o cometes o per un nombre normal</translation>
    </message>
    <message>
        <source>a numbered reference must not be zero</source>
        <translation type="vanished">una referència amb número no pot ser zero</translation>
    </message>
    <message>
        <source>an argument is not allowed for (*ACCEPT), (*FAIL), or (*COMMIT)</source>
        <translation type="vanished">no es permet cap argument per (*ACCEPT), (*FAIL), o (*COMMIT)</translation>
    </message>
    <message>
        <source>(*VERB) not recognized</source>
        <translation type="vanished">(*VERB) no es reconeix</translation>
    </message>
    <message>
        <source>number is too big</source>
        <translation type="vanished">nombre massa gran</translation>
    </message>
    <message>
        <source>subpattern name expected</source>
        <translation>s&apos;esperava un nom de subpatró</translation>
    </message>
    <message>
        <source>digit expected after (?+</source>
        <translation type="vanished">s&apos;esperava un dígit després de (?+</translation>
    </message>
    <message>
        <source>] is an invalid data character in JavaScript compatibility mode</source>
        <translation type="vanished">] és un caràcter no vàlid en el mode de compatibilitat amb JavaScript</translation>
    </message>
    <message>
        <source>different names for subpatterns of the same number are not allowed</source>
        <translation>no es permeten noms diferents per subpatrons del mateix nombre</translation>
    </message>
    <message>
        <source>(*MARK) must have an argument</source>
        <translation>(*MARK) cal que tingui un argument</translation>
    </message>
    <message>
        <source>this version of PCRE is not compiled with PCRE_UCP support</source>
        <translation type="vanished">aquesta versió del PCRE no està compilada amb compatibilitat PCRE_UCP</translation>
    </message>
    <message>
        <source>\c must be followed by an ASCII character</source>
        <translation type="vanished">\c ha d&apos;anar seguit d&apos;un caràcter ASCII</translation>
    </message>
    <message>
        <source>\k is not followed by a braced, angle-bracketed, or quoted name</source>
        <translation>\k no és seguit per un nom entre claus, claus angulars o cometes</translation>
    </message>
    <message>
        <source>internal error: unknown opcode in find_fixedlength()</source>
        <translation type="vanished">error intern: «opcode» desconegut en «find_fixedlength()»</translation>
    </message>
    <message>
        <source>\N is not supported in a class</source>
        <translation>\N no està implementat en cap classe</translation>
    </message>
    <message>
        <source>too many forward references</source>
        <translation type="vanished">hi ha massa referències cap endavant</translation>
    </message>
    <message>
        <source>disallowed Unicode code point (&gt;= 0xd800 &amp;&amp; &lt;= 0xdfff)</source>
        <translation>punt de codi Unicode no permès (&gt;= 0xd800 &amp;&amp; &lt;= 0xdfff)</translation>
    </message>
    <message>
        <source>invalid UTF-16 string</source>
        <translation type="vanished">cadena UTF-16 no vàlida</translation>
    </message>
    <message>
        <source>name is too long in (*MARK), (*PRUNE), (*SKIP), or (*THEN)</source>
        <translation>el nom és massa llarg en (*MARK), (*PRUNE), (*SKIP), o (*THEN)</translation>
    </message>
    <message>
        <source>character value in \u.... sequence is too large</source>
        <translation type="vanished">el valor del caràcter en la seqüència \u.... és massa gran</translation>
    </message>
    <message>
        <source>invalid UTF-32 string</source>
        <translation type="vanished">cadena UTF-32 no vàlida</translation>
    </message>
    <message>
        <source>setting UTF is disabled by the application</source>
        <translation type="vanished">L&apos;aplicació ha desactivat la definició de l&apos;UTF</translation>
    </message>
    <message>
        <source>non-hex character in \x{} (closing brace missing?)</source>
        <translation>caràcter no hexadecimal en \x{} (manca la clau de tancament?)</translation>
    </message>
    <message>
        <source>non-octal character in \o{} (closing brace missing?)</source>
        <translation>caràcter no octal en \o{} (manca la clau de tancament?)</translation>
    </message>
    <message>
        <source>escape sequence is invalid in character class</source>
        <translation>la seqüència d&apos;escapada no és vàlida a la classe caràcter</translation>
    </message>
    <message>
        <source>missing closing parenthesis for condition</source>
        <translation>manca el parèntesi de tancament a la condició</translation>
    </message>
    <message>
        <source>a relative value of zero is not allowed</source>
        <translation>no es permet un valor relatiu de zero</translation>
    </message>
    <message>
        <source>conditional subpattern contains more than two branches</source>
        <translation>el subpatró condicional conté més de dues branques</translation>
    </message>
    <message>
        <source>digit expected after (?+ or (?-</source>
        <translation>s&apos;esperava un dígit després de (?+ o (?-</translation>
    </message>
    <message>
        <source>lookbehind is too complicated</source>
        <translation>el «lookbehind» és massa complicat</translation>
    </message>
    <message>
        <source>\C is not allowed in a lookbehind assertion in UTF-16 mode</source>
        <translation>no es permet \C en una asserció «lookbehind» en mode UTF-16</translation>
    </message>
    <message>
        <source>PCRE2 does not support \F, \L, \l, \N{name}, \U, or \u</source>
        <translation>PCRE2 no admet \F, \L, \l, \N{nom}, \U, or \u</translation>
    </message>
    <message>
        <source>syntax error in subpattern name (missing terminator?)</source>
        <translation>error de sintaxi al nom de subpatró (manca un terminador?)</translation>
    </message>
    <message>
        <source>subpattern name must start with a non-digit</source>
        <translation>el nom del subpatró ha de començar per un no dígit</translation>
    </message>
    <message>
        <source>subpattern name is too long (maximum 32 code units)</source>
        <translation>el nom de subpatró és massa llarg (màxim 32 unitats de codi)</translation>
    </message>
    <message>
        <source>DEFINE subpattern contains more than one branch</source>
        <translation>el subpatró DEFINE conté més d&apos;una branca</translation>
    </message>
    <message>
        <source>missing opening brace after \o</source>
        <translation>manca una clau d&apos;obertura després de \o</translation>
    </message>
    <message>
        <source>parentheses are too deeply nested</source>
        <translation>els parèntesis s&apos;han imbricat amb massa profunditat</translation>
    </message>
    <message>
        <source>invalid range in character class</source>
        <translation>interval no vàlid a la classe caràcter</translation>
    </message>
    <message>
        <source>group name must start with a non-digit</source>
        <translation type="vanished">el nom del grup ha de començar sense un dígit</translation>
    </message>
    <message>
        <source>quantifier does not follow a repeatable item</source>
        <translation>el quantificador no segueix cap element repetible</translation>
    </message>
    <message>
        <source>missing closing parenthesis</source>
        <translation>manca el parèntesi de tancament</translation>
    </message>
    <message>
        <source>pattern passed as NULL</source>
        <translation>patró passat com a NULL</translation>
    </message>
    <message>
        <source>unrecognised compile-time option bit(s)</source>
        <translation>bit/s no reconegut/s d&apos;opció en temps de compilació</translation>
    </message>
    <message>
        <source>missing ) after (?# comment</source>
        <translation>manca ) després d&apos;un comentari (?#</translation>
    </message>
    <message>
        <source>failed to allocate heap memory</source>
        <translation>ha fallat en assignar la memòria en monticles</translation>
    </message>
    <message>
        <source>unmatched closing parenthesis</source>
        <translation>parèntesi de tancament sense parella</translation>
    </message>
    <message>
        <source>letter or underscore expected after (?&lt; or (?&apos;</source>
        <translation type="vanished">s&apos;espera una lletra o un subratllat després de (?&lt; o (?&apos;</translation>
    </message>
    <message>
        <source>assertion expected after (?( or (?(?C)</source>
        <translation>s&apos;espera una declaració després de (?( o (?(?C)</translation>
    </message>
    <message>
        <source>internal error in pcre2_study(): should not occur</source>
        <translation>error intern a pcre2_study(): no hauria d&apos;ocórrer</translation>
    </message>
    <message>
        <source>this version of PCRE2 does not have Unicode support</source>
        <translation>aquesta versió del PCRE2 no implementa l&apos;Unicode</translation>
    </message>
    <message>
        <source>parentheses are too deeply nested (stack check)</source>
        <translation>els parèntesis s&apos;han imbricat amb massa profunditat (verificació de pila)</translation>
    </message>
    <message>
        <source>character code point value in \x{} or \o{} is too large</source>
        <translation>el valor del codi de caràcter de coma en \x{} o \o{} és massa gran</translation>
    </message>
    <message>
        <source>\C is not allowed in a lookbehind assertion</source>
        <translation type="vanished">\C no es permet en una asserció «lookbehind»</translation>
    </message>
    <message>
        <source>number after (?C is greater than 255</source>
        <translation>el nombre després de (?C és més gran que 255</translation>
    </message>
    <message>
        <source>closing parenthesis for (?C expected</source>
        <translation>s&apos;esperava un tancament ) per (?C</translation>
    </message>
    <message>
        <source>invalid escape sequence in (*VERB) name</source>
        <translation>seqüència d&apos;escapada no vàlida en un nom (*VERB)</translation>
    </message>
    <message>
        <source>two named subpatterns have the same name (PCRE2_DUPNAMES not set)</source>
        <translation>dos subpatrons amb nom tenen el mateix nom (no s&apos;ha definit PCRE2_DUPNAMES)</translation>
    </message>
    <message>
        <source>this version of PCRE2 does not have support for \P, \p, or \X</source>
        <translation>aquesta versió del PCRE2 no té la implementació per \P, \p, ni \X</translation>
    </message>
    <message>
        <source>subpattern name is too long (maximum 10000 characters)</source>
        <translation type="vanished">el nom de subpatró és massa llarg (màxim 10000 caràcters)</translation>
    </message>
    <message>
        <source>too many named subpatterns (maximum 256)</source>
        <translation type="vanished">hi ha massa subpatrons amb nom (màxim 256)</translation>
    </message>
    <message>
        <source>octal value is greater than \377 in 8-bit non-UTF-8 mode</source>
        <translation>el valor octal és més gran que \377 en 8 bits en mode no UTF-8</translation>
    </message>
    <message>
        <source>internal error: unknown newline setting</source>
        <translation>error intern: paràmetre desconegut de línia nova</translation>
    </message>
    <message>
        <source>(?R (recursive pattern call) must be followed by a closing parenthesis</source>
        <translation>(?R (crida recursiva de patró) cal que estigui seguida per un parèntesi de tancament</translation>
    </message>
    <message>
        <source>obsolete error (should not occur)</source>
        <translation>error obsolet (no hauria d&apos;ocórrer)</translation>
    </message>
    <message>
        <source>(*VERB) not recognized or malformed</source>
        <translation>(*VERB) no es reconeix o amb format incorrecte</translation>
    </message>
    <message>
        <source>subpattern number is too big</source>
        <translation>el nombre de subpatrons és massa gran</translation>
    </message>
    <message>
        <source>internal error: parsed pattern overflow</source>
        <translation>error intern: desbordament de patró analitzat</translation>
    </message>
    <message>
        <source>\c must be followed by a printable ASCII character</source>
        <translation>\c ha d&apos;anar seguit d&apos;un caràcter ASCII imprimible</translation>
    </message>
    <message>
        <source>\c must be followed by a letter or one of [\]^_?</source>
        <translation>\c ha d&apos;anar seguit d&apos;una lletra o un [\]^_?</translation>
    </message>
    <message>
        <source>SPARE ERROR</source>
        <translation type="vanished">ERROR DE RESERVA</translation>
    </message>
    <message>
        <source>using UTF is disabled by the application</source>
        <translation>l&apos;aplicació ha desactivat l&apos;ús de l&apos;UTF</translation>
    </message>
    <message>
        <source>using UCP is disabled by the application</source>
        <translation>l&apos;aplicació ha desactivat l&apos;ús de l&apos;UCP</translation>
    </message>
    <message>
        <source>character code point value in \u.... sequence is too large</source>
        <translation>el valor del codi de caràcter de coma a una seqüència en \u.... és massa gran</translation>
    </message>
    <message>
        <source>digits missing in \x{} or \o{}</source>
        <translation type="vanished">manquen els dígits a\x{} o \o{}</translation>
    </message>
    <message>
        <source>syntax error in (?(VERSION condition</source>
        <translation type="vanished">error de sintaxi a la condició (?(VERSION</translation>
    </message>
    <message>
        <source>internal error: unknown meta code in check_lookbehinds()</source>
        <translation>error intern: codi «meta» desconegut a «check_lookbehinds()»</translation>
    </message>
    <message>
        <source>callout string is too long</source>
        <translation>la cadena de crida és massa gran</translation>
    </message>
    <message>
        <source>digits missing in \x{} or \o{} or \N{U+}</source>
        <translation>manquen dígits a \x{} o \o{} o \N{U+}</translation>
    </message>
    <message>
        <source>syntax error or number too big in (?(VERSION condition</source>
        <translation>error de sintaxi o un nombre massa gran a la condició (?(VERSION</translation>
    </message>
    <message>
        <source>internal error: unknown opcode in auto_possessify()</source>
        <translation>error intern: «opcode» desconegut a «auto_possessify()»</translation>
    </message>
    <message>
        <source>missing terminating delimiter for callout with string argument</source>
        <translation>manca el delimitador de terminació de crida amb un argument de cadena</translation>
    </message>
    <message>
        <source>unrecognized string delimiter follows (?C</source>
        <translation>delimitador de cadena no reconegut segueix (?C</translation>
    </message>
    <message>
        <source>using \C is disabled by the application</source>
        <translation>l&apos;aplicació ha desactivat l&apos;ús de \C</translation>
    </message>
    <message>
        <source>(?| and/or (?J: or (?x: parentheses are too deeply nested</source>
        <translation>(?| i/o (?J: o (?x: els parèntesis s&apos;han imbricat amb massa profunditat</translation>
    </message>
    <message>
        <source>using \C is disabled in this PCRE2 library</source>
        <translation>aquesta biblioteca PCRE2 ha desactivat l&apos;ús de \C</translation>
    </message>
    <message>
        <source>regular expression is too complicated</source>
        <translation>l&apos;expressió regular és massa complicada</translation>
    </message>
    <message>
        <source>lookbehind assertion is too long</source>
        <translation>l&apos;asserció «lookbehind» és massa llarga</translation>
    </message>
    <message>
        <source>pattern string is longer than the limit set by the application</source>
        <translation>la cadena del patró és més gran que el límit definit per l&apos;aplicació</translation>
    </message>
    <message>
        <source>internal error: unknown code in parsed pattern</source>
        <translation>error intern: codi desconegut a un patró analitzat</translation>
    </message>
    <message>
        <source>internal error: bad code value in parsed_skip()</source>
        <translation>error intern: valor incorrecte de codi a «parsed_skip()»</translation>
    </message>
    <message>
        <source>PCRE2_EXTRA_ALLOW_SURROGATE_ESCAPES is not allowed in UTF-16 mode</source>
        <translation>no es permet PCRE2_EXTRA_ALLOW_SURROGATE_ESCAPES en el mode UTF-16</translation>
    </message>
    <message>
        <source>invalid option bits with PCRE2_LITERAL</source>
        <translation>bits no vàlids d&apos;opció amb PCRE2_LITERAL</translation>
    </message>
    <message>
        <source>\N{U+dddd} is supported only in Unicode (UTF) mode</source>
        <translation>\N{U+dddd} només s&apos;admet en el mode Unicode (UTF)</translation>
    </message>
    <message>
        <source>invalid hyphen in option setting</source>
        <translation>guió no vàlid a la definició d&apos;opció</translation>
    </message>
    <message>
        <source>(*alpha_assertion) not recognized</source>
        <translation>(*alpha_assertion) no es reconeix</translation>
    </message>
    <message>
        <source>script runs require Unicode support, which this version of PCRE2 does not have</source>
        <translation>l&apos;execució de l&apos;script requereix admetre l&apos;Unicode, que aquesta versió del PCRE2 no ho fa</translation>
    </message>
    <message>
        <source>too many capturing groups (maximum 65535)</source>
        <translation>massa grups de captura (màxim 65535)</translation>
    </message>
    <message>
        <source>atomic assertion expected after (?( or (?(?C)</source>
        <translation>s&apos;esperava una asserció atòmica després de (?( o (?(?C)</translation>
    </message>
    <message>
        <source>no match</source>
        <translation>no coincideix</translation>
    </message>
    <message>
        <source>partial match</source>
        <translation>coincidència parcial</translation>
    </message>
    <message>
        <source>UTF-8 error: 1 byte missing at end</source>
        <translation>error d&apos;UTF-8: manca 1 byte al final</translation>
    </message>
    <message>
        <source>UTF-8 error: 2 bytes missing at end</source>
        <translation>error d&apos;UTF-8: manquen 2 bytes al final</translation>
    </message>
    <message>
        <source>UTF-8 error: 3 bytes missing at end</source>
        <translation>error d&apos;UTF-8: manquen 3 bytes al final</translation>
    </message>
    <message>
        <source>UTF-8 error: 4 bytes missing at end</source>
        <translation>error d&apos;UTF-8: manquen 4 bytes al final</translation>
    </message>
    <message>
        <source>UTF-8 error: 5 bytes missing at end</source>
        <translation>error d&apos;UTF-8: manquen 5 bytes al final</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 2 top bits not 0x80</source>
        <translation>error d&apos;UTF-8: els 2 bits superiors del byte no són 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 3 top bits not 0x80</source>
        <translation>error d&apos;UTF-8: els 3 bits superiors del byte no són 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 4 top bits not 0x80</source>
        <translation>error d&apos;UTF-8: els 4 bits superiors del byte no són 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 5 top bits not 0x80</source>
        <translation>error d&apos;UTF-8: els 5 bits superiors del byte no són 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 6 top bits not 0x80</source>
        <translation>error d&apos;UTF-8: els 6 bits superiors del byte no són 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: 5-byte character is not allowed (RFC 3629)</source>
        <translation>error d&apos;UTF-8: no es permeten caràcters de 5 bytes (RFC 3629)</translation>
    </message>
    <message>
        <source>UTF-8 error: 6-byte character is not allowed (RFC 3629)</source>
        <translation>error d&apos;UTF-8: no es permeten caràcters de 6 bytes (RFC 3629)</translation>
    </message>
    <message>
        <source>UTF-8 error: code points greater than 0x10ffff are not defined</source>
        <translation>error d&apos;UTF-8: no s&apos;han definit punts de codi més grans que 0x10ffff</translation>
    </message>
    <message>
        <source>UTF-8 error: code points 0xd800-0xdfff are not defined</source>
        <translation>error d&apos;UTF-8: no s&apos;han definit punts de codi 0xd800-0xdfff</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 2-byte sequence</source>
        <translation>error d&apos;UTF-8: s&apos;excedeix la seqüència de 2 bytes</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 3-byte sequence</source>
        <translation>error d&apos;UTF-8: s&apos;excedeix la seqüència de 3 bytes</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 4-byte sequence</source>
        <translation>error d&apos;UTF-8: s&apos;excedeix la seqüència de 4 bytes</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 5-byte sequence</source>
        <translation>error d&apos;UTF-8: s&apos;excedeix la seqüència de 5 bytes</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 6-byte sequence</source>
        <translation>error d&apos;UTF-8: s&apos;excedeix la seqüència de 6 bytes</translation>
    </message>
    <message>
        <source>UTF-8 error: isolated byte with 0x80 bit set</source>
        <translation>error d&apos;UTF-8: byte aïllat amb el bit 0x80 activat</translation>
    </message>
    <message>
        <source>UTF-8 error: illegal byte (0xfe or 0xff)</source>
        <translation>error d&apos;UTF-8: byte il·legal (0xfe o 0xff)</translation>
    </message>
    <message>
        <source>UTF-16 error: missing low surrogate at end</source>
        <translation>error d&apos;UTF-16: manca un suplent baix al final</translation>
    </message>
    <message>
        <source>UTF-16 error: invalid low surrogate</source>
        <translation>error d&apos;UTF-16: suplent baix no vàlid</translation>
    </message>
    <message>
        <source>UTF-16 error: isolated low surrogate</source>
        <translation>error d&apos;UTF-16: suplent baix aïllat</translation>
    </message>
    <message>
        <source>UTF-32 error: code points 0xd800-0xdfff are not defined</source>
        <translation>error d&apos;UTF-32: no s&apos;han definit punts de codi 0xd800-0xdfff</translation>
    </message>
    <message>
        <source>UTF-32 error: code points greater than 0x10ffff are not defined</source>
        <translation>error d&apos;UTF-32: no s&apos;han definit punts de codi més grans que 0x10ffff</translation>
    </message>
    <message>
        <source>bad data value</source>
        <translation>valor incorrecte de dada</translation>
    </message>
    <message>
        <source>patterns do not all use the same character tables</source>
        <translation>no tots els patrons usen les mateixes taules de caràcters</translation>
    </message>
    <message>
        <source>magic number missing</source>
        <translation>manca el nombre màgic</translation>
    </message>
    <message>
        <source>pattern compiled in wrong mode: 8/16/32-bit error</source>
        <translation>patró compilat en el mode incorrecte: error de 8/16/32 bits</translation>
    </message>
    <message>
        <source>bad offset value</source>
        <translation>valor incorrecte de desplaçament</translation>
    </message>
    <message>
        <source>bad option value</source>
        <translation>valor incorrecte d&apos;opció</translation>
    </message>
    <message>
        <source>invalid replacement string</source>
        <translation>cadena de substitució no vàlida</translation>
    </message>
    <message>
        <source>bad offset into UTF string</source>
        <translation>desplaçament incorrecte dins la cadena UTF</translation>
    </message>
    <message>
        <source>callout error code</source>
        <translation>codi d&apos;error de crida</translation>
    </message>
    <message>
        <source>invalid data in workspace for DFA restart</source>
        <translation>dades no vàlides a l&apos;espai de treball per al reinici DFA</translation>
    </message>
    <message>
        <source>too much recursion for DFA matching</source>
        <translation>hi ha massa recursivitat per a la coincidència DFA</translation>
    </message>
    <message>
        <source>backreference condition or recursion test is not supported for DFA matching</source>
        <translation>la condició de referència cap enrere o la prova de recursivitat no estan admeses a la coincidència DFA</translation>
    </message>
    <message>
        <source>function is not supported for DFA matching</source>
        <translation>la funció no està admesa a la coincidència DFA</translation>
    </message>
    <message>
        <source>pattern contains an item that is not supported for DFA matching</source>
        <translation>el patró conté un element que no està admès a la coincidència DFA</translation>
    </message>
    <message>
        <source>workspace size exceeded in DFA matching</source>
        <translation>la mida de l&apos;espai de treball s&apos;ha excedit a la coincidència DFA</translation>
    </message>
    <message>
        <source>internal error - pattern overwritten?</source>
        <translation>error intern: sobreescriptura del patró?</translation>
    </message>
    <message>
        <source>bad JIT option</source>
        <translation>opció incorrecta del JIT</translation>
    </message>
    <message>
        <source>JIT stack limit reached</source>
        <translation>s&apos;ha arribat al límit de la pila del JIT</translation>
    </message>
    <message>
        <source>match limit exceeded</source>
        <translation>s&apos;ha excedit el límit de coincidències</translation>
    </message>
    <message>
        <source>no more memory</source>
        <translation>no hi ha més memòria</translation>
    </message>
    <message>
        <source>unknown substring</source>
        <translation>subcadena desconeguda</translation>
    </message>
    <message>
        <source>non-unique substring name</source>
        <translation>nom de subcadena no únic</translation>
    </message>
    <message>
        <source>NULL argument passed</source>
        <translation>s&apos;ha passat un argument NULL</translation>
    </message>
    <message>
        <source>nested recursion at the same subject position</source>
        <translation>recursivitat imbricada a la mateixa posició del subjecte</translation>
    </message>
    <message>
        <source>matching depth limit exceeded</source>
        <translation>s&apos;ha excedit el límit de profunditat de coincidències</translation>
    </message>
    <message>
        <source>match with end before start or start moved backwards is not supported</source>
        <translation>no s&apos;admet la coincidència amb el final abans de l&apos;inici o moure l&apos;inici cap enrere</translation>
    </message>
    <message>
        <source>bad serialized data</source>
        <translation>dades serialitzades incorrectes</translation>
    </message>
    <message>
        <source>heap limit exceeded</source>
        <translation>s&apos;ha excedit el límit de la memòria en monticles</translation>
    </message>
    <message>
        <source>invalid syntax</source>
        <translation>sintaxi no vàlida</translation>
    </message>
    <message>
        <source>internal error - duplicate substitution match</source>
        <translation>error intern - coincidència de substitució duplicada</translation>
    </message>
    <message>
        <source>PCRE2_MATCH_INVALID_UTF is not supported for DFA matching</source>
        <translation>no s&apos;admet PCRE2_MATCH_INVALID_UTF per a la coincidència DFA</translation>
    </message>
    <message>
        <source>INTERNAL ERROR: invalid substring offset</source>
        <translation>ERROR INTERN: desplaçament no vàlid de la subcadena</translation>
    </message>
    <message>
        <source>recursion limit exceeded</source>
        <translation type="vanished">s&apos;ha excedit el límit de recursions</translation>
    </message>
    <message>
        <source>requested value is not available</source>
        <translation>el valor sol·licitat no és disponible</translation>
    </message>
    <message>
        <source>requested value is not set</source>
        <translation>el valor sol·licitat no està definit</translation>
    </message>
    <message>
        <source>offset limit set without PCRE2_USE_OFFSET_LIMIT</source>
        <translation>definit el límit del desplaçament sense PCRE2_USE_OFFSET_LIMIT</translation>
    </message>
    <message>
        <source>bad escape sequence in replacement string</source>
        <translation>seqüència d&apos;escapada incorrecta a la cadena de reemplaçament</translation>
    </message>
    <message>
        <source>expected closing curly bracket in replacement string</source>
        <translation>s&apos;esperava una clau de tancament a la cadena de reemplaçament</translation>
    </message>
    <message>
        <source>bad substitution in replacement string</source>
        <translation>substitució incorrecta a la cadena de reemplaçament</translation>
    </message>
    <message>
        <source>match with end before start is not supported</source>
        <translation type="vanished">no s&apos;admet la coincidència amb el final abans de l&apos;inici</translation>
    </message>
    <message>
        <source>too many replacements (more than INT_MAX)</source>
        <translation>hi ha massa reemplaçaments (més que INT_MAX)</translation>
    </message>
</context>
<context>
    <name>QSQLite2Driver</name>
    <message>
        <source>Error opening database</source>
        <translation type="vanished">Error en obrir la base de dades</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation type="vanished">La transacció no ha pogut començar</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation type="vanished">No s&apos;ha pogut confirmar la transacció</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation type="vanished">No s&apos;ha pogut desfer la transacció</translation>
    </message>
</context>
<context>
    <name>QSQLite2Result</name>
    <message>
        <source>Unable to fetch results</source>
        <translation type="vanished">No s&apos;han pogut recuperar resultats</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation type="vanished">No s&apos;ha pogut executar la sentència</translation>
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <source>Error opening database</source>
        <translation>Error en obrir la base de dades</translation>
    </message>
    <message>
        <source>Error closing database</source>
        <translation>Error en tancar la base de dades</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>La transacció no ha pogut començar</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No s&apos;ha pogut confirmar la transacció</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No s&apos;ha pogut desfer la transacció</translation>
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <source>Unable to fetch row</source>
        <translation>No s&apos;ha pogut recuperar la fila</translation>
    </message>
    <message>
        <source>No query</source>
        <translation>Sense consulta</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No s&apos;ha pogut executar la sentència</translation>
    </message>
    <message>
        <source>Unable to execute multiple statements at a time</source>
        <translation>No s&apos;han pogut executar múltiples sentències a la vegada</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>No s&apos;ha pogut reiniciar la sentència</translation>
    </message>
    <message>
        <source>Unable to bind parameters</source>
        <translation>No s&apos;han pogut vincular els paràmetres</translation>
    </message>
    <message>
        <source>Parameter count mismatch</source>
        <translation>El comptador de paràmetres no quadra</translation>
    </message>
</context>
<context>
    <name>QSaveFile</name>
    <message>
        <source>Existing file %1 is not writable</source>
        <translation>No es pot escriure al fitxer existent %1</translation>
    </message>
    <message>
        <source>Filename refers to a directory</source>
        <translation>El nom del fitxer es refereix a un directori</translation>
    </message>
    <message>
        <source>QSaveFile cannot open &apos;%1&apos; without direct write fallback enabled.</source>
        <translation>QSaveFile no pot obrir «%1» sense una reserva d&apos;escriptura directa activada.</translation>
    </message>
    <message>
        <source>QSaveFile cannot open &apos;%1&apos; without direct write fallback enabled: path contains an Alternate Data Stream specifier</source>
        <translation type="vanished">QSaveFile no pot obrir «%1» sense una reserva d&apos;escriptura activada: el camí conté un especificador de flux de dades alternatiu</translation>
    </message>
    <message>
        <source>Writing canceled by application</source>
        <translation>L&apos;aplicació ha cancel·lat l&apos;escriptura</translation>
    </message>
</context>
<context>
    <name>QScrollBar</name>
    <message>
        <source>Scroll here</source>
        <translation>Desplaça aquí</translation>
    </message>
    <message>
        <source>Left edge</source>
        <translation>Vora esquerra</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Part superior</translation>
    </message>
    <message>
        <source>Right edge</source>
        <translation>Vora dreta</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Part inferior</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Pàgina esquerra</translation>
    </message>
    <message>
        <source>Page up</source>
        <translation>Pàgina superior</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Pàgina dreta</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Pàgina inferior</translation>
    </message>
    <message>
        <source>Scroll left</source>
        <translation>Desplaça a l&apos;esquerra</translation>
    </message>
    <message>
        <source>Scroll up</source>
        <translation>Desplaça amunt</translation>
    </message>
    <message>
        <source>Scroll right</source>
        <translation>Desplaça a la dreta</translation>
    </message>
    <message>
        <source>Scroll down</source>
        <translation>Desplaça avall</translation>
    </message>
</context>
<context>
    <name>QSctpSocket</name>
    <message>
        <source>The remote host closed the connection</source>
        <translation>L&apos;ordinador remot ha tancat la connexió</translation>
    </message>
</context>
<context>
    <name>QSharedMemory</name>
    <message>
        <source>%1: unable to set key on lock</source>
        <translation type="vanished">%1: no s&apos;ha pogut establir la clau del bloqueig</translation>
    </message>
    <message>
        <source>%1: unsupported key type</source>
        <translation>%1: tipus de clau no admès</translation>
    </message>
    <message>
        <source>%1: unable to set key on lock (%2)</source>
        <translation>%1: no s&apos;ha pogut establir la clau del bloqueig (%2)</translation>
    </message>
    <message>
        <source>%1: create size is less then 0</source>
        <translation>%1: la mida de creació és inferior a 0</translation>
    </message>
    <message>
        <source>%1: unable to lock</source>
        <translation>%1: no s&apos;ha pogut bloquejar</translation>
    </message>
    <message>
        <source>%1: unable to unlock</source>
        <translation>%1: no s&apos;ha pogut desbloquejar</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: s&apos;ha denegat el permís</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: ja existeix</translation>
    </message>
    <message>
        <source>%1: doesn&apos;t exist</source>
        <translation>%1: no existeix</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: sense recursos</translation>
    </message>
    <message>
        <source>%1: unknown error: %2</source>
        <translation>%1: error desconegut: %2</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation type="vanished">%1: error desconegut %2</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: la clau és buida</translation>
    </message>
    <message>
        <source>%1: bad name</source>
        <translation>%1: nom incorrecte</translation>
    </message>
    <message>
        <source>%1: UNIX key file doesn&apos;t exist</source>
        <translation type="vanished">%1: no existeix el fitxer de claus de l&apos;UNIX</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation type="vanished">%1: ha fallat el «ftok»</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: no s&apos;ha pogut crear la clau</translation>
    </message>
    <message>
        <source>%1: system-imposed size restrictions</source>
        <translation>%1: restriccions de mida imposades pel sistema</translation>
    </message>
    <message>
        <source>%1: not attached</source>
        <translation>%1: no s&apos;ha adjuntat</translation>
    </message>
    <message>
        <source>%1: invalid size</source>
        <translation>%1: mida no vàlida</translation>
    </message>
    <message>
        <source>%1: key error</source>
        <translation>%1: error de clau</translation>
    </message>
    <message>
        <source>%1: size query failed</source>
        <translation>%1: ha fallat la consulta de la mida</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <source>Space</source>
        <extracomment>This and all following &quot;incomprehensible&quot; strings in QShortcut context are key names. Please use the localized names appearing on actual keyboards or whatever is commonly used.</extracomment>
        <translation>Espai</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Tab</source>
        <translation>Tab</translation>
    </message>
    <message>
        <source>Backtab</source>
        <translation>Tab enrere</translation>
    </message>
    <message>
        <source>Backspace</source>
        <translation>Retrocés</translation>
    </message>
    <message>
        <source>Return</source>
        <translation>Retorn</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Retorn</translation>
    </message>
    <message>
        <source>Ins</source>
        <translation>Inser</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Supr</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimeix</translation>
    </message>
    <message>
        <source>SysReq</source>
        <translation>PetSis</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Inici</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Final</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Esquerra</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Amunt</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Dreta</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Avall</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>Re Pàg</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>Av Pàg</translation>
    </message>
    <message>
        <source>CapsLock</source>
        <translation>Bloq Maj</translation>
    </message>
    <message>
        <source>NumLock</source>
        <translation>Bloq Núm</translation>
    </message>
    <message>
        <source>ScrollLock</source>
        <translation>Bloq Despl</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menú</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Enrere</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Endavant</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Atura</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Refresca</translation>
    </message>
    <message>
        <source>Volume Down</source>
        <translation>Abaixa el volum</translation>
    </message>
    <message>
        <source>Volume Mute</source>
        <translation>Silencia el volum</translation>
    </message>
    <message>
        <source>Volume Up</source>
        <translation>Apuja el volum</translation>
    </message>
    <message>
        <source>Bass Boost</source>
        <translation>Potència de greus</translation>
    </message>
    <message>
        <source>Bass Up</source>
        <translation>Apuja els greus</translation>
    </message>
    <message>
        <source>Bass Down</source>
        <translation>Abaixa els greus</translation>
    </message>
    <message>
        <source>Treble Up</source>
        <translation>Apuja els aguts</translation>
    </message>
    <message>
        <source>Treble Down</source>
        <translation>Abaixa els aguts</translation>
    </message>
    <message>
        <source>Media Play</source>
        <translation>Reprodueix</translation>
    </message>
    <message>
        <source>Media Stop</source>
        <translation>Atura la reproducció</translation>
    </message>
    <message>
        <source>Media Previous</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <source>Media Next</source>
        <translation>Següent</translation>
    </message>
    <message>
        <source>Media Record</source>
        <translation>Enregistra</translation>
    </message>
    <message>
        <source>Media Pause</source>
        <extracomment>Media player pause button</extracomment>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Toggle Media Play/Pause</source>
        <extracomment>Media player button to toggle between playing and paused</extracomment>
        <translation>Commuta la reproducció/pausa</translation>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Pàgina d&apos;inici</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Preferits</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>Standby</source>
        <translation>En espera</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation>Obre URL</translation>
    </message>
    <message>
        <source>Launch Mail</source>
        <translation>Inicia el correu</translation>
    </message>
    <message>
        <source>Launch Media</source>
        <translation>Inicia el reproductor</translation>
    </message>
    <message>
        <source>Launch (0)</source>
        <translation>Inicia (0)</translation>
    </message>
    <message>
        <source>Launch (1)</source>
        <translation>Inicia (1)</translation>
    </message>
    <message>
        <source>Launch (2)</source>
        <translation>Inicia (2)</translation>
    </message>
    <message>
        <source>Launch (3)</source>
        <translation>Inicia (3)</translation>
    </message>
    <message>
        <source>Launch (4)</source>
        <translation>Inicia (4)</translation>
    </message>
    <message>
        <source>Launch (5)</source>
        <translation>Inicia (5)</translation>
    </message>
    <message>
        <source>Launch (6)</source>
        <translation>Inicia (6)</translation>
    </message>
    <message>
        <source>Launch (7)</source>
        <translation>Inicia (7)</translation>
    </message>
    <message>
        <source>Launch (8)</source>
        <translation>Inicia (8)</translation>
    </message>
    <message>
        <source>Launch (9)</source>
        <translation>Inicia (9)</translation>
    </message>
    <message>
        <source>Launch (A)</source>
        <translation>Inicia (A)</translation>
    </message>
    <message>
        <source>Launch (B)</source>
        <translation>Inicia (B)</translation>
    </message>
    <message>
        <source>Launch (C)</source>
        <translation>Inicia (C)</translation>
    </message>
    <message>
        <source>Launch (D)</source>
        <translation>Inicia (D)</translation>
    </message>
    <message>
        <source>Launch (E)</source>
        <translation>Inicia (E)</translation>
    </message>
    <message>
        <source>Launch (F)</source>
        <translation>Inicia (F)</translation>
    </message>
    <message>
        <source>Monitor Brightness Up</source>
        <translation>Augmenta la lluminositat del monitor</translation>
    </message>
    <message>
        <source>Monitor Brightness Down</source>
        <translation>Redueix la lluminositat del monitor</translation>
    </message>
    <message>
        <source>Keyboard Light On/Off</source>
        <translation>Engega/apaga la il·luminació del teclat</translation>
    </message>
    <message>
        <source>Keyboard Brightness Up</source>
        <translation>Augmenta la lluminositat del teclat</translation>
    </message>
    <message>
        <source>Keyboard Brightness Down</source>
        <translation>Redueix la lluminositat del teclat</translation>
    </message>
    <message>
        <source>Power Off</source>
        <translation>Apaga</translation>
    </message>
    <message>
        <source>Wake Up</source>
        <translation>Desperta</translation>
    </message>
    <message>
        <source>Eject</source>
        <translation>Expulsa</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Estalvi de pantalla</translation>
    </message>
    <message>
        <source>WWW</source>
        <translation>WWW</translation>
    </message>
    <message>
        <source>Sleep</source>
        <translation>Suspèn</translation>
    </message>
    <message>
        <source>LightBulb</source>
        <translation>Bombeta</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Botiga</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Història</translation>
    </message>
    <message>
        <source>Add Favorite</source>
        <translation>Afegeix als favorits</translation>
    </message>
    <message>
        <source>Hot Links</source>
        <translation>Enllaços candents</translation>
    </message>
    <message>
        <source>Adjust Brightness</source>
        <translation>Ajusta la lluminositat</translation>
    </message>
    <message>
        <source>Finance</source>
        <translation>Finances</translation>
    </message>
    <message>
        <source>Community</source>
        <translation>Comunitat</translation>
    </message>
    <message>
        <source>Audio Rewind</source>
        <translation type="vanished">Rebobina l&apos;àudio</translation>
    </message>
    <message>
        <source>Back Forward</source>
        <translation>Enrere Endavant</translation>
    </message>
    <message>
        <source>Application Left</source>
        <translation>Aplicació esquerra</translation>
    </message>
    <message>
        <source>Application Right</source>
        <translation>Aplicació dreta</translation>
    </message>
    <message>
        <source>Book</source>
        <translation>Llibre</translation>
    </message>
    <message>
        <source>CD</source>
        <translation>CD</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>Calculadora</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Neteja</translation>
    </message>
    <message>
        <source>Clear Grab</source>
        <translation>Neteja la gravació</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Retalla</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Visualitza</translation>
    </message>
    <message>
        <source>DOS</source>
        <translation>DOS</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Documents</translation>
    </message>
    <message>
        <source>Spreadsheet</source>
        <translation>Full de càlcul</translation>
    </message>
    <message>
        <source>Browser</source>
        <translation>Navegador</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Joc</translation>
    </message>
    <message>
        <source>Go</source>
        <translation>Ves</translation>
    </message>
    <message>
        <source>iTouch</source>
        <translation>iTouch</translation>
    </message>
    <message>
        <source>Logoff</source>
        <translation>Desconnecta</translation>
    </message>
    <message>
        <source>Market</source>
        <translation>Mercat</translation>
    </message>
    <message>
        <source>Meeting</source>
        <translation>Reunió</translation>
    </message>
    <message>
        <source>Keyboard Menu</source>
        <translation>Menú del teclat</translation>
    </message>
    <message>
        <source>Menu PB</source>
        <translation>Menú PB</translation>
    </message>
    <message>
        <source>My Sites</source>
        <translation>Els meus llocs</translation>
    </message>
    <message>
        <source>News</source>
        <translation>Notícies</translation>
    </message>
    <message>
        <source>Home Office</source>
        <translation>Despatx</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Opció</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Telèfon</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>Respon</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Torna a carregar</translation>
    </message>
    <message>
        <source>Rotate Windows</source>
        <translation>Gira les finestres</translation>
    </message>
    <message>
        <source>Rotation PB</source>
        <translation>Gir de PB</translation>
    </message>
    <message>
        <source>Rotation KB</source>
        <translation>Gir de teclat</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Envia</translation>
    </message>
    <message>
        <source>Spellchecker</source>
        <translation>Corrector ortogràfic</translation>
    </message>
    <message>
        <source>Split Screen</source>
        <translation>Divideix la pantalla</translation>
    </message>
    <message>
        <source>Support</source>
        <translation>Suport</translation>
    </message>
    <message>
        <source>Task Panel</source>
        <translation>Plafó de tasques</translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation>Terminal</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Eines</translation>
    </message>
    <message>
        <source>Travel</source>
        <translation>Viatge</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Word Processor</source>
        <translation>Processador de textos</translation>
    </message>
    <message>
        <source>XFer</source>
        <translation>Transf</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Apropa</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Allunya</translation>
    </message>
    <message>
        <source>Away</source>
        <translation>Absent</translation>
    </message>
    <message>
        <source>Messenger</source>
        <translation>Missatger</translation>
    </message>
    <message>
        <source>WebCam</source>
        <translation>Càmera web</translation>
    </message>
    <message>
        <source>Mail Forward</source>
        <translation>Reenvia el correu</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Imatges</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <source>Battery</source>
        <translation>Bateria</translation>
    </message>
    <message>
        <source>Bluetooth</source>
        <translation>Bluetooth</translation>
    </message>
    <message>
        <source>Wireless</source>
        <translation>Sense fils</translation>
    </message>
    <message>
        <source>Ultra Wide Band</source>
        <translation>Banda ultraampla</translation>
    </message>
    <message>
        <source>Audio Forward</source>
        <translation type="vanished">Avança àudio</translation>
    </message>
    <message>
        <source>Audio Repeat</source>
        <translation>Repetició de l&apos;àudio</translation>
    </message>
    <message>
        <source>Audio Random Play</source>
        <translation>Reproducció aleatòria de l&apos;àudio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Subtítol</translation>
    </message>
    <message>
        <source>Audio Cycle Track</source>
        <translation>Reproducció cíclica de la pista àudio</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Selecció</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Visualitza</translation>
    </message>
    <message>
        <source>Top Menu</source>
        <translation>Menú principal</translation>
    </message>
    <message>
        <source>Suspend</source>
        <translation>Suspèn</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation>Hiberna</translation>
    </message>
    <message>
        <source>Launch (G)</source>
        <translation>Inicia (G)</translation>
    </message>
    <message>
        <source>Launch (H)</source>
        <translation>Inicia (H)</translation>
    </message>
    <message>
        <source>Media Rewind</source>
        <translation>Rebobina el fitxer multimèdia</translation>
    </message>
    <message>
        <source>Calendar</source>
        <translation>Calendari</translation>
    </message>
    <message>
        <source>Adjust contrast</source>
        <translation>Ajusta el contrast</translation>
    </message>
    <message>
        <source>Memo</source>
        <translation>Anotació</translation>
    </message>
    <message>
        <source>To-do list</source>
        <translation>Llista de tasques pendents</translation>
    </message>
    <message>
        <source>Media Fast Forward</source>
        <translation>Avança ràpidament el fitxer multimèdia</translation>
    </message>
    <message>
        <source>Power Down</source>
        <translation>Apaga</translation>
    </message>
    <message>
        <source>Microphone Mute</source>
        <translation>Silencia el micròfon</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Vermell</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Verd</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Groc</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Blau</translation>
    </message>
    <message>
        <source>Channel Up</source>
        <translation>Canal següent</translation>
    </message>
    <message>
        <source>Channel Down</source>
        <translation>Canal anterior</translation>
    </message>
    <message>
        <source>Guide</source>
        <translation>Guia</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Informació</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <source>Microphone Volume Up</source>
        <translation>Apuja el volum del micròfon</translation>
    </message>
    <message>
        <source>Microphone Volume Down</source>
        <translation>Abaixa el volum del micròfon</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation>Teclat</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nou</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Desfés</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Refés</translation>
    </message>
    <message>
        <source>Print Screen</source>
        <translation>Impr Pant</translation>
    </message>
    <message>
        <source>Page Up</source>
        <translation>Retrocedir pàgina</translation>
    </message>
    <message>
        <source>Page Down</source>
        <translation>Avançar pàgina</translation>
    </message>
    <message>
        <source>Caps Lock</source>
        <translation>Bloq Maj</translation>
    </message>
    <message>
        <source>Num Lock</source>
        <translation>Bloq Núm</translation>
    </message>
    <message>
        <source>Number Lock</source>
        <translation>Bloq Núm</translation>
    </message>
    <message>
        <source>Scroll Lock</source>
        <translation>Bloq Despl</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Insereix</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Supressió</translation>
    </message>
    <message>
        <source>Escape</source>
        <translation>Escapada</translation>
    </message>
    <message>
        <source>System Request</source>
        <translation>Petició al sistema</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Context1</source>
        <translation>Context1</translation>
    </message>
    <message>
        <source>Context2</source>
        <translation>Context2</translation>
    </message>
    <message>
        <source>Context3</source>
        <translation>Context3</translation>
    </message>
    <message>
        <source>Context4</source>
        <translation>Context4</translation>
    </message>
    <message>
        <source>Call</source>
        <extracomment>Button to start a call (note: a separate button is used to end the call)</extracomment>
        <translation>Truca</translation>
    </message>
    <message>
        <source>Hangup</source>
        <extracomment>Button to end a call (note: a separate button is used to start the call)</extracomment>
        <translation>Penja</translation>
    </message>
    <message>
        <source>Toggle Call/Hangup</source>
        <extracomment>Button that will hang up if we&apos;re in call, or make a call if we&apos;re not.</extracomment>
        <translation>Commuta trucada/penjar</translation>
    </message>
    <message>
        <source>Flip</source>
        <translation>Inverteix</translation>
    </message>
    <message>
        <source>Voice Dial</source>
        <extracomment>Button to trigger voice dialing</extracomment>
        <translation>Marcació per veu</translation>
    </message>
    <message>
        <source>Last Number Redial</source>
        <extracomment>Button to redial the last number called</extracomment>
        <translation>Torna a marcar el darrer número</translation>
    </message>
    <message>
        <source>Camera Shutter</source>
        <extracomment>Button to trigger the camera shutter (take a picture)</extracomment>
        <translation>Disparador de la càmera</translation>
    </message>
    <message>
        <source>Camera Focus</source>
        <extracomment>Button to focus the camera</extracomment>
        <translation>Focus de la càmera</translation>
    </message>
    <message>
        <source>Kanji</source>
        <translation>Kanji</translation>
    </message>
    <message>
        <source>Muhenkan</source>
        <translation>Muhenkan</translation>
    </message>
    <message>
        <source>Henkan</source>
        <translation>Henkan</translation>
    </message>
    <message>
        <source>Romaji</source>
        <translation>Romaji</translation>
    </message>
    <message>
        <source>Hiragana</source>
        <translation>Hiragana</translation>
    </message>
    <message>
        <source>Katakana</source>
        <translation>Katakana</translation>
    </message>
    <message>
        <source>Hiragana Katakana</source>
        <translation>Hiragana Katakana</translation>
    </message>
    <message>
        <source>Zenkaku</source>
        <translation>Zenkaku</translation>
    </message>
    <message>
        <source>Hankaku</source>
        <translation>Hankaku</translation>
    </message>
    <message>
        <source>Zenkaku Hankaku</source>
        <translation>Zenkaku Hankaku</translation>
    </message>
    <message>
        <source>Touroku</source>
        <translation>Touroku</translation>
    </message>
    <message>
        <source>Massyo</source>
        <translation>Massyo</translation>
    </message>
    <message>
        <source>Kana Lock</source>
        <translation>Bloqueig Kana</translation>
    </message>
    <message>
        <source>Kana Shift</source>
        <translation>Majúscules Kana</translation>
    </message>
    <message>
        <source>Eisu Shift</source>
        <translation>Majúscules Eisu</translation>
    </message>
    <message>
        <source>Eisu toggle</source>
        <translation>Commuta Eisu</translation>
    </message>
    <message>
        <source>Code input</source>
        <translation>Entrada de codi</translation>
    </message>
    <message>
        <source>Multiple Candidate</source>
        <translation>Candidats múltiples</translation>
    </message>
    <message>
        <source>Previous Candidate</source>
        <translation>Candidat anterior</translation>
    </message>
    <message>
        <source>Hangul</source>
        <translation>Hangul</translation>
    </message>
    <message>
        <source>Hangul Start</source>
        <translation>Inici de Hangul</translation>
    </message>
    <message>
        <source>Hangul End</source>
        <translation>Final de Hangul</translation>
    </message>
    <message>
        <source>Hangul Hanja</source>
        <translation>Hangul Hanja</translation>
    </message>
    <message>
        <source>Hangul Jamo</source>
        <translation>Hangul Jamo</translation>
    </message>
    <message>
        <source>Hangul Romaja</source>
        <translation>Hangul Romaja</translation>
    </message>
    <message>
        <source>Hangul Jeonja</source>
        <translation>Hangul Jeonja</translation>
    </message>
    <message>
        <source>Hangul Banja</source>
        <translation>Hangul Banja</translation>
    </message>
    <message>
        <source>Hangul PreHanja</source>
        <translation>Hangul PreHanja</translation>
    </message>
    <message>
        <source>Hangul PostHanja</source>
        <translation>Hangul PostHanja</translation>
    </message>
    <message>
        <source>Hangul Special</source>
        <translation>Hangul especial</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Impressora</translation>
    </message>
    <message>
        <source>Execute</source>
        <translation>Executa</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Reprodueix</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Surt</translation>
    </message>
    <message>
        <source>Touchpad Toggle</source>
        <translation>Commuta el ratolí tàctil</translation>
    </message>
    <message>
        <source>Touchpad On</source>
        <translation>Ratolí tàctil actiu</translation>
    </message>
    <message>
        <source>Touchpad Off</source>
        <translation>Ratolí tàctil inactiu</translation>
    </message>
    <message>
        <source>Control</source>
        <translation>Control</translation>
    </message>
    <message>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <source>Shift</source>
        <translation>Maj</translation>
    </message>
    <message>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <source>Num</source>
        <translation>Núm</translation>
    </message>
    <message>
        <source>+</source>
        <extracomment>Key separator in shortcut string</extracomment>
        <translation>+</translation>
    </message>
    <message>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
</context>
<context>
    <name>QSocks5SocketEngine</name>
    <message>
        <source>Connection to proxy refused</source>
        <translation>S&apos;ha rebutjat la connexió al servidor intermediari</translation>
    </message>
    <message>
        <source>Connection to proxy closed prematurely</source>
        <translation>La connexió al servidor intermediari s&apos;ha tancat prematurament</translation>
    </message>
    <message>
        <source>Proxy host not found</source>
        <translation>No s&apos;ha trobat el servidor intermediari</translation>
    </message>
    <message>
        <source>Connection to proxy timed out</source>
        <translation>La connexió al servidor intermediari ha excedit el temps</translation>
    </message>
    <message>
        <source>Proxy authentication failed</source>
        <translation>Ha fallat l&apos;autenticació al servidor intermediari</translation>
    </message>
    <message>
        <source>Proxy authentication failed: %1</source>
        <translation>Ha fallat l&apos;autenticació al servidor intermediari: %1</translation>
    </message>
    <message>
        <source>SOCKS version 5 protocol error</source>
        <translation>Error de protocol SOCKS versió 5</translation>
    </message>
    <message>
        <source>General SOCKSv5 server failure</source>
        <translation>Fallada general del servidor SOCKSv5</translation>
    </message>
    <message>
        <source>Connection not allowed by SOCKSv5 server</source>
        <translation>Connexió no autoritzada pel servidor SOCKSv5</translation>
    </message>
    <message>
        <source>TTL expired</source>
        <translation>Ha caducat el TTL</translation>
    </message>
    <message>
        <source>SOCKSv5 command not supported</source>
        <translation>Ordre SOCKSv5 no admesa</translation>
    </message>
    <message>
        <source>Address type not supported</source>
        <translation>Tipus d&apos;accés no admès</translation>
    </message>
    <message>
        <source>Unknown SOCKSv5 proxy error code 0x%1</source>
        <translation>Codi d&apos;error desconegut del servidor intermediari SOCKSv5: 0x%1</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>L&apos;operació de xarxa ha excedit el temps</translation>
    </message>
</context>
<context>
    <name>QSpiAccessibleBridge</name>
    <message>
        <source>invalid role</source>
        <extracomment>Role of an accessible object - the object is in an invalid state or could not be constructed</extracomment>
        <translation>rol no vàlid</translation>
    </message>
    <message>
        <source>title bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de títol</translation>
    </message>
    <message>
        <source>menu bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de menús</translation>
    </message>
    <message>
        <source>scroll bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de desplaçament</translation>
    </message>
    <message>
        <source>grip</source>
        <extracomment>Role of an accessible object - the grip is usually used for resizing another object</extracomment>
        <translation>nansa</translation>
    </message>
    <message>
        <source>sound</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>so</translation>
    </message>
    <message>
        <source>cursor</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>cursor</translation>
    </message>
    <message>
        <source>text caret</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>cursor de text</translation>
    </message>
    <message>
        <source>alert message</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>missatge d&apos;alerta</translation>
    </message>
    <message>
        <source>window</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation type="vanished">finestra</translation>
    </message>
    <message>
        <source>filler</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>farciment</translation>
    </message>
    <message>
        <source>popup menu</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>menú emergent</translation>
    </message>
    <message>
        <source>menu item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>element de menú</translation>
    </message>
    <message>
        <source>tool tip</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>indicador de funció</translation>
    </message>
    <message>
        <source>application</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>aplicació</translation>
    </message>
    <message>
        <source>document</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>document</translation>
    </message>
    <message>
        <source>panel</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>plafó</translation>
    </message>
    <message>
        <source>chart</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>diagrama</translation>
    </message>
    <message>
        <source>dialog</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>diàleg</translation>
    </message>
    <message>
        <source>frame</source>
        <extracomment>Role of an accessible object: a window with frame and title</extracomment>
        <translation>marc</translation>
    </message>
    <message>
        <source>separator</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>separador</translation>
    </message>
    <message>
        <source>tool bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra d&apos;eines</translation>
    </message>
    <message>
        <source>status bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra d&apos;estat</translation>
    </message>
    <message>
        <source>table</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>taula</translation>
    </message>
    <message>
        <source>column header</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>capçalera de columna</translation>
    </message>
    <message>
        <source>row header</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>capçalera de fila</translation>
    </message>
    <message>
        <source>column</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>columna</translation>
    </message>
    <message>
        <source>row</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>fila</translation>
    </message>
    <message>
        <source>cell</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>cel·la</translation>
    </message>
    <message>
        <source>link</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>enllaç</translation>
    </message>
    <message>
        <source>help balloon</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>globus d&apos;ajuda</translation>
    </message>
    <message>
        <source>assistant</source>
        <extracomment>Role of an accessible object - a helper dialog</extracomment>
        <translation>assistent</translation>
    </message>
    <message>
        <source>list</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>llista</translation>
    </message>
    <message>
        <source>list item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>element de llista</translation>
    </message>
    <message>
        <source>tree</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>arbre</translation>
    </message>
    <message>
        <source>tree item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>element d&apos;arbre</translation>
    </message>
    <message>
        <source>page tab</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>pestanya de pàgina</translation>
    </message>
    <message>
        <source>property page</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>pàgina de propietats</translation>
    </message>
    <message>
        <source>indicator</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>indicador</translation>
    </message>
    <message>
        <source>graphic</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>gràfic</translation>
    </message>
    <message>
        <source>label</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>etiqueta</translation>
    </message>
    <message>
        <source>text</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>text</translation>
    </message>
    <message>
        <source>push button</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botó per a prémer</translation>
    </message>
    <message>
        <source>check box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>casella de selecció</translation>
    </message>
    <message>
        <source>switch</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>commutador</translation>
    </message>
    <message>
        <source>radio button</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botó d&apos;opció</translation>
    </message>
    <message>
        <source>combo box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>quadre combinat</translation>
    </message>
    <message>
        <source>progress bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de progrés</translation>
    </message>
    <message>
        <source>dial</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>marcador</translation>
    </message>
    <message>
        <source>hotkey field</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>camp de drecera</translation>
    </message>
    <message>
        <source>slider</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>control lliscant</translation>
    </message>
    <message>
        <source>spin box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botó de selecció de valors</translation>
    </message>
    <message>
        <source>canvas</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>llenç</translation>
    </message>
    <message>
        <source>animation</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>animació</translation>
    </message>
    <message>
        <source>equation</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>equació</translation>
    </message>
    <message>
        <source>button with drop down</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botó amb llista desplegable</translation>
    </message>
    <message>
        <source>button menu</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botó de menú</translation>
    </message>
    <message>
        <source>button with drop down grid</source>
        <extracomment>Role of an accessible object - a button that expands a grid.</extracomment>
        <translation>botó amb nansa desplegable</translation>
    </message>
    <message>
        <source>space</source>
        <extracomment>Role of an accessible object - blank space between other objects.</extracomment>
        <translation>espai</translation>
    </message>
    <message>
        <source>page tab list</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>llista de pestanyes de pàgina</translation>
    </message>
    <message>
        <source>clock</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>rellotge</translation>
    </message>
    <message>
        <source>splitter</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>separador</translation>
    </message>
    <message>
        <source>layered pane</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>subfinestra amb capes</translation>
    </message>
    <message>
        <source>web document</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>document web</translation>
    </message>
    <message>
        <source>paragraph</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>paràgraf</translation>
    </message>
    <message>
        <source>section</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>secció</translation>
    </message>
    <message>
        <source>color chooser</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>selector de color</translation>
    </message>
    <message>
        <source>footer</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>peu de pàgina</translation>
    </message>
    <message>
        <source>form</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>formulari</translation>
    </message>
    <message>
        <source>heading</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>capçalera</translation>
    </message>
    <message>
        <source>note</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>nota</translation>
    </message>
    <message>
        <source>complementary content</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>contingut complementari</translation>
    </message>
    <message>
        <source>terminal</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>terminal</translation>
    </message>
    <message>
        <source>desktop</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>escriptori</translation>
    </message>
    <message>
        <source>notification</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>notificació</translation>
    </message>
    <message>
        <source>block quote</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>cita de bloc</translation>
    </message>
    <message>
        <source>unknown</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>desconegut</translation>
    </message>
</context>
<context>
    <name>QSslDiffieHellmanParameter</name>
    <message>
        <source>No error</source>
        <translation>Sense error</translation>
    </message>
    <message>
        <source>Invalid input data</source>
        <translation>Dades d&apos;entrada no vàlides</translation>
    </message>
    <message>
        <source>The given Diffie-Hellman parameters are deemed unsafe</source>
        <translation>Els paràmetres del Diffie-Hellman indicats es consideren insegurs</translation>
    </message>
</context>
<context>
    <name>QSslSocket</name>
    <message>
        <source>Error when setting the elliptic curves (%1)</source>
        <translation>Error en determinar les corbes el·líptiques (%1)</translation>
    </message>
    <message>
        <source>Error creating SSL context (%1)</source>
        <translation>Error en crear el context SSL (%1)</translation>
    </message>
    <message>
        <source>unsupported protocol</source>
        <translation>protocol no admès</translation>
    </message>
    <message>
        <source>Error while setting the minimal protocol version</source>
        <translation>Error en definir la versió mínima del protocol</translation>
    </message>
    <message>
        <source>Error while setting the maximum protocol version</source>
        <translation>Error en definir la versió màxima del protocol</translation>
    </message>
    <message>
        <source>Invalid or empty cipher list (%1)</source>
        <translation>Llista de xifres no vàlida o buida (%1)</translation>
    </message>
    <message>
        <source>Cannot provide a certificate with no key, %1</source>
        <translation type="vanished">No es pot subministrar un certificat sense una clau, %1</translation>
    </message>
    <message>
        <source>Error loading local certificate, %1</source>
        <translation>Error en carregar un certificat local, %1</translation>
    </message>
    <message>
        <source>Error loading private key, %1</source>
        <translation>Error en carregar la clau privada, %1</translation>
    </message>
    <message>
        <source>Private key does not certify public key, %1</source>
        <translation>La clau privada no certifica la clau pública, %1</translation>
    </message>
    <message>
        <source>Diffie-Hellman parameters are not valid</source>
        <translation>Els paràmetres del Diffie-Hellman no són vàlids</translation>
    </message>
    <message>
        <source>OpenSSL version with disabled elliptic curves</source>
        <translation>Versió de l&apos;OpenSSL amb les corbes el·líptiques desactivades</translation>
    </message>
    <message>
        <source>Error when setting the OpenSSL configuration (%1)</source>
        <translation>Error en definir la configuració de l&apos;OpenSSL (%1)</translation>
    </message>
    <message>
        <source>Expecting QByteArray for %1</source>
        <translation>S&apos;esperava QByteArray per %1</translation>
    </message>
    <message>
        <source>An error occurred attempting to set %1 to %2</source>
        <translation>S&apos;ha produït un error en intentar establir %1 a %2</translation>
    </message>
    <message>
        <source>Wrong value for %1 (%2)</source>
        <translation>Valor erroni per %1 (%2)</translation>
    </message>
    <message>
        <source>Unrecognized command %1 = %2</source>
        <translation>Ordre no reconeguda %1 = %2</translation>
    </message>
    <message>
        <source>SSL_CONF_finish() failed</source>
        <translation>Ha fallat SSL_CONF_finish()</translation>
    </message>
    <message>
        <source>SSL_CONF_CTX_new() failed</source>
        <translation>Ha fallat SSL_CONF_CTX_new()</translation>
    </message>
    <message>
        <source>OpenSSL version too old, need at least v1.0.2</source>
        <translation type="vanished">La versió de l&apos;OpenSSL és massa antiga, cal com a mínim la v1.0.2</translation>
    </message>
    <message>
        <source>No error</source>
        <translation>Sense error</translation>
    </message>
    <message>
        <source>The issuer certificate could not be found</source>
        <translation>No s&apos;ha trobat l&apos;emissor del certificat</translation>
    </message>
    <message>
        <source>The certificate signature could not be decrypted</source>
        <translation>No s&apos;ha pogut desencriptar la signatura del certificat</translation>
    </message>
    <message>
        <source>The public key in the certificate could not be read</source>
        <translation>No s&apos;ha pogut llegir la clau pública del certificat</translation>
    </message>
    <message>
        <source>The signature of the certificate is invalid</source>
        <translation>La signatura del certificat no és vàlida</translation>
    </message>
    <message>
        <source>The certificate is not yet valid</source>
        <translation>El certificat encara no és vàlid</translation>
    </message>
    <message>
        <source>The certificate has expired</source>
        <translation>El certificat ha caducat</translation>
    </message>
    <message>
        <source>The certificate&apos;s notBefore field contains an invalid time</source>
        <translation>El camp «noAbans» del certificat conté una hora no vàlida</translation>
    </message>
    <message>
        <source>The certificate&apos;s notAfter field contains an invalid time</source>
        <translation>El camp «noDesprés» del certificat conté una hora no vàlida</translation>
    </message>
    <message>
        <source>The certificate is self-signed, and untrusted</source>
        <translation>El certificat està autosignat, i no és fiable</translation>
    </message>
    <message>
        <source>The root certificate of the certificate chain is self-signed, and untrusted</source>
        <translation>El certificat arrel de la cadena de certificats està autosignat, i no és fiable</translation>
    </message>
    <message>
        <source>The issuer certificate of a locally looked up certificate could not be found</source>
        <translation>No s&apos;ha trobat l&apos;emissor del certificat d&apos;un certificat local</translation>
    </message>
    <message>
        <source>No certificates could be verified</source>
        <translation>No es pot verificar cap certificat</translation>
    </message>
    <message>
        <source>One of the CA certificates is invalid</source>
        <translation>Un dels certificats de la CA no és vàlid</translation>
    </message>
    <message>
        <source>The basicConstraints path length parameter has been exceeded</source>
        <translation>S&apos;ha excedit el paràmetre de longitud del camí de «basicConstraints»</translation>
    </message>
    <message>
        <source>The supplied certificate is unsuitable for this purpose</source>
        <translation>El certificat proporcionat no és adequat per a aquest propòsit</translation>
    </message>
    <message>
        <source>The root CA certificate is not trusted for this purpose</source>
        <translation>El certificat de la CA arrel no és fiable per a aquest propòsit</translation>
    </message>
    <message>
        <source>The root CA certificate is marked to reject the specified purpose</source>
        <translation>El certificat de la CA arrel està marcat per a rebutjar el propòsit especificat</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its subject name did not match the issuer name of the current certificate</source>
        <translation>El certificat de l&apos;emissor del candidat actual s&apos;ha rebutjat perquè el seu nom de subjecte no coincideix amb el nom de l&apos;emissor del certificat actual</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its issuer name and serial number was present and did not match the authority key identifier of the current certificate</source>
        <translation>El certificat de l&apos;emissor del candidat actual s&apos;ha rebutjat perquè el seu nom d&apos;emissor i número de sèrie eren presents i no coincideixen amb l&apos;identificador de la clau de l&apos;autoritat del certificat actual</translation>
    </message>
    <message>
        <source>The peer did not present any certificate</source>
        <translation>El parell no presenta cap certificat</translation>
    </message>
    <message>
        <source>The host name did not match any of the valid hosts for this certificate</source>
        <translation>El nom d&apos;ordinador no concorda amb cap dels ordinadors vàlids per aquest certificat</translation>
    </message>
    <message>
        <source>The peer certificate is blacklisted</source>
        <translation>El certificat del parell és a la llista negra</translation>
    </message>
    <message>
        <source>No OCSP status response found</source>
        <translation>No s&apos;ha trobat cap resposta de l&apos;estat OCSP</translation>
    </message>
    <message>
        <source>The OCSP status request had invalid syntax</source>
        <translation>La sol·licitud de l&apos;estat OCSP tenia una sintaxi no vàlida</translation>
    </message>
    <message>
        <source>OCSP response contains an unexpected number of SingleResponse structures</source>
        <translation>La resposta OCSP conté un nombre inesperat d&apos;estructures «SingleResponse»</translation>
    </message>
    <message>
        <source>OCSP responder reached an inconsistent internal state</source>
        <translation>El contestador OCSP ha arribat a un estat intern incoherent</translation>
    </message>
    <message>
        <source>OCSP responder was unable to return a status for the requested certificate</source>
        <translation>El contestador OCSP no ha pogut retornar un estat per al certificat sol·licitat</translation>
    </message>
    <message>
        <source>The server requires the client to sign the OCSP request in order to construct a response</source>
        <translation>El servidor requereix que el client signi la sol·licitud OCSP per tal de construir una resposta</translation>
    </message>
    <message>
        <source>The client is not authorized to request OCSP status from this server</source>
        <translation>El client no està autoritzat a sol·licitar un estat OCSP d&apos;aquest servidor</translation>
    </message>
    <message>
        <source>OCSP responder&apos;s identity cannot be verified</source>
        <translation>No s&apos;ha pogut verificar la identitat del contestador OCSP</translation>
    </message>
    <message>
        <source>The identity of a certificate in an OCSP response cannot be established</source>
        <translation>No s&apos;ha pogut establir la identitat d&apos;un certificat a una resposta OCSP</translation>
    </message>
    <message>
        <source>The certificate status response has expired</source>
        <translation>La resposta de l&apos;estat del certificat ha caducat</translation>
    </message>
    <message>
        <source>The certificate&apos;s status is unknown</source>
        <translation>L&apos;estat del certificat és desconegut</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
    <message>
        <source>Error creating SSL session, %1</source>
        <translation>Error en crear la sessió SSL, %1</translation>
    </message>
    <message>
        <source>Error creating SSL session: %1</source>
        <translation>Error en crear la sessió SSL: %1</translation>
    </message>
    <message>
        <source>Server-side QSslSocket does not support OCSP stapling</source>
        <translation>El QSslSocket de la banda del servidor no admet la marca horària OCSP</translation>
    </message>
    <message>
        <source>Failed to enable OCSP stapling</source>
        <translation>Ha fallat en activar la marca horària OCSP</translation>
    </message>
    <message>
        <source>Client-side sockets do not send OCSP responses</source>
        <translation>Els sòcols de la banda del client no envien respostes OCSP</translation>
    </message>
    <message>
        <source>Unable to init SSL Context: %1</source>
        <translation>No s&apos;ha pogut iniciar el context SSL: %1</translation>
    </message>
    <message>
        <source>Unable to write data: %1</source>
        <translation>No s&apos;han pogut escriure les dades: %1</translation>
    </message>
    <message>
        <source>Unable to decrypt data: %1</source>
        <translation>No s&apos;han pogut desencriptar les dades: %1</translation>
    </message>
    <message>
        <source>TLS certificate unexpectedly changed during renegotiation!</source>
        <translation>El certificat TLS ha canviat inesperadament durant la renegociació!</translation>
    </message>
    <message>
        <source>Failed to decode OCSP response</source>
        <translation>Ha fallat en descodificar la resposta OCSP</translation>
    </message>
    <message>
        <source>Failed to extract basic OCSP response</source>
        <translation>Ha fallat en extreure la resposta OCSP bàsica</translation>
    </message>
    <message>
        <source>No certificate verification store, cannot verify OCSP response</source>
        <translation>No hi ha cap magatzem de verificació de certificats, no s&apos;ha pogut verificar la resposta OCSP</translation>
    </message>
    <message>
        <source>Failed to decode a SingleResponse from OCSP status response</source>
        <translation>Ha fallat en descodificar una «SingleResponse» d&apos;una resposta d&apos;estat OCSP</translation>
    </message>
    <message>
        <source>Failed to extract &apos;this update time&apos; from the SingleResponse</source>
        <translation>Ha fallat en extreure «this update time» de la «SingleResponse»</translation>
    </message>
    <message>
        <source>The TLS/SSL connection has been closed</source>
        <translation>S&apos;ha tancat la connexió TLS/SSL</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Error en llegir: %1</translation>
    </message>
    <message>
        <source>Error during SSL handshake: %1</source>
        <translation>Error durant la conformitat de connexió SSL: %1</translation>
    </message>
    <message>
        <source>TLS initialization failed</source>
        <translation>Ha fallat la inicialització del TLS</translation>
    </message>
    <message>
        <source>Attempted to use an unsupported protocol.</source>
        <translation>S&apos;ha intentat usar un protocol no admès.</translation>
    </message>
    <message>
        <source>Insufficient memory</source>
        <translation>Memòria insuficient</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation>Error intern</translation>
    </message>
    <message>
        <source>An internal handle was invalid</source>
        <translation>Un gestor intern no era vàlid</translation>
    </message>
    <message>
        <source>An internal token was invalid</source>
        <translation>Un testimoni intern no era vàlid</translation>
    </message>
    <message>
        <source>Access denied</source>
        <translation>S&apos;ha denegat l&apos;accés</translation>
    </message>
    <message>
        <source>No authority could be contacted for authorization</source>
        <translation>No s&apos;ha pogut contactar amb cap autoritat per a l&apos;autorització</translation>
    </message>
    <message>
        <source>No credentials</source>
        <translation>Sense credencials</translation>
    </message>
    <message>
        <source>The target is unknown or unreachable</source>
        <translation>El destí és desconegut o inaccessible</translation>
    </message>
    <message>
        <source>An unsupported function was requested</source>
        <translation>S&apos;ha sol·licitat una funció no admesa</translation>
    </message>
    <message>
        <source>The hostname provided does not match the one received from the peer</source>
        <translation>El nom d&apos;ordinador proporcionat no coincideix amb el rebut del parell</translation>
    </message>
    <message>
        <source>No common protocol exists between the client and the server</source>
        <translation>No existeix cap protocol comú entre el client i el servidor</translation>
    </message>
    <message>
        <source>Unexpected or badly-formatted message received</source>
        <translation>S&apos;ha rebut un missatge inesperat o amb format incorrecte</translation>
    </message>
    <message>
        <source>The data could not be encrypted</source>
        <translation>No s&apos;han pogut encriptar les dades</translation>
    </message>
    <message>
        <source>The data could not be decrypted</source>
        <translation>No s&apos;han pogut desencriptar les dades</translation>
    </message>
    <message>
        <source>No cipher suites in common</source>
        <translation>No hi ha cap xifra adequada en comú</translation>
    </message>
    <message>
        <source>The credentials were not recognized / Invalid argument</source>
        <translation>No s&apos;han reconegut les credencials / Argument no vàlid</translation>
    </message>
    <message>
        <source>The message was tampered with, damaged or out of sequence.</source>
        <translation>El missatge s&apos;ha manipulat, està malmès o està fora de la seqüència.</translation>
    </message>
    <message>
        <source>A message was received out of sequence.</source>
        <translation>S&apos;ha rebut un missatge fora de la seqüència.</translation>
    </message>
    <message>
        <source>Unknown error occurred: %1</source>
        <translation>S&apos;ha produït un error desconegut: %1</translation>
    </message>
    <message>
        <source>Invalid protocol chosen</source>
        <translation>S&apos;ha triat un protocol no vàlid</translation>
    </message>
    <message>
        <source>The certificate provided cannot be used for a client.</source>
        <translation type="vanished">El certificat proporcionat no pot ser usat per un client.</translation>
    </message>
    <message>
        <source>The certificate provided cannot be used for a server.</source>
        <translation type="vanished">El certificat proporcionat no pot ser usat per un servidor.</translation>
    </message>
    <message>
        <source>Server did not accept any certificate we could present.</source>
        <translation type="unfinished">El servidor no ha acceptat cap certificat que puguem presentar.</translation>
    </message>
    <message>
        <source>Algorithm mismatch</source>
        <translation>Algorisme desaparellat</translation>
    </message>
    <message>
        <source>Handshake failed: %1</source>
        <translation>Ha fallat la conformitat de la connexió: %1</translation>
    </message>
    <message>
        <source>Failed to query the TLS context: %1</source>
        <translation>Ha fallat en consultar el context del TLS: %1</translation>
    </message>
    <message>
        <source>Did not get the required attributes for the connection.</source>
        <translation>No s&apos;han aconseguit els atributs requerits per a la connexió.</translation>
    </message>
    <message>
        <source>Unwanted protocol was negotiated</source>
        <translation>S&apos;ha negociat un protocol no desitjat</translation>
    </message>
    <message>
        <source>Renegotiation was unsuccessful: %1</source>
        <translation>La renegociació ha estat infructuosa: %1</translation>
    </message>
    <message>
        <source>Schannel failed to encrypt data: %1</source>
        <translation>El «Schannel» ha fallat en encriptar les dades: %1</translation>
    </message>
    <message>
        <source>Cannot provide a certificate with no key</source>
        <translation>No es pot subministrar un certificat sense una clau</translation>
    </message>
</context>
<context>
    <name>QStandardPaths</name>
    <message>
        <source>Desktop</source>
        <translation>Escriptori</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Documents</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Lletres</translation>
    </message>
    <message>
        <source>Applications</source>
        <translation>Aplicacions</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Pel·lícules</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Imatges</translation>
    </message>
    <message>
        <source>Temporary Directory</source>
        <translation>Directori temporal</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Inici</translation>
    </message>
    <message>
        <source>Application Data</source>
        <translation>Dades d&apos;aplicació</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estat</translation>
    </message>
    <message>
        <source>Shared State</source>
        <translation>Estat compartit</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Baixades</translation>
    </message>
    <message>
        <source>Application Configuration</source>
        <translation>Configuració d&apos;aplicació</translation>
    </message>
    <message>
        <source>Public</source>
        <translation>Públic</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Plantilles</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Memòria cau</translation>
    </message>
    <message>
        <source>Shared Data</source>
        <translation>Dades compartides</translation>
    </message>
    <message>
        <source>Runtime</source>
        <translation>Execució</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <source>Shared Configuration</source>
        <translation>Configuració compartida</translation>
    </message>
    <message>
        <source>Shared Cache</source>
        <translation>Memòria cau compartida</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="vanished">Baixades</translation>
    </message>
    <message>
        <source>Temporary Items</source>
        <extracomment>macOS: Temporary directory</extracomment>
        <translation>Elements temporals</translation>
    </message>
</context>
<context>
    <name>QStateMachine</name>
    <message>
        <source>Missing initial state in compound state &apos;%1&apos;</source>
        <translation type="vanished">Manca l&apos;estat inicial a l&apos;estat compost «%1»</translation>
    </message>
    <message>
        <source>Missing default state in history state &apos;%1&apos;</source>
        <translation type="vanished">Manca l&apos;estat per defecte a l&apos;estat històric «%1»</translation>
    </message>
    <message>
        <source>No common ancestor for targets and source of transition from state &apos;%1&apos;</source>
        <translation type="vanished">No hi ha cap antecessor comú per les destinacions i origen des de l&apos;estat «%1»</translation>
    </message>
    <message>
        <source>Child mode of state machine &apos;%1&apos; is not &apos;ExclusiveStates&apos;.</source>
        <translation type="vanished">El mode fill de la màquina d&apos;estats «%1» no és «ExclusiveStates».</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Error desconegut</translation>
    </message>
</context>
<context>
    <name>QSystemSemaphore</name>
    <message>
        <source>%1: unsupported key type</source>
        <translation>%1: tipus de clau no admès</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: s&apos;ha denegat el permís</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: ja existeix</translation>
    </message>
    <message>
        <source>%1: does not exist</source>
        <translation>%1: no existeix</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: sense recursos</translation>
    </message>
    <message>
        <source>%1: key too long</source>
        <translation>%1: la clau és massa llarga</translation>
    </message>
    <message>
        <source>%1: unknown error: %2</source>
        <translation>%1: error desconegut: %2</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation type="vanished">%1: error desconegut %2</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: la clau és buida</translation>
    </message>
    <message>
        <source>%1: System V semaphores are not available for sandboxed applications. Please build Qt with -feature-ipc_posix</source>
        <translation>%1: els semàfors del System V no estan disponibles per a aplicacions en entorn protegit. Construïu les Qt amb -feature-ipc_posix</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: no s&apos;ha pogut crear la clau</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation>%1: ha fallat el «ftok»</translation>
    </message>
</context>
<context>
    <name>QTDSDriver</name>
    <message>
        <source>Unable to open connection</source>
        <translation type="vanished">No s&apos;ha pogut obrir la connexió</translation>
    </message>
    <message>
        <source>Unable to use database</source>
        <translation type="vanished">No s&apos;ha pogut utilitzar la base de dades</translation>
    </message>
</context>
<context>
    <name>QTabBar</name>
    <message>
        <source>Scroll Left</source>
        <translation>Desplaçament a l&apos;esquerra</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Desplaçament a la dreta</translation>
    </message>
</context>
<context>
    <name>QTcpServer</name>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>Operació no admesa al sòcol</translation>
    </message>
</context>
<context>
    <name>QTgaFile</name>
    <message>
        <source>Could not read image data</source>
        <translation>No s&apos;han pogut llegir les dades de la imatge</translation>
    </message>
    <message>
        <source>Sequential device (eg socket) for image read not supported</source>
        <translation>No s&apos;admet cap dispositiu seqüencial (p. ex. sòcol) per a llegir una imatge</translation>
    </message>
    <message>
        <source>Seek file/device for image read failed</source>
        <translation>Ha fallat la cerca del fitxer/dispositiu per a llegir la imatge</translation>
    </message>
    <message>
        <source>Image header read failed</source>
        <translation>Ha fallat la lectura de la capçalera de la imatge</translation>
    </message>
    <message>
        <source>Image type not supported</source>
        <translation>Tipus d&apos;imatge no admès</translation>
    </message>
    <message>
        <source>Image depth not valid</source>
        <translation>Profunditat de la imatge no vàlida</translation>
    </message>
    <message>
        <source>Image size exceeds limit</source>
        <translation>La mida de la imatge excedeix el límit</translation>
    </message>
    <message>
        <source>Could not seek to image read footer</source>
        <translation>No s&apos;ha pogut cercar el peu de lectura de la imatge</translation>
    </message>
    <message>
        <source>Could not read footer</source>
        <translation>No s&apos;ha pogut llegir el peu</translation>
    </message>
    <message>
        <source>Image type (non-TrueVision 2.0) not supported</source>
        <translation>Tipus d&apos;imatge no admès (no és TrueVision 2.0)</translation>
    </message>
    <message>
        <source>Could not reset to read data</source>
        <translation>No s&apos;ha pogut reiniciar la lectura de les dades</translation>
    </message>
    <message>
        <source>Invalid color map depth (%1)</source>
        <translation>Profunditat del mapa de color no vàlida (%1)</translation>
    </message>
</context>
<context>
    <name>QUdpSocket</name>
    <message>
        <source>Unable to send a datagram</source>
        <translation>No s&apos;ha pogut enviar un datagrama</translation>
    </message>
    <message>
        <source>No datagram available for reading</source>
        <translation>No hi ha cap datagrama disponible per a llegir</translation>
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <source>Undo %1</source>
        <translation>Desfés %1</translation>
    </message>
    <message>
        <source>Undo</source>
        <comment>Default text for undo action</comment>
        <translation>Desfés</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation>Refés %1</translation>
    </message>
    <message>
        <source>Redo</source>
        <comment>Default text for redo action</comment>
        <translation>Refés</translation>
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;buit&gt;</translation>
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <source>Undo %1</source>
        <translation>Desfés %1</translation>
    </message>
    <message>
        <source>Undo</source>
        <comment>Default text for undo action</comment>
        <translation>Desfés</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation>Refés %1</translation>
    </message>
    <message>
        <source>Redo</source>
        <comment>Default text for redo action</comment>
        <translation>Refés</translation>
    </message>
</context>
<context>
    <name>QUnicodeControlCharacterMenu</name>
    <message>
        <source>LRM Left-to-right mark</source>
        <translation>Marca d&apos;esquerra a dreta (LRM)</translation>
    </message>
    <message>
        <source>RLM Right-to-left mark</source>
        <translation>Marca de dreta a esquerra (RLM)</translation>
    </message>
    <message>
        <source>ZWJ Zero width joiner</source>
        <translation>Connector d&apos;amplada zero (ZWJ)</translation>
    </message>
    <message>
        <source>ZWNJ Zero width non-joiner</source>
        <translation>Separador d&apos;amplada zero (ZWNJ)</translation>
    </message>
    <message>
        <source>ZWSP Zero width space</source>
        <translation>Espai d&apos;amplada zero (ZWSP)</translation>
    </message>
    <message>
        <source>LRE Start of left-to-right embedding</source>
        <translation>Inici d&apos;incrustació d&apos;esquerra a dreta (LRE)</translation>
    </message>
    <message>
        <source>RLE Start of right-to-left embedding</source>
        <translation>Inici d&apos;incrustació de dreta a esquerra (RLE)</translation>
    </message>
    <message>
        <source>LRO Start of left-to-right override</source>
        <translation>Inici de sobreescriptura d&apos;esquerra a dreta (LRO)</translation>
    </message>
    <message>
        <source>RLO Start of right-to-left override</source>
        <translation>Inici de sobreescriptura de dreta a esquerra (RLO)</translation>
    </message>
    <message>
        <source>PDF Pop directional formatting</source>
        <translation>Final de format direccional (PDF)</translation>
    </message>
    <message>
        <source>LRI Left-to-right isolate</source>
        <translation>Aïllada d&apos;esquerra a dreta (LRI)</translation>
    </message>
    <message>
        <source>RLI Right-to-left isolate</source>
        <translation>Aïllada de dreta a esquerra (RLI)</translation>
    </message>
    <message>
        <source>FSI First strong isolate</source>
        <translation>Aïllada intensa primera (FSI)</translation>
    </message>
    <message>
        <source>PDI Pop directional isolate</source>
        <translation>Final d&apos;aïllament direccional (PDI)</translation>
    </message>
    <message>
        <source>Insert Unicode control character</source>
        <translation>Insereix un caràcter de control Unicode</translation>
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>Què és això?</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <source>*</source>
        <translation>*</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Desfés</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Refés</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Re&amp;talla</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Copia la ubicació de l&apos;en&amp;llaç</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Enganxa</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
</context>
<context>
    <name>QWindowsDirect2DIntegration</name>
    <message>
        <source>Qt cannot load the direct2d platform plugin because the Direct2D version on this system is too old. The minimum system requirement for this platform plugin is Windows 7 SP1 with Platform Update.

The minimum Direct2D version required is %1.%2.%3.%4. The Direct2D version on this system is %5.%6.%7.%8.</source>
        <translation type="vanished">Les Qt no han pogut carregar el connector de la plataforma Direct2D perquè la versió del Direct2D en aquest sistema és massa antiga. El requisit mínim de sistema per aquest connector de plataforma és Windows 7 SP1 amb «Platform Update».

La versió mínima requerida del Direct2D és %1.%2.%3.%4. La versió del Direct2D en aquest sistema és %5.%6.%7.%8.</translation>
    </message>
    <message>
        <source>Qt cannot load the direct2d platform plugin because the Direct2D version on this system is too old. The minimum system requirement for this platform plugin is Windows 7 SP1 with Platform Update.

The minimum Direct2D version required is %1. The Direct2D version on this system is %2.</source>
        <translation>Les Qt no han pogut carregar el connector de la plataforma «direct2d» perquè la versió del Direct2D en aquest sistema és massa antiga. El requisit mínim de sistema per aquest connector de plataforma és Windows 7 SP1 amb «Platform Update».

La versió mínima requerida del Direct2D és %1. La versió del Direct2D en aquest sistema és %2.</translation>
    </message>
    <message>
        <source>Cannot load direct2d platform plugin</source>
        <translation>No s&apos;ha pogut carregar el connector de la plataforma «direct2d»</translation>
    </message>
</context>
<context>
    <name>QWizard</name>
    <message>
        <source>Go Back</source>
        <translation>Retrocedeix</translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Enrere</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continua</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Següent</translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Següent &gt;</translation>
    </message>
    <message>
        <source>Commit</source>
        <translation>Confirma</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Fet</translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation>&amp;Acaba</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>A&amp;juda</translation>
    </message>
</context>
<context>
    <name>QXml</name>
    <message>
        <source>no error occurred</source>
        <translation type="vanished">sense errors</translation>
    </message>
    <message>
        <source>error triggered by consumer</source>
        <translation type="vanished">error provocat pel consumidor</translation>
    </message>
    <message>
        <source>unexpected end of file</source>
        <translation type="vanished">fi de fitxer inesperat</translation>
    </message>
    <message>
        <source>more than one document type definition</source>
        <translation type="vanished">més d&apos;una definició de tipus de document</translation>
    </message>
    <message>
        <source>error occurred while parsing element</source>
        <translation type="vanished">hi ha hagut un error en analitzar un element</translation>
    </message>
    <message>
        <source>tag mismatch</source>
        <translation type="vanished">marcador desaparellat</translation>
    </message>
    <message>
        <source>error occurred while parsing content</source>
        <translation type="vanished">hi ha hagut un error en analitzar el contingut</translation>
    </message>
    <message>
        <source>unexpected character</source>
        <translation type="vanished">caràcter inesperat</translation>
    </message>
    <message>
        <source>invalid name for processing instruction</source>
        <translation type="vanished">nom d&apos;instrucció de procés no vàlid</translation>
    </message>
    <message>
        <source>version expected while reading the XML declaration</source>
        <translation type="vanished">s&apos;esperava una versió en llegir la declaració XML</translation>
    </message>
    <message>
        <source>wrong value for standalone declaration</source>
        <translation type="vanished">valor erroni per a la declaració autònoma</translation>
    </message>
    <message>
        <source>encoding declaration or standalone declaration expected while reading the XML declaration</source>
        <translation type="vanished">s&apos;esperava una declaració de codificació o una declaració autònoma en llegir la declaració XML</translation>
    </message>
    <message>
        <source>standalone declaration expected while reading the XML declaration</source>
        <translation type="vanished">s&apos;esperava una declaració autònoma en llegir la declaració XML</translation>
    </message>
    <message>
        <source>error occurred while parsing document type definition</source>
        <translation type="vanished">hi ha hagut un error en analitzar la definició del tipus de document</translation>
    </message>
    <message>
        <source>letter is expected</source>
        <translation type="vanished">s&apos;esperava una lletra</translation>
    </message>
    <message>
        <source>error occurred while parsing comment</source>
        <translation type="vanished">hi ha hagut un error en analitzar un comentari</translation>
    </message>
    <message>
        <source>error occurred while parsing reference</source>
        <translation type="vanished">hi ha hagut un error en analitzar una referència</translation>
    </message>
    <message>
        <source>internal general entity reference not allowed in DTD</source>
        <translation type="vanished">al DTD no es permet una referència interna a una entitat general</translation>
    </message>
    <message>
        <source>external parsed general entity reference not allowed in attribute value</source>
        <translation type="vanished">al valor d&apos;atribut no es permet una referència a una entitat general analitzada externament</translation>
    </message>
    <message>
        <source>external parsed general entity reference not allowed in DTD</source>
        <translation type="vanished">al DTD no es permet una referència a una entitat general analitzada externament</translation>
    </message>
    <message>
        <source>unparsed entity reference in wrong context</source>
        <translation type="vanished">referència a una entitat no analitzada a un context erroni</translation>
    </message>
    <message>
        <source>recursive entities</source>
        <translation type="vanished">entitats recursives</translation>
    </message>
    <message>
        <source>error in the text declaration of an external entity</source>
        <translation type="vanished">error a la declaració de text d&apos;una entitat externa</translation>
    </message>
</context>
<context>
    <name>QXmlStream</name>
    <message>
        <source>Extra content at end of document.</source>
        <translation>Contingut extra al final del document.</translation>
    </message>
    <message>
        <source>Unexpected token while reading raw inner data.</source>
        <translation>Testimoni inesperat mentre es llegien dades internes en brut.</translation>
    </message>
    <message>
        <source>Invalid entity value.</source>
        <translation>Valor d&apos;entitat no vàlid.</translation>
    </message>
    <message>
        <source>Invalid XML character.</source>
        <translation>Caràcter XML no vàlid.</translation>
    </message>
    <message>
        <source>Sequence &apos;]]&gt;&apos; not allowed in content.</source>
        <translation>No es permet la seqüència «]]&gt;» al contingut.</translation>
    </message>
    <message>
        <source>Encountered incorrectly encoded content.</source>
        <translation>S&apos;ha trobat contingut codificat incorrectament.</translation>
    </message>
    <message>
        <source>Namespace prefix &apos;%1&apos; not declared</source>
        <translation>No s&apos;ha declarat el prefix «%1» d&apos;espai de noms</translation>
    </message>
    <message>
        <source>Illegal namespace declaration.</source>
        <translation>Declaració d&apos;espai de noms il·legal.</translation>
    </message>
    <message>
        <source>Attribute redefined.</source>
        <translation type="vanished">S&apos;ha redefinit l&apos;atribut.</translation>
    </message>
    <message>
        <source>Attribute &apos;%1&apos; redefined.</source>
        <translation>S&apos;ha redefinit l&apos;atribut «%1».</translation>
    </message>
    <message>
        <source>Unexpected character &apos;%1&apos; in public id literal.</source>
        <translation>Caràcter inesperat «%1» al literal d&apos;ID públic.</translation>
    </message>
    <message>
        <source>Invalid XML version string.</source>
        <translation>Cadena de versió de l&apos;XML no vàlida.</translation>
    </message>
    <message>
        <source>Unsupported XML version.</source>
        <translation>Versió no admesa de l&apos;XML.</translation>
    </message>
    <message>
        <source>The standalone pseudo attribute must appear after the encoding.</source>
        <translation>Els pseudoatributs autònoms han d&apos;aparèixer després de la codificació.</translation>
    </message>
    <message>
        <source>%1 is an invalid encoding name.</source>
        <translation>%1 no és un nom de codificació vàlid.</translation>
    </message>
    <message>
        <source>Encoding %1 is unsupported</source>
        <translation>La codificació %1 no està admesa</translation>
    </message>
    <message>
        <source>Standalone accepts only yes or no.</source>
        <translation>L&apos;autònom només accepta sí o no.</translation>
    </message>
    <message>
        <source>Invalid attribute in XML declaration: %1 = %2</source>
        <translation>Atribut no vàlid a la declaració de l&apos;XML: %1 = %2</translation>
    </message>
    <message>
        <source>An I/O error occurred while writing</source>
        <translation>Hi ha hagut un error d&apos;E/S en escriure</translation>
    </message>
    <message>
        <source>An encoding error occurred while writing</source>
        <translation>Hi ha hagut un error de codificació en escriure</translation>
    </message>
    <message>
        <source>Encountered an invalid XML 1.0 character while writing</source>
        <translation>S&apos;ha trobat un caràcter XML 1.0 no vàlid en escriure</translation>
    </message>
    <message>
        <source>An error occurred while writing</source>
        <translation>Hi ha hagut un error en escriure</translation>
    </message>
    <message>
        <source>Unexpected token type %1 in %2.</source>
        <translation>Tipus de testimoni inesperat %1 a %2.</translation>
    </message>
    <message>
        <source>Found second DTD token in %1.</source>
        <translation>S&apos;ha trobat un segon testimoni DTD a %1.</translation>
    </message>
    <message>
        <source>Invalid attribute in XML declaration.</source>
        <translation type="vanished">Atribut no vàlid a la declaració de l&apos;XML.</translation>
    </message>
    <message>
        <source>Premature end of document.</source>
        <translation>Final prematur del document.</translation>
    </message>
    <message>
        <source>Invalid document.</source>
        <translation>Document no vàlid.</translation>
    </message>
    <message>
        <source>Length of XML attribute name exceeds implementation limits (4KiB characters).</source>
        <translation>La longitud del nom de l&apos;atribut XML excedeix els límits d&apos;implementació (4 KiB de caràcters).</translation>
    </message>
    <message>
        <source>&apos;%1&apos;</source>
        <comment>expected</comment>
        <extracomment>&apos;&lt;first option&gt;&apos;</extracomment>
        <translation>«%1»</translation>
    </message>
    <message>
        <source>%1 or &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;first option&gt;, &apos;&lt;second option&gt;&apos;</extracomment>
        <translation>%1 o «%2»</translation>
    </message>
    <message>
        <source>%1, &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;options so far&gt;, &apos;&lt;next option&gt;&apos;</extracomment>
        <translation>%1, «%2»</translation>
    </message>
    <message>
        <source>%1, or &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;options so far&gt;, or &apos;&lt;final option&gt;&apos;</extracomment>
        <translation>%1, o «%2»</translation>
    </message>
    <message>
        <source>Expected %1, but got &apos;%2&apos;.</source>
        <translation>S&apos;esperava %1, però s&apos;ha obtingut «%2».</translation>
    </message>
    <message>
        <source>Unexpected &apos;%1&apos;.</source>
        <translation>«%1» inesperat.</translation>
    </message>
    <message>
        <source>Expected </source>
        <translation type="vanished">S&apos;esperava </translation>
    </message>
    <message>
        <source>, but got &apos;</source>
        <translation type="vanished">, però s&apos;ha trobat &apos;</translation>
    </message>
    <message>
        <source>Unexpected &apos;</source>
        <translation type="vanished">No s&apos;esperava &apos;</translation>
    </message>
    <message>
        <source>Expected character data.</source>
        <translation>S&apos;esperava un caràcter de dades.</translation>
    </message>
    <message>
        <source>Recursive entity detected.</source>
        <translation type="vanished">S&apos;ha detectat una entitat recursiva.</translation>
    </message>
    <message>
        <source>Self-referencing entity detected.</source>
        <translation>S&apos;ha detectat una entitat autoreferent.</translation>
    </message>
    <message>
        <source>Entity expands to more characters than the entity expansion limit.</source>
        <translation>L&apos;entitat s&apos;expandeix a més caràcters que el límit d&apos;expansió de l&apos;entitat.</translation>
    </message>
    <message>
        <source>Start tag expected.</source>
        <translation>S&apos;esperava un marcador inicial.</translation>
    </message>
    <message>
        <source>NDATA in parameter entity declaration.</source>
        <translation>NDATA en paràmetre de declaració d&apos;entitat.</translation>
    </message>
    <message>
        <source>XML declaration not at start of document.</source>
        <translation>La declaració XML no és a l&apos;inici del document.</translation>
    </message>
    <message>
        <source>%1 is an invalid processing instruction name.</source>
        <translation>%1 és un nom d&apos;instrucció de procés no vàlid.</translation>
    </message>
    <message>
        <source>Invalid processing instruction name.</source>
        <translation>Nom d&apos;instrucció de procés no vàlid.</translation>
    </message>
    <message>
        <source>%1 is an invalid PUBLIC identifier.</source>
        <translation>%1 és un identificador PUBLIC no vàlid.</translation>
    </message>
    <message>
        <source>Invalid XML name.</source>
        <translation>Nom XML no vàlid.</translation>
    </message>
    <message>
        <source>Opening and ending tag mismatch.</source>
        <translation>Marcadors d&apos;obertura i tancament desaparellats.</translation>
    </message>
    <message>
        <source>Entity &apos;%1&apos; not declared.</source>
        <translation>Entitat «%1» no declarada.</translation>
    </message>
    <message>
        <source>Reference to unparsed entity &apos;%1&apos;.</source>
        <translation>Referència a entitat no analitzada «%1».</translation>
    </message>
    <message>
        <source>Reference to external entity &apos;%1&apos; in attribute value.</source>
        <translation>Referència a entitat externa «%1» en un valor d&apos;atribut.</translation>
    </message>
    <message>
        <source>Invalid character reference.</source>
        <translation>Referència de caràcter no vàlid.</translation>
    </message>
</context>
<context>
    <name>QAxSelect</name>
    <message>
        <source>Select ActiveX Control</source>
        <translation>Selecció de control ActiveX</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <source>COM &amp;Object:</source>
        <translation>&amp;Objecte COM:</translation>
    </message>
    <message>
        <source>Sandboxing:</source>
        <translation>Entorn protegit:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nom:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipus:</translation>
    </message>
    <message>
        <source>In process</source>
        <translation>En procés</translation>
    </message>
    <message>
        <source>Out of process</source>
        <translation>Fora de procés</translation>
    </message>
    <message>
        <source>CLSID:</source>
        <translation>CLSID:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Clau:</translation>
    </message>
    <message>
        <source>Word&amp;nbsp;size:</source>
        <translation>Mida&amp;nbsp;de&amp;nbsp;paraula:</translation>
    </message>
    <message>
        <source>DLL:</source>
        <translation>DLL:</translation>
    </message>
    <message>
        <source>Binary:</source>
        <translation>Binari:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Versió:</translation>
    </message>
</context>
<context>
    <name>QFactoryLoader</name>
    <message>
        <source>Invalid metadata version</source>
        <translation>Versió no vàlida de les metadades</translation>
    </message>
    <message>
        <source>Metadata parsing error: %1</source>
        <translation>Error en analitzar les metadades: %1</translation>
    </message>
    <message>
        <source>Unexpected metadata contents</source>
        <translation>Contingut inesperat de les metadades</translation>
    </message>
</context>
<context>
    <name>QAbstractFileIconProvider</name>
    <message>
        <source>Drive</source>
        <translation>Unitat</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fitxer</translation>
    </message>
    <message>
        <source>File Folder</source>
        <comment>Match Windows Explorer</comment>
        <translation>Carpeta de fitxers</translation>
    </message>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation>Carpeta</translation>
    </message>
    <message>
        <source>Alias</source>
        <comment>macOS Finder</comment>
        <translation>Àlies</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <comment>All other platforms</comment>
        <translation>Drecera</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
</context>
<context>
    <name>QCocoaMenu</name>
    <message>
        <source>Edit</source>
        <translation type="vanished">Edita</translation>
    </message>
</context>
<context>
    <name>quiaccessibilityelement</name>
    <message>
        <source>checked</source>
        <translation>activat</translation>
    </message>
    <message>
        <source>unchecked</source>
        <translation>desactivat</translation>
    </message>
</context>
<context>
    <name>QCocoaMenuBar</name>
    <message>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
</context>
<context>
    <name>QMimerSQL</name>
    <message>
        <source>No Mimer SQL error for code %1</source>
        <translation>No hi ha cap error de l&apos;SQL del Mimer per al codi %1</translation>
    </message>
    <message>
        <source>Generic Mimer SQL error</source>
        <translation>Error genèric de l&apos;SQL del Mimer</translation>
    </message>
</context>
<context>
    <name>QMimerSQLResult</name>
    <message>
        <source>Could not get %1, column %2</source>
        <extracomment>Data type, column</extracomment>
        <translation>No s&apos;ha pogut obtenir %1, columna %2</translation>
    </message>
    <message>
        <source>Could not set %1, parameter %2</source>
        <extracomment>Data type, parameter</extracomment>
        <translation>No s&apos;ha pogut establir %1, paràmetre %2</translation>
    </message>
    <message>
        <source>Could not close cursor</source>
        <translation>No s&apos;ha pogut tancar el cursor</translation>
    </message>
    <message>
        <source>Could not close statement</source>
        <translation>No s&apos;ha pogut tancar la sentència</translation>
    </message>
    <message>
        <source>Fetch did not succeed</source>
        <translation>No s&apos;ha pogut recuperar</translation>
    </message>
    <message>
        <source>Fetch first did not succeed</source>
        <translation>No s&apos;ha pogut recuperar el primer</translation>
    </message>
    <message>
        <source>Could not fetch next row</source>
        <translation>No s&apos;ha pogut recuperar la columna següent</translation>
    </message>
    <message>
        <source>Unknown data type %1</source>
        <translation>Tipus de dada desconeguda %1</translation>
    </message>
    <message>
        <source>Could not check null, column %1</source>
        <translation>No s&apos;ha pogut comprovar si és nul, columna %1</translation>
    </message>
    <message>
        <source>Could not prepare/execute statement</source>
        <translation>No s&apos;ha pogut preparar/executar la sentència</translation>
    </message>
    <message>
        <source>Wrong number of parameters</source>
        <translation>Nombre erroni de paràmetres</translation>
    </message>
    <message>
        <source>Unknown datatype, parameter %1</source>
        <translation>Tipus de dada desconeguda, paràmetre %1</translation>
    </message>
    <message>
        <source>Could not execute statement/open cursor</source>
        <translation>No s&apos;ha pogut executar la sentència/obrir el cursor</translation>
    </message>
    <message>
        <source>Only input parameters can be used in batch operations</source>
        <translation>Només es poden utilitzar paràmetres d&apos;entrada en operacions per lots</translation>
    </message>
    <message>
        <source>Could not add batch %1</source>
        <extracomment>%1 is the batch number</extracomment>
        <translation>No s&apos;ha pogut afegir el lot %1</translation>
    </message>
    <message>
        <source>Could not execute batch</source>
        <translation>No s&apos;ha pogut executar el lot</translation>
    </message>
</context>
<context>
    <name>QMimerSQLResult:</name>
    <message>
        <source>Fetch last did not succeed</source>
        <translation>No s&apos;ha pogut recuperar l&apos;últim</translation>
    </message>
    <message>
        <source>Column %1 out of range</source>
        <translation>La columna %1 està fora de l&apos;interval</translation>
    </message>
</context>
<context>
    <name>QMimerSQLDriver</name>
    <message>
        <source>Could not connect to database</source>
        <translation>No s&apos;ha pogut connectar a la base de dades</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>La transacció no ha pogut iniciar-se</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>La transacció no ha pogut confirmar-se</translation>
    </message>
    <message>
        <source>Could not roll back transaction</source>
        <translation>La transacció no ha pogut desfer-se</translation>
    </message>
</context>
<context>
    <name>QMimeType</name>
    <message>
        <source>Empty document</source>
        <extracomment>application/x-zerosize</extracomment>
        <translation>document buit</translation>
    </message>
    <message>
        <source>Desktop file</source>
        <extracomment>application/x-desktop</extracomment>
        <translation>fitxer «desktop»</translation>
    </message>
    <message>
        <source>Qt Markup Language file</source>
        <extracomment>text/x-qml</extracomment>
        <translation>fitxer de llenguatge de marcatge de Qt</translation>
    </message>
    <message>
        <source>Compressed postscript</source>
        <extracomment>application/x-gzpostscript</extracomment>
        <translation>Postscript comprimit</translation>
    </message>
    <message>
        <source>Core dump</source>
        <extracomment>application/x-core</extracomment>
        <translation>bolcat de nucli</translation>
    </message>
    <message>
        <source>BZip2 compressed tar file</source>
        <extracomment>application/x-bzip2-compressed-tar</extracomment>
        <translation>fitxer «tar» comprimit amb BZip2</translation>
    </message>
    <message>
        <source>Directory</source>
        <extracomment>inode/directory</extracomment>
        <translation>directori</translation>
    </message>
    <message>
        <source>Windows Batch / Command File</source>
        <extracomment>application/x-bat</extracomment>
        <translation>fitxer de lots / ordres de Windows</translation>
    </message>
    <message>
        <source>BizAgi Process Modeler</source>
        <extracomment>application/bizagi-modeler</extracomment>
        <translation>modelador de processos BizAgi</translation>
    </message>
    <message>
        <source>Concise Binary Object Representation container</source>
        <extracomment>application/cbor</extracomment>
        <translation>contenidor de representació concisa d&apos;objectes binaris</translation>
    </message>
    <message>
        <source>CorelDraw</source>
        <extracomment>application/coreldraw</extracomment>
        <translation>CorelDraw</translation>
    </message>
    <message>
        <source>DICOM medical imaging data</source>
        <extracomment>application/dicom</extracomment>
        <translation>dades d&apos;imatges mèdiques DICOM</translation>
    </message>
    <message>
        <source>Darwin Information Typing Architecture</source>
        <extracomment>application/dita+xml</extracomment>
        <translation>arquitectura Darwin de transcripció d&apos;informació</translation>
    </message>
    <message>
        <source>DVD information file</source>
        <extracomment>application/x-dvd-ifo</extracomment>
        <translation>fitxer d&apos;informació de DVD</translation>
    </message>
    <message>
        <source>EBU-STL subtitles</source>
        <extracomment>application/x-ebu-stl</extracomment>
        <translation>subtítols EBU-STL</translation>
    </message>
    <message>
        <source>Electronic Publication</source>
        <extracomment>application/epub+zip</extracomment>
        <translation>publicació electrònica</translation>
    </message>
    <message>
        <source>Flexible Image Transport System</source>
        <extracomment>application/fits</extracomment>
        <translation>sistema flexible de transport d&apos;imatges</translation>
    </message>
    <message>
        <source>Adobe Illustrator Artwork</source>
        <extracomment>application/illustrator</extracomment>
        <translation>Illustrator Artwork d&apos;Adobe</translation>
    </message>
    <message>
        <source>Adobe Illustrator Artwork -- the older postscript based AI files</source>
        <extracomment>application/illustrator+ps</extracomment>
        <translation>Illustrator Artwork d&apos;Adobe -- fitxers antics d&apos;IA basats en postscript</translation>
    </message>
    <message>
        <source>Windows setup INFormation</source>
        <extracomment>application/inf</extracomment>
        <translation>INFormació de configuració de Windows</translation>
    </message>
    <message>
        <source>Java Archive</source>
        <extracomment>application/java-archive</extracomment>
        <translation>arxiu Java</translation>
    </message>
    <message>
        <source>JavaScript Source Code</source>
        <extracomment>text/javascript</extracomment>
        <translation>codi font de JavaScript</translation>
    </message>
    <message>
        <source>Web Application Manifest file</source>
        <extracomment>application/manifest+json</extracomment>
        <translation>fitxer de manifest d&apos;aplicació web</translation>
    </message>
    <message>
        <source>Java Class File</source>
        <extracomment>application/java-vm</extracomment>
        <translation>fitxers de classe Java</translation>
    </message>
    <message>
        <source>Mach-O Universal</source>
        <extracomment>application/x-mach-o-universal</extracomment>
        <translation>Mach-O Universal</translation>
    </message>
    <message>
        <source>Java Native Library for OSX</source>
        <extracomment>application/x-java-jnilib</extracomment>
        <translation>biblioteca nativa de Java d&apos;OSX</translation>
    </message>
    <message>
        <source>Java hprof text file</source>
        <extracomment>application/vnd.java.hprof 
----------
application/vnd.java.hprof.text</extracomment>
        <translation>fitxer de text «hprof» de Java</translation>
    </message>
    <message>
        <source>Wolfram Mathematica</source>
        <extracomment>application/mathematica</extracomment>
        <translation>Mathematica de Wolfram</translation>
    </message>
    <message>
        <source>Wolfram Language</source>
        <extracomment>application/vnd.wolfram.wl</extracomment>
        <translation>llenguatge Wolfram</translation>
    </message>
    <message>
        <source>Adobe MIF File</source>
        <extracomment>application/vnd.mif</extracomment>
        <translation>fitxer MIF d&apos;Adobe</translation>
    </message>
    <message>
        <source>QuickTime container format</source>
        <extracomment>application/quicktime</extracomment>
        <translation>format de contenidor QuickTime</translation>
    </message>
    <message>
        <source>MP4 container format</source>
        <extracomment>application/mp4</extracomment>
        <translation>format de contenidor MP4</translation>
    </message>
    <message>
        <source>Microsoft Word Document</source>
        <extracomment>application/msword</extracomment>
        <translation>document de Microsoft Word</translation>
    </message>
    <message>
        <source>Microsoft Word 2 Document</source>
        <extracomment>application/msword2</extracomment>
        <translation>document de Microsoft Word 2</translation>
    </message>
    <message>
        <source>Microsoft Word 5 Document</source>
        <extracomment>application/msword5</extracomment>
        <translation>document de Microsoft Word 5</translation>
    </message>
    <message>
        <source>OneNote Package</source>
        <extracomment>application/onenote; format=package</extracomment>
        <translation>paquet OneNote</translation>
    </message>
    <message>
        <source>Portable Document Format</source>
        <extracomment>application/pdf</extracomment>
        <translation>format de document portable</translation>
    </message>
    <message>
        <source>PostScript</source>
        <extracomment>application/postscript</extracomment>
        <translation>PostScript</translation>
    </message>
    <message>
        <source>Excel 2003 xml format, pre-ooxml</source>
        <extracomment>application/vnd.ms-spreadsheetml</extracomment>
        <translation>format XML d&apos;Excel 2003, pre-ooxml</translation>
    </message>
    <message>
        <source>Word 2003 xml format, pre-ooxml</source>
        <extracomment>application/vnd.ms-wordml</extracomment>
        <translation>format XML de Word 2003, pre-ooxml</translation>
    </message>
    <message>
        <source>Word 2006 xml format, pre-ooxml</source>
        <extracomment>application/vnd.ms-word2006ml</extracomment>
        <translation>format XML de Word 2006, pre-ooxml</translation>
    </message>
    <message>
        <source>XML syntax for RDF graphs</source>
        <extracomment>application/rdf+xml</extracomment>
        <translation>sintaxi XML per a gràfics RDF</translation>
    </message>
    <message>
        <source>Rich Text Format File</source>
        <extracomment>application/rtf</extracomment>
        <translation>fitxer de format de text enriquit</translation>
    </message>
    <message>
        <source>Sereal binary serialization format</source>
        <extracomment>application/sereal</extracomment>
        <translation>format de serialització binari Sereal</translation>
    </message>
    <message>
        <source>SMIL Multimedia</source>
        <extracomment>application/smil+xml</extracomment>
        <translation>multimèdia SMIL</translation>
    </message>
    <message>
        <source>SolidWorks CAD program</source>
        <extracomment>application/sldworks</extracomment>
        <translation>programa CAD de SolidWorks</translation>
    </message>
    <message>
        <source>Password Protected iWorks File</source>
        <extracomment>application/x-tika-iworks-protected</extracomment>
        <translation>fitxer iWorks protegit amb contrasenya</translation>
    </message>
    <message>
        <source>web archive frictionless zip</source>
        <extracomment>application/x-wacz</extracomment>
        <translation>zip frictionless d&apos;arxiu web</translation>
    </message>
    <message>
        <source>frictionless data package zip package</source>
        <extracomment>application/x-vnd.datapackage+zip</extracomment>
        <translation>paquet zip de paquet de dades frictionless</translation>
    </message>
    <message>
        <source>frictionless data package - standalong datapackage.json</source>
        <extracomment>application/x-vnd.datapackage+json</extracomment>
        <translation>paquet de dades frictionless - datapackage.json autònom</translation>
    </message>
    <message>
        <source>frictionless data package - gzip of standalone datapackage.json</source>
        <extracomment>application/x-vnd.datapackage+gz</extracomment>
        <translation>paquet de dades frictionless - gzip de datapackage.json autònom</translation>
    </message>
    <message>
        <source>digilite.eu Prolights configuration file</source>
        <extracomment>application/vnd.digilite.prolights</extracomment>
        <translation>fitxer de configuració Prolights de digilite.eu</translation>
    </message>
    <message>
        <source>Extended Associated Signature Container</source>
        <extracomment>application/vnd.etsi.asic-e+zip</extracomment>
        <translation>contenidor de signatura associada ampliada</translation>
    </message>
    <message>
        <source>Simple Associated Signature Container</source>
        <extracomment>application/vnd.etsi.asic-s+zip</extracomment>
        <translation>contenidor de signatura associada simple</translation>
    </message>
    <message>
        <source>Forms Data Format</source>
        <extracomment>application/vnd.fdf</extracomment>
        <translation>format de dades Forms</translation>
    </message>
    <message>
        <source>Keyhole Markup Language</source>
        <extracomment>application/vnd.google-earth.kml+xml</extracomment>
        <translation>llenguatge de marcatge Keyhole</translation>
    </message>
    <message>
        <source>XML syntax for IPTC NewsMessages</source>
        <extracomment>application/vnd.iptc.g2.newsmessage+xml</extracomment>
        <translation>sintaxi XML per a IPTC NewsMessages</translation>
    </message>
    <message>
        <source>KChart File</source>
        <extracomment>application/vnd.kde.kchart</extracomment>
        <translation>fitxer de KChart</translation>
    </message>
    <message>
        <source>KPresenter File</source>
        <extracomment>application/vnd.kde.kpresenter</extracomment>
        <translation>fitxer de KPresenter</translation>
    </message>
    <message>
        <source>KSpread File</source>
        <extracomment>application/vnd.kde.kspread</extracomment>
        <translation>fitxer de KSpread</translation>
    </message>
    <message>
        <source>KWord File</source>
        <extracomment>application/vnd.kde.kword</extracomment>
        <translation>fitxer de KWord</translation>
    </message>
    <message>
        <source>SSEYO Koan File</source>
        <extracomment>application/vnd.koan</extracomment>
        <translation>fitxer SSEYO Koan</translation>
    </message>
    <message>
        <source>Lotus 1-2-3</source>
        <extracomment>application/vnd.lotus-1-2-3</extracomment>
        <translation>Lotus 1-2-3</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 1</source>
        <extracomment>application/vnd.lotus-1-2-3;version=1</extracomment>
        <translation>Lotus 1-2-3, versió 1</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 2</source>
        <extracomment>application/vnd.lotus-1-2-3;version=2</extracomment>
        <translation>Lotus 1-2-3, versió 2</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 3</source>
        <extracomment>application/vnd.lotus-1-2-3;version=3</extracomment>
        <translation>Lotus 1-2-3, versió 3</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 4-5</source>
        <extracomment>application/vnd.lotus-1-2-3;version=4</extracomment>
        <translation>Lotus 1-2-3, versió 4-5</translation>
    </message>
    <message>
        <source>Lotus 1-2-3, version 97/9.x</source>
        <extracomment>application/vnd.lotus-1-2-3;version=97+9.x</extracomment>
        <translation>Lotus 1-2-3, versió 97/9.x</translation>
    </message>
    <message>
        <source>FrameMaker Interchange Format</source>
        <extracomment>application/vnd.mif</extracomment>
        <translation>format d&apos;intercanvi de FrameMaker</translation>
    </message>
    <message>
        <source>MindManager</source>
        <extracomment>application/vnd.mindjet.mindmanager</extracomment>
        <translation>MindManager</translation>
    </message>
    <message>
        <source>Microsoft Excel Spreadsheet</source>
        <extracomment>application/vnd.ms-excel</extracomment>
        <translation>full de càlcul de Microsoft Excel</translation>
    </message>
    <message>
        <source>Office Open XML Workbook Add-in (macro-enabled)</source>
        <extracomment>application/vnd.ms-excel.addin.macroenabled.12</extracomment>
        <translation>complement de llibre de treball d&apos;Office Open XML (amb macros)</translation>
    </message>
    <message>
        <source>Office Open XML Workbook (macro-enabled)</source>
        <extracomment>application/vnd.ms-excel.sheet.macroenabled.12</extracomment>
        <translation>llibre de treball d&apos;Office Open XML (amb macros)</translation>
    </message>
    <message>
        <source>Microsoft Excel 2007 Binary Spreadsheet</source>
        <extracomment>application/vnd.ms-excel.sheet.binary.macroenabled.12</extracomment>
        <translation>full de càlcul binari de Microsoft Excel 2007</translation>
    </message>
    <message>
        <source>Microsoft Excel 4 Worksheet</source>
        <extracomment>application/vnd.ms-excel.sheet.4</extracomment>
        <translation>full de treball de Microsoft Excel 4</translation>
    </message>
    <message>
        <source>Microsoft Excel 4 Workspace</source>
        <extracomment>application/vnd.ms-excel.workspace.4</extracomment>
        <translation>espai de treball de Microsoft Excel 4</translation>
    </message>
    <message>
        <source>Microsoft Excel 3 Worksheet</source>
        <extracomment>application/vnd.ms-excel.sheet.3</extracomment>
        <translation>full de treball de Microsoft Excel 3</translation>
    </message>
    <message>
        <source>Microsoft Excel 3 Workspace</source>
        <extracomment>application/vnd.ms-excel.workspace.3</extracomment>
        <translation>espai de treball de Microsoft Excel 3</translation>
    </message>
    <message>
        <source>Microsoft Excel 2 Worksheet</source>
        <extracomment>application/vnd.ms-excel.sheet.2</extracomment>
        <translation>full de treball de Microsoft Excel 2</translation>
    </message>
    <message>
        <source>Microsoft Outlook Message</source>
        <extracomment>application/vnd.ms-outlook</extracomment>
        <translation>missatge de Microsoft Outlook</translation>
    </message>
    <message>
        <source>Outlook Personal Folders File Format</source>
        <extracomment>application/vnd.ms-outlook-pst</extracomment>
        <translation>format de fitxer de carpetes personals d&apos;Outlook</translation>
    </message>
    <message>
        <source>3D manufacturing format</source>
        <extracomment>application/vnd.ms-package.3dmanufacturing-3dmodel+xml</extracomment>
        <translation>format de manufactura 3D</translation>
    </message>
    <message>
        <source>Microsoft Powerpoint Presentation</source>
        <extracomment>application/vnd.ms-powerpoint</extracomment>
        <translation>presentació de Microsoft Powerpoint</translation>
    </message>
    <message>
        <source>Office Open XML Presentation Add-in (macro-enabled)</source>
        <extracomment>application/vnd.ms-powerpoint.addin.macroenabled.12</extracomment>
        <translation>complement de presentació d&apos;Office Open XML (amb macros)</translation>
    </message>
    <message>
        <source>Office Open XML Presentation (macro-enabled)</source>
        <extracomment>application/vnd.ms-powerpoint.presentation.macroenabled.12</extracomment>
        <translation>presentació d&apos;Office Open XML (amb macros)</translation>
    </message>
    <message>
        <source>Office Open XML Presentation Slideshow (macro-enabled)</source>
        <extracomment>application/vnd.ms-powerpoint.slideshow.macroenabled.12</extracomment>
        <translation>presentació de diapositives de presentació d&apos;Office Open XML (amb macros)</translation>
    </message>
    <message>
        <source>Office Open XML Document (macro-enabled)</source>
        <extracomment>application/vnd.ms-word.document.macroenabled.12</extracomment>
        <translation>document d&apos;Office d&apos;Open XML (amb macros)</translation>
    </message>
    <message>
        <source>Office Open XML Document Template (macro-enabled)</source>
        <extracomment>application/vnd.ms-word.template.macroenabled.12</extracomment>
        <translation>plantilla de document d&apos;Office Open XML (amb macros)</translation>
    </message>
    <message>
        <source>Open XML Paper Specification</source>
        <extracomment>application/vnd.ms-xpsdocument</extracomment>
        <translation>especificació d&apos;article d&apos;Open XML</translation>
    </message>
    <message>
        <source>Magic Shadow Archiver</source>
        <extracomment>application/vnd.msa-disk-image</extracomment>
        <translation>arxivador Magic Shadow</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Chart document</source>
        <extracomment>application/vnd.oasis.opendocument.chart</extracomment>
        <translation>OpenDocument v1.0: document de diagrama</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Chart document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.chart-template</extracomment>
        <translation>OpenDocument v1.0: document de diagrama utilitzat com a plantilla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Formula document</source>
        <extracomment>application/vnd.oasis.opendocument.formula</extracomment>
        <translation>OpenDocument v1.0: document de fórmula</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Formula document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.formula-template</extracomment>
        <translation>OpenDocument v1.0: document de fórmula utilitzat com a plantilla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Graphics document (Drawing)</source>
        <extracomment>application/vnd.oasis.opendocument.graphics</extracomment>
        <translation>OpenDocument v1.0: document de gràfic (Drawing)</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Graphics document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.graphics-template</extracomment>
        <translation>OpenDocument v1.0: document de gràfic utilitzat com a plantilla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Image document</source>
        <extracomment>application/vnd.oasis.opendocument.image</extracomment>
        <translation>OpenDocument v1.0: document d&apos;imatge</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Image document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.image-template</extracomment>
        <translation>OpenDocument v1.0: document d&apos;imatge utilitzat com a plantilla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Presentation document</source>
        <extracomment>application/vnd.oasis.opendocument.presentation</extracomment>
        <translation>OpenDocument v1.0: document de presentació</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Presentation document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.presentation-template</extracomment>
        <translation>OpenDocument v1.0: document de presentació utilitzat com a plantilla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Spreadsheet document</source>
        <extracomment>application/vnd.oasis.opendocument.spreadsheet</extracomment>
        <translation>OpenDocument v1.0: document de full de càlcul</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Spreadsheet document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.spreadsheet-template</extracomment>
        <translation>OpenDocument v1.0: document de full de càlcul utilitzat com a plantilla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Text document</source>
        <extracomment>application/vnd.oasis.opendocument.text</extracomment>
        <translation>OpenDocument v1.0: document de text</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Flat Text document</source>
        <extracomment>application/vnd.oasis.opendocument.tika.flat.document
----------
application/vnd.oasis.opendocument.flat.text</extracomment>
        <translation>OpenDocument v1.0: document de text pla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Flat Presentation document</source>
        <extracomment>application/vnd.oasis.opendocument.flat.presentation</extracomment>
        <translation>OpenDocument v1.0: document de presentació pla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Flat Spreadsheet document</source>
        <extracomment>application/vnd.oasis.opendocument.flat.spreadsheet</extracomment>
        <translation>OpenDocument v1.0: document de full de càlcul pla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Global Text document</source>
        <extracomment>application/vnd.oasis.opendocument.text-master</extracomment>
        <translation>OpenDocument v1.0: document de text global</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Text document used as template</source>
        <extracomment>application/vnd.oasis.opendocument.text-template</extracomment>
        <translation>OpenDocument v1.0: document de text utilitzat com a plantilla</translation>
    </message>
    <message>
        <source>OpenDocument v1.0: Text document used as template for HTML documents</source>
        <extracomment>application/vnd.oasis.opendocument.text-web</extracomment>
        <translation>OpenDocument v1.0: document de text utilitzat com a plantilla per a documents HTML</translation>
    </message>
    <message>
        <source>Office Open XML Presentation</source>
        <extracomment>application/vnd.openxmlformats-officedocument.presentationml.presentation</extracomment>
        <translation>presentació d&apos;Office Open XML</translation>
    </message>
    <message>
        <source>Office Open XML Presentation Template</source>
        <extracomment>application/vnd.openxmlformats-officedocument.presentationml.template</extracomment>
        <translation>plantilla de presentació d&apos;Office Open XML</translation>
    </message>
    <message>
        <source>Office Open XML Presentation Slideshow</source>
        <extracomment>application/vnd.openxmlformats-officedocument.presentationml.slideshow</extracomment>
        <translation>presentació de diapositives de presentació d&apos;Office Open XML</translation>
    </message>
    <message>
        <source>Office Open XML Workbook</source>
        <extracomment>application/vnd.openxmlformats-officedocument.spreadsheetml.sheet</extracomment>
        <translation>llibre de treball Office d&apos;Open XML</translation>
    </message>
    <message>
        <source>Office Open XML Workbook Template</source>
        <extracomment>application/vnd.openxmlformats-officedocument.spreadsheetml.template</extracomment>
        <translation>plantilla de llibre de treball d&apos;Office Open XML</translation>
    </message>
    <message>
        <source>Office Open XML Workbook Template (macro-enabled)</source>
        <extracomment>application/vnd.ms-excel.template.macroenabled.12</extracomment>
        <translation>plantilla de llibre de treball d&apos;Office Open XML (amb macros)</translation>
    </message>
    <message>
        <source>Office Open XML Document</source>
        <extracomment>application/vnd.openxmlformats-officedocument.wordprocessingml.document</extracomment>
        <translation>document d&apos;Office Open XML</translation>
    </message>
    <message>
        <source>Office Open XML Document Template</source>
        <extracomment>application/vnd.openxmlformats-officedocument.wordprocessingml.template</extracomment>
        <translation>plantilla de document d&apos;Office Open XML</translation>
    </message>
    <message>
        <source>SubRip (srt) subtitles</source>
        <extracomment>application/x-subrip</extracomment>
        <translation>subtítols SubRip (srt)</translation>
    </message>
    <message>
        <source>OpenOffice v1.0: Writer Document</source>
        <extracomment>application/vnd.sun.xml.writer</extracomment>
        <translation>OpenDocument v1.0: document de Writer</translation>
    </message>
    <message>
        <source>TCPDump pcap packet capture</source>
        <extracomment>application/vnd.tcpdump.pcap</extracomment>
        <translation>captura de paquet «pcap» de TCPDump</translation>
    </message>
    <message>
        <source>TCPDump next gen pcap packet capture</source>
        <extracomment>application/vnd.tcpdump.pcapng</extracomment>
        <translation>captura de paquet «pcap» de TCPDump «next gen»</translation>
    </message>
    <message>
        <source>TMX Translation Memory</source>
        <extracomment>application/x-tmx</extracomment>
        <translation>memòria de traducció TMX</translation>
    </message>
    <message>
        <source>Microsoft Visio Diagram</source>
        <extracomment>application/vnd.visio</extracomment>
        <translation>diagrama de Microsoft Visio</translation>
    </message>
    <message>
        <source>Office Open XML Visio Drawing (macro-free)</source>
        <extracomment>application/vnd.ms-visio.drawing</extracomment>
        <translation>dibuix d&apos;Office Open XML Visio (sense macros)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Template (macro-free)</source>
        <extracomment>application/vnd.ms-visio.template</extracomment>
        <translation>plantilla d&apos;Office Open XML Visio (sense macros)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Stencil (macro-free)</source>
        <extracomment>application/vnd.ms-visio.stencil</extracomment>
        <translation>trepa d&apos;Office Open XML Visio (sense macros)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Drawing (macro-enabled)</source>
        <extracomment>application/vnd.ms-visio.drawing.macroEnabled.12</extracomment>
        <translation>dibuix d&apos;Office Open XML Visio (amb macros)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Template (macro-enabled)</source>
        <extracomment>application/vnd.ms-visio.template.macroEnabled.12</extracomment>
        <translation>plantilla d&apos;Office Open XML Visio (amb macros)</translation>
    </message>
    <message>
        <source>Office Open XML Visio Stencil (macro-enabled)</source>
        <extracomment>application/vnd.ms-visio.stencil.macroEnabled.12</extracomment>
        <translation>trepa d&apos;Office Open XML Visio (amb macros)</translation>
    </message>
    <message>
        <source>Compiled WML Document</source>
        <extracomment>application/vnd.wap.wmlc</extracomment>
        <translation>document WML compilat</translation>
    </message>
    <message>
        <source>Compiled WML Script</source>
        <extracomment>application/vnd.wap.wmlscriptc</extracomment>
        <translation>script WML compilat</translation>
    </message>
    <message>
        <source>WordPerfect - Corel Word Processing</source>
        <extracomment>application/vnd.wordperfect</extracomment>
        <translation>WordPerfect - Corel Word Processing</translation>
    </message>
    <message>
        <source>WARC</source>
        <extracomment>application/warc
----------
application/warc+gz</extracomment>
        <translation>WARC</translation>
    </message>
    <message>
        <source>Web Assembly</source>
        <extracomment>application/wasm</extracomment>
        <translation>Web Assembly</translation>
    </message>
    <message>
        <source>Targa image data</source>
        <extracomment>image/x-tga</extracomment>
        <translation>dades d&apos;imatge Targa</translation>
    </message>
    <message>
        <source>AxCrypt</source>
        <extracomment>application/x-axcrypt</extracomment>
        <translation>AxCrypt</translation>
    </message>
    <message>
        <source>Adobe InDesign document</source>
        <extracomment>application/x-adobe-indesign</extracomment>
        <translation>document d&apos;Adobe InDesign</translation>
    </message>
    <message>
        <source>Flow Cytometry Standard File</source>
        <extracomment>application/vnd.isac.fcs</extracomment>
        <translation>fitxer estàndard Flow Cytometry</translation>
    </message>
    <message>
        <source>IDML</source>
        <extracomment>application/vnd.adobe.indesign-idml-package</extracomment>
        <translation>IDML</translation>
    </message>
    <message>
        <source>Adobe InDesign Interchange format</source>
        <extracomment>application/x-adobe-indesign-interchange</extracomment>
        <translation>format d&apos;intercanvi d&apos;Adobe InDesign</translation>
    </message>
    <message>
        <source>ASPRS Lidar Data Exchange Format</source>
        <extracomment>application/x-asprs</extracomment>
        <translation>format d&apos;intercanvi de dades Lidar d&apos;ASPRS</translation>
    </message>
    <message>
        <source>Berkeley DB</source>
        <extracomment>application/x-berkeley-db</extracomment>
        <translation>Berkeley DB</translation>
    </message>
    <message>
        <source>CD Audio</source>
        <extracomment>application/x-cdf</extracomment>
        <translation>CD d&apos;àudio</translation>
    </message>
    <message>
        <source>GNU tar Compressed File Archive (GNU Tape Archive)</source>
        <extracomment>application/x-gtar</extracomment>
        <translation>arxiu de fitxer comprimit «tar» de GNU (arxiu de cinta GNU)</translation>
    </message>
    <message>
        <source>Guitar Pro</source>
        <extracomment>application/x-guitar-pro</extracomment>
        <translation>Guitar Pro</translation>
    </message>
    <message>
        <source>Amiga Disk File</source>
        <extracomment>application/x-amiga-disk-format</extracomment>
        <translation>fitxer de disc Amiga</translation>
    </message>
    <message>
        <source>Bzip 2 UNIX Compressed File</source>
        <extracomment>application/x-bzip2</extracomment>
        <translation>fitxer comprimit Bzip 2 d&apos;UNIX</translation>
    </message>
    <message>
        <source>Virtual CD-ROM CD Image File</source>
        <extracomment>application/x-cdlink</extracomment>
        <translation>fitxer d&apos;imatge de CD de CD-ROM virtual</translation>
    </message>
    <message>
        <source>Chrome Extension Package</source>
        <extracomment>application/x-chrome-package</extracomment>
        <translation>paquet d&apos;extensió de Chrome</translation>
    </message>
    <message>
        <source>UNIX CPIO Archive</source>
        <extracomment>application/x-cpio</extracomment>
        <translation>arxiu CPIO d&apos;UNIX</translation>
    </message>
    <message>
        <source>Dalvik Executable Format</source>
        <extracomment>application/x-dex</extracomment>
        <translation>format executable Dalvik</translation>
    </message>
    <message>
        <source>Shockwave Movie</source>
        <extracomment>application/x-director</extracomment>
        <translation>pel·licula Shockwave</translation>
    </message>
    <message>
        <source>TeX Device Independent Document</source>
        <extracomment>application/x-dvi</extracomment>
        <translation>document TeX independent de dispositiu</translation>
    </message>
    <message>
        <source>Emacs Lisp bytecode</source>
        <extracomment>application/x-elc</extracomment>
        <translation>codi de bytes Lisp d&apos;Emacs</translation>
    </message>
    <message>
        <source>fat disk image; extensions: ima, img, dsk</source>
        <extracomment>application/x-fat-diskimage</extracomment>
        <translation>imatge de disk FAT; extensions: ima, img, dsk</translation>
    </message>
    <message>
        <source>KIllustrator File</source>
        <extracomment>application/x-killustrator</extracomment>
        <translation>fitxer de KIllustrator</translation>
    </message>
    <message>
        <source>Modified Maximum Method Digisonde Portable Sounder File format</source>
        <extracomment>application/x-mmm-digisonde</extracomment>
        <translation>format de fitxer Sounder portable amb el mètode màxim modificat</translation>
    </message>
    <message>
        <source>DOS/Windows executable (EXE)</source>
        <extracomment>application/x-dosexec</extracomment>
        <translation>executable DOS/Windows (EXE)</translation>
    </message>
    <message>
        <source>FileMaker Pro 7</source>
        <extracomment>application/x-filemaker</extracomment>
        <translation>FileMaker Pro 7</translation>
    </message>
    <message>
        <source>OpenType Font</source>
        <extracomment>application/x-font-otf</extracomment>
        <translation>OpenType Font</translation>
    </message>
    <message>
        <source>TrueType Font</source>
        <extracomment>application/x-font-ttf</extracomment>
        <translation>TrueType Font</translation>
    </message>
    <message>
        <source>Adobe Font Metric</source>
        <extracomment>application/x-font-adobe-metric</extracomment>
        <translation>Adobe Font Metric</translation>
    </message>
    <message>
        <source>Printer Font Metric</source>
        <extracomment>application/x-font-printer-metric</extracomment>
        <translation>Printer Font Metric</translation>
    </message>
    <message>
        <source>Foxmail Email File</source>
        <extracomment>application/x-foxmail</extracomment>
        <translation>fitxer de correu electrònic Foxmail</translation>
    </message>
    <message>
        <source>Macromedia FutureSplash File</source>
        <extracomment>application/x-futuresplash</extracomment>
        <translation>fitxer Macromedia FutureSplash</translation>
    </message>
    <message>
        <source>General Regularly-distributed Information in Binary form</source>
        <extracomment>application/x-grib</extracomment>
        <translation>informació general distribuïda normalment en forma binària</translation>
    </message>
    <message>
        <source>Gzip Compressed Archive</source>
        <extracomment>application/gzip</extracomment>
        <translation>arxiu comprimit Gzip</translation>
    </message>
    <message>
        <source>https://en.wikipedia.org/wiki/Zstandard</source>
        <extracomment>application/zstd</extracomment>
        <translation>https://en.wikipedia.org/wiki/Zstandard</translation>
    </message>
    <message>
        <source>ESRI Layer file</source>
        <extracomment>application/x-esri-layer</extracomment>
        <translation>fitxer de capa ESRI</translation>
    </message>
    <message>
        <source>Hierarchical Data Format File</source>
        <extracomment>application/x-hdf</extracomment>
        <translation>fitxer de format de dades jeràrquic</translation>
    </message>
    <message>
        <source>Hangul Word Processor File</source>
        <extracomment>application/x-hwp</extracomment>
        <translation>fitxer Hangul Word Processor</translation>
    </message>
    <message>
        <source>Hangul Word Processor File v5</source>
        <extracomment>application/x-hwp-v5</extracomment>
        <translation>fitxer Hangul Word Processor v5</translation>
    </message>
    <message>
        <source>Hangul Word Processor File, zip based</source>
        <extracomment>application/hwp+zip</extracomment>
        <translation>fitxer Hangul Word Processor, basat en zip</translation>
    </message>
    <message>
        <source>Apple iBooks Author publication format</source>
        <extracomment>application/x-ibooks+zip</extracomment>
        <translation>format de publicació iBooks Author d&apos;Apple</translation>
    </message>
    <message>
        <source>NV5 Geospatial Interactive Data Language Save File</source>
        <extracomment>application/x-idl-save-file</extracomment>
        <translation>fitxer desat de llenguatge de dades interactives geoespacials NV5</translation>
    </message>
    <message>
        <source>ARC</source>
        <extracomment>application/x-internet-archive</extracomment>
        <translation>ARC</translation>
    </message>
    <message>
        <source>ISA-Tab Investigation file</source>
        <extracomment>application/x-isatab-investigation</extracomment>
        <translation>fitxers d&apos;investigació ISA-Tab</translation>
    </message>
    <message>
        <source>ISA-Tab Study file</source>
        <extracomment>application/x-isatab</extracomment>
        <translation>fitxers d&apos;estudi ISA-Tab</translation>
    </message>
    <message>
        <source>ISA-Tab Assay file</source>
        <extracomment>application/x-isatab-assay</extracomment>
        <translation>fitxers d&apos;assaig ISA-Tab</translation>
    </message>
    <message>
        <source>ISO 9660 CD-ROM filesystem data</source>
        <extracomment>application/x-iso9660-image</extracomment>
        <translation>dades de sistema de fitxers de CD-ROM ISO 9660</translation>
    </message>
    <message>
        <source>Apple iTunes Binary Property List</source>
        <extracomment>application/x-itunes-bplist</extracomment>
        <translation>llista de propietats binària iTunes d&apos;Apple</translation>
    </message>
    <message>
        <source>Apple iOS IPA AppStore file</source>
        <extracomment>application/x-itunes-ipa</extracomment>
        <translation>fitxers d&apos;AppStore iOS IPA d&apos;Apple</translation>
    </message>
    <message>
        <source>JDF NMR Spectroscopy</source>
        <extracomment>application/x-jeol-jdf</extracomment>
        <translation>espectroscopis JDF NMR</translation>
    </message>
    <message>
        <source>Jigsaw Download</source>
        <extracomment>application/x-jigdo</extracomment>
        <translation>baixada Jigsaw</translation>
    </message>
    <message>
        <source>LaTeX Source Document</source>
        <extracomment>application/x-latex</extracomment>
        <translation>document de codi font LaTeX</translation>
    </message>
    <message>
        <source>First match LZ4 Frame</source>
        <extracomment>application/x-lz4</extracomment>
        <translation>First match LZ4 Frame</translation>
    </message>
    <message>
        <source>Lzip (LZMA) compressed archive</source>
        <extracomment>application/x-lzip</extracomment>
        <translation>arxiu comprimit Lzip (LZMA)</translation>
    </message>
    <message>
        <source>LZMA compressed archive</source>
        <extracomment>application/x-lzma</extracomment>
        <translation>arxiu comprimit LZMA</translation>
    </message>
    <message>
        <source>Mach-O</source>
        <extracomment>application/x-mach-o</extracomment>
        <translation>Mach-O</translation>
    </message>
    <message>
        <source>Mach-O relocatable object file</source>
        <extracomment>application/x-mach-o-object</extracomment>
        <translation>fitxer objecte reubicable de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O executable</source>
        <extracomment>application/x-mach-o-executable</extracomment>
        <translation>executable de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O fixed VM shared library</source>
        <extracomment>application/x-mach-o-fvmlib</extracomment>
        <translation>biblioteca compartida de VM fixada de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O core file</source>
        <extracomment>application/x-mach-o-core</extracomment>
        <translation>fitxer de nucli de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O preloaded executable</source>
        <extracomment>application/x-mach-o-preload</extracomment>
        <translation>executable precarregat de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O dynamic shared library</source>
        <extracomment>application/x-mach-o-dylib</extracomment>
        <translation>biblioteca compartida dinàmica de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O dynamic link editor</source>
        <extracomment>application/x-mach-o-dylinker</extracomment>
        <translation>editor d&apos;enllaç dinàmic de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O dynamic bundle</source>
        <extracomment>application/x-mach-o-bundle</extracomment>
        <translation>paquet dinàmic de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O shared library for static linking</source>
        <extracomment>application/x-mach-o-dylib-stub</extracomment>
        <translation>biblioteca compartida per a l&apos;enllaçat dinàmic de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O debug symbols file</source>
        <extracomment>application/x-mach-o-dsym</extracomment>
        <translation>fitxer de símbols de depuració de Mach-O</translation>
    </message>
    <message>
        <source>Mach-O kext bundle</source>
        <extracomment>application/x-mach-o-kext-bundle</extracomment>
        <translation>paquet kext de Mach-O</translation>
    </message>
    <message>
        <source>Apple Xcode Memgraph</source>
        <extracomment>application/x-memgraph</extracomment>
        <translation>Apple Xcode Memgraph</translation>
    </message>
    <message>
        <source>Mobipocket Ebook</source>
        <extracomment>application/x-mobipocket-ebook</extracomment>
        <translation>Mobipocket Ebook</translation>
    </message>
    <message>
        <source>MS-DOS compression szzd</source>
        <extracomment>application/x-ms-compress-szdd</extracomment>
        <translation>MS-DOS compressió szzd</translation>
    </message>
    <message>
        <source>Temporary files created by MSOffice applications</source>
        <extracomment>application/x-ms-owner</extracomment>
        <translation>fitxers temporals creats per les aplicacions MSOffice</translation>
    </message>
    <message>
        <source>Microsoft National Language Support</source>
        <extracomment>application/x-ms-nls</extracomment>
        <translation>Microsoft National Language Support</translation>
    </message>
    <message>
        <source>Microsoft Windows Installer</source>
        <extracomment>application/x-ms-installer</extracomment>
        <translation>instal·lador de Microsoft Windows</translation>
    </message>
    <message>
        <source>MySQL Table Definition (Format)</source>
        <extracomment>application/x-mysql-table-definition</extracomment>
        <translation>definició de taula MySQL (format)</translation>
    </message>
    <message>
        <source>MySQL MISAM Index</source>
        <extracomment>application/x-mysql-misam-index</extracomment>
        <translation>índex MISAM de MySQL</translation>
    </message>
    <message>
        <source>MySQL MISAM Compressed Index</source>
        <extracomment>application/x-mysql-misam-compressed-index</extracomment>
        <translation>índex comprimit MISAM de MySQL</translation>
    </message>
    <message>
        <source>MySQL MISAM Data</source>
        <extracomment>application/x-mysql-misam-data</extracomment>
        <translation>dades MISAM de MySQL</translation>
    </message>
    <message>
        <source>Nintendo Entertainment System ROM</source>
        <extracomment>application/x-nesrom</extracomment>
        <translation>ROM del sistema d&apos;entreteniment de Nintendo</translation>
    </message>
    <message>
        <source>Planetary Data System Version 3 format</source>
        <extracomment>application/x-pds</extracomment>
        <translation>format de Planetary Data System versió 3</translation>
    </message>
    <message>
        <source>Quattro Pro - Corel Spreadsheet (part of WordPerfect Office suite)</source>
        <extracomment>application/x-quattro-pro</extracomment>
        <translation>Quattro Pro - Corel Spreadsheet (part del paquet WordPerfect Office)</translation>
    </message>
    <message>
        <source>Quattro Pro for DOS, version 1-4</source>
        <extracomment>application/x-quattro-pro;version=1-4</extracomment>
        <translation>Quattro Pro per a DOS, versió 1-4</translation>
    </message>
    <message>
        <source>Quattro Pro for DOS, version 5</source>
        <extracomment>application/x-quattro-pro;version=5</extracomment>
        <translation>Quattro Pro per a DOS, versió 5</translation>
    </message>
    <message>
        <source>Quattro Pro for Windows, version 1, 5</source>
        <extracomment>application/x-quattro-pro;version=1+5</extracomment>
        <translation>Quattro Pro per a Windows, versió 1, 5</translation>
    </message>
    <message>
        <source>Quattro Pro for Windows, version 6</source>
        <extracomment>application/x-quattro-pro;version=6</extracomment>
        <translation>Quattro Pro per a Windows, versió 6</translation>
    </message>
    <message>
        <source>XQuery source code</source>
        <extracomment>application/xquery</extracomment>
        <translation>codi font XQuery</translation>
    </message>
    <message>
        <source>RAR archive</source>
        <extracomment>application/x-rar-compressed
----------
application/x-rar-compressed;version=4
----------
application/x-rar-compressed;version=5</extracomment>
        <translation>arxiu RAR</translation>
    </message>
    <message>
        <source>RedHat Package Manager</source>
        <extracomment>application/x-rpm</extracomment>
        <translation>gestor de paquets de RedHat</translation>
    </message>
    <message>
        <source>SAS Program</source>
        <extracomment>application/x-sas</extracomment>
        <translation>programa SAS</translation>
    </message>
    <message>
        <source>SAS Stored Program (DATA Step)</source>
        <extracomment>application/x-sas-program-data</extracomment>
        <translation>programa emmagatzemat SAS (pas STEP)</translation>
    </message>
    <message>
        <source>SAS Audit</source>
        <extracomment>application/x-sas-audit</extracomment>
        <translation>SAS Audit</translation>
    </message>
    <message>
        <source>SAS v6 Data Set</source>
        <extracomment>application/x-sas-data-v6</extracomment>
        <translation>conjunt de dades SAS v6</translation>
    </message>
    <message>
        <source>SAS Data Set</source>
        <extracomment>application/x-sas-data</extracomment>
        <translation>conjunt de dades SAS</translation>
    </message>
    <message>
        <source>SAS Data Set View</source>
        <extracomment>application/x-sas-view</extracomment>
        <translation>vista de conjunt de dades SAS</translation>
    </message>
    <message>
        <source>SAS Data Set Index</source>
        <extracomment>application/x-sas-data-index</extracomment>
        <translation>índex de conjunt de dades SAS</translation>
    </message>
    <message>
        <source>SAS Catalog</source>
        <extracomment>application/x-sas-catalog</extracomment>
        <translation>catàleg SAS</translation>
    </message>
    <message>
        <source>SAS Access Descriptor</source>
        <extracomment>application/x-sas-access</extracomment>
        <translation>descriptor d&apos;accés SAS</translation>
    </message>
    <message>
        <source>SAS FDB Consolidation Database File</source>
        <extracomment>application/x-sas-fdb</extracomment>
        <translation>fitxer de base de dades de consolidació FDB de SAS</translation>
    </message>
    <message>
        <source>SAS MDDB Multi-Dimensional Database File</source>
        <extracomment>application/x-sas-mddb</extracomment>
        <translation>fitxer de base de dades multidimensional MDDB de SAS</translation>
    </message>
    <message>
        <source>SAS DMDB Data Mining Database File</source>
        <extracomment>application/x-sas-dmdb</extracomment>
        <translation>fitxer de base de dades de mineria de dades DMDB de SAS</translation>
    </message>
    <message>
        <source>SAS Item Store (ItemStor) File</source>
        <extracomment>application/x-sas-itemstor</extracomment>
        <translation>fitxer Item Store (ItemStor) de SAS</translation>
    </message>
    <message>
        <source>SAS Utility</source>
        <extracomment>application/x-sas-utility</extracomment>
        <translation>utilitat SAS</translation>
    </message>
    <message>
        <source>SAS Permanent Utility</source>
        <extracomment>application/x-sas-putility</extracomment>
        <translation>utilitat permanent SAS</translation>
    </message>
    <message>
        <source>SAS Transport File</source>
        <extracomment>application/x-sas-transport</extracomment>
        <translation>fitxer de transport SAS</translation>
    </message>
    <message>
        <source>SAS Backup</source>
        <extracomment>application/x-sas-backup</extracomment>
        <translation>còpia de seguretat de SAS</translation>
    </message>
    <message>
        <source>SAS XPORT Transfer File</source>
        <extracomment>application/x-sas-xport</extracomment>
        <translation>fitxer de transferència XPORT de SAS</translation>
    </message>
    <message>
        <source>SPSS Data File</source>
        <extracomment>application/x-spss-sav</extracomment>
        <translation>fitxer de dades SPSS</translation>
    </message>
    <message>
        <source>UNIX/LINUX Shell Script</source>
        <extracomment>application/x-sh</extracomment>
        <translation>script d&apos;intèrpret d&apos;ordres UNIX/LINUX</translation>
    </message>
    <message>
        <source>ESRI Shapefiles</source>
        <extracomment>application/x-shapefile</extracomment>
        <translation>shapefiles ESRI</translation>
    </message>
    <message>
        <source>Adobe Flash</source>
        <extracomment>application/x-shockwave-flash</extracomment>
        <translation>Adobe Flash</translation>
    </message>
    <message>
        <source>Sibelius</source>
        <extracomment>application/x-sibelius</extracomment>
        <translation>Sibelius</translation>
    </message>
    <message>
        <source>Snappy Framed</source>
        <extracomment>application/x-snappy-framed</extracomment>
        <translation>Snappy Framed</translation>
    </message>
    <message>
        <source>Standard Formatted Data Units (SFDUs) data</source>
        <extracomment>application/x-sfdu</extracomment>
        <translation>dades Standard Formatted Data Units (SFDU)</translation>
    </message>
    <message>
        <source>TAP (ZX Spectrum)</source>
        <extracomment>application/x-spectrum-tzx</extracomment>
        <translation>TAP (ZX Spectrum)</translation>
    </message>
    <message>
        <source>Stata DTA Script</source>
        <extracomment>application/x-stata-do</extracomment>
        <translation>script Stata DTA</translation>
    </message>
    <message>
        <source>Stata DTA Dataset</source>
        <extracomment>application/x-stata-dta</extracomment>
        <translation>conjunt de dades Stata DTA</translation>
    </message>
    <message>
        <source>TeX Source</source>
        <extracomment>application/x-tex</extracomment>
        <translation>codi font TeX</translation>
    </message>
    <message>
        <source>TeX Virtual Font format</source>
        <extracomment>application/x-tex-virtual-font</extracomment>
        <translation>format TeX Virtual Font</translation>
    </message>
    <message>
        <source>Pre-OLE2 (Old) Microsoft Excel Worksheets</source>
        <extracomment>application/x-tika-old-excel</extracomment>
        <translation>fulls de càlcul de Microsoft Excel Pre-OLE2 (antic)</translation>
    </message>
    <message>
        <source>Password Protected OOXML File</source>
        <extracomment>application/x-tika-ooxml-protected</extracomment>
        <translation>fitxer OOXML protegit amb contrasenya</translation>
    </message>
    <message>
        <source>Visio OOXML File</source>
        <extracomment>application/x-tika-visio-ooxml</extracomment>
        <translation>fitxer Visio OOXML</translation>
    </message>
    <message>
        <source>Virtual PC Virtual Hard Disk</source>
        <extracomment>application/x-vhd</extracomment>
        <translation>disc dur virtual de Virtual PC</translation>
    </message>
    <message>
        <source>Virtual Disk Format</source>
        <extracomment>application/x-vmdk</extracomment>
        <translation>format de disc virtual</translation>
    </message>
    <message>
        <source>Java Keystore</source>
        <extracomment>application/x-java-keystore</extracomment>
        <translation>Java Keystore</translation>
    </message>
    <message>
        <source>XMind Pro</source>
        <extracomment>application/x-xmind</extracomment>
        <translation>XMind Pro</translation>
    </message>
    <message>
        <source>Zeno IMproved (ZIM)</source>
        <extracomment>application/x-zim</extracomment>
        <translation>Zeno IMproved (ZIM)</translation>
    </message>
    <message>
        <source>Extensible Markup Language</source>
        <extracomment>application/xml</extracomment>
        <translation>llenguatge de marcatge extensible</translation>
    </message>
    <message>
        <source>XML Document Type Definition</source>
        <extracomment>application/xml-dtd</extracomment>
        <translation>definició de tipus de document XML</translation>
    </message>
    <message>
        <source>XSL Format</source>
        <extracomment>application/xslfo+xml</extracomment>
        <translation>format XSL</translation>
    </message>
    <message>
        <source>XSL Transformations</source>
        <extracomment>application/xslt+xml</extracomment>
        <translation>transformacions XSL</translation>
    </message>
    <message>
        <source>XML Shareable Playlist Format</source>
        <extracomment>application/xspf+xml</extracomment>
        <translation>format de llista de reproducció compartible XML</translation>
    </message>
    <message>
        <source>Compressed Archive File</source>
        <extracomment>application/zip</extracomment>
        <translation>fitxer d&apos;arxiu comprimit</translation>
    </message>
    <message>
        <source>ZLIB Compressed Data Format</source>
        <extracomment>application/zlib</extracomment>
        <translation>format de dades comprimides ZLIB</translation>
    </message>
    <message>
        <source>7-zip archive</source>
        <extracomment>application/x-7z-compressed</extracomment>
        <translation>arxiu 7-zip</translation>
    </message>
    <message>
        <source>Dolby Digital Audio Compression File</source>
        <extracomment>audio/ac3</extracomment>
        <translation>fitxer de compressió d&apos;àudio digital Dolby</translation>
    </message>
    <message>
        <source>uLaw/AU Audio File</source>
        <extracomment>audio/basic</extracomment>
        <translation>fitxer d&apos;àudio uLaw/AU</translation>
    </message>
    <message>
        <source>Musical Instrument Digital Interface</source>
        <extracomment>audio/midi</extracomment>
        <translation>interfície digital d&apos;instrument musical</translation>
    </message>
    <message>
        <source>MPEG-1 Audio Layer 3</source>
        <extracomment>audio/mpeg</extracomment>
        <translation>àudio MPEG-1 Layer 3</translation>
    </message>
    <message>
        <source>Ogg Vorbis Audio</source>
        <extracomment>audio/ogg</extracomment>
        <translation>àudio Ogg Vorbis</translation>
    </message>
    <message>
        <source>Ogg Vorbis Codec Compressed WAV File</source>
        <extracomment>audio/vorbis</extracomment>
        <translation>fitxer WAV comprimit amb el còdec Ogg Vorbis</translation>
    </message>
    <message>
        <source>Portable Sound Format</source>
        <extracomment>audio/x-psf</extracomment>
        <translation>format de so portable</translation>
    </message>
    <message>
        <source>Slight Atari Player</source>
        <extracomment>audio/x-sap</extracomment>
        <translation>Slight Atari Player</translation>
    </message>
    <message>
        <source>Ogg Packaged Free Lossless Audio Codec</source>
        <extracomment>audio/x-oggflac</extracomment>
        <translation>còdec d&apos;àudio lliure sense pèrdua empaquetat amb Ogg</translation>
    </message>
    <message>
        <source>Ogg Packaged Unompressed WAV File</source>
        <extracomment>audio/x-oggpcm</extracomment>
        <translation>fitxer WAV sense comprimir empaquetat amb Ogg</translation>
    </message>
    <message>
        <source>Ogg Opus Codec Compressed WAV File</source>
        <extracomment>audio/opus</extracomment>
        <translation>fitxer WAV comprimit amb el còdec Opus Ogg</translation>
    </message>
    <message>
        <source>Ogg Speex Codec Compressed WAV File</source>
        <extracomment>audio/speex</extracomment>
        <translation>fitxer WAV comprimit amb el còdec Speex Ogg</translation>
    </message>
    <message>
        <source>Audio Interchange File Format</source>
        <extracomment>audio/x-aiff</extracomment>
        <translation>format de fitxer d&apos;intercanvi d&apos;àudio</translation>
    </message>
    <message>
        <source>Core Audio Format</source>
        <extracomment>audio/x-caf</extracomment>
        <translation>format d&apos;àudio core</translation>
    </message>
    <message>
        <source>Free Lossless Audio Codec</source>
        <extracomment>audio/x-flac</extracomment>
        <translation>còdec d&apos;àudio lliure sense pèrdua</translation>
    </message>
    <message>
        <source>MP3 Playlist File</source>
        <extracomment>audio/x-mpegurl</extracomment>
        <translation>fitxer de llista de reproducció de MP3</translation>
    </message>
    <message>
        <source>Real Audio</source>
        <extracomment>audio/x-pn-realaudio</extracomment>
        <translation>Real Audio</translation>
    </message>
    <message>
        <source>RealMedia Player Plug-in</source>
        <extracomment>audio/x-pn-realaudio-plugin</extracomment>
        <translation>connector de reproductor RealMedia</translation>
    </message>
    <message>
        <source>Brookhaven Protein Databank File</source>
        <extracomment>chemical/x-pdb</extracomment>
        <translation>fitxer de banc de dades de proteïnes Brookhaven</translation>
    </message>
    <message>
        <source>3D Studio (V1)</source>
        <extracomment>image/x-3ds</extracomment>
        <translation>3D Studio (V1)</translation>
    </message>
    <message>
        <source>ACES Image Container File</source>
        <extracomment>image/aces</extracomment>
        <translation>fitxer contenidor d&apos;imatge ACES</translation>
    </message>
    <message>
        <source>OS2 bitmap array</source>
        <extracomment>image/x-os2-graphics; charset=binary</extracomment>
        <translation>matriu de mapa de bits d&apos;OS2</translation>
    </message>
    <message>
        <source>Windows bitmap</source>
        <extracomment>image/bmp</extracomment>
        <translation>mapa de bits de Windows</translation>
    </message>
    <message>
        <source>Better Portable Graphics</source>
        <extracomment>image/x-bpg</extracomment>
        <translation>Better Portable Graphics</translation>
    </message>
    <message>
        <source>Computer Graphics Metafile</source>
        <extracomment>image/cgm</extracomment>
        <translation>metafitxer de Computer Graphics</translation>
    </message>
    <message>
        <source>Digital Picture Exchange from SMPTE</source>
        <extracomment>image/x-dpx</extracomment>
        <translation>intercanvi d&apos;imatge digital de SMPTE</translation>
    </message>
    <message>
        <source>Enhanced Metafile</source>
        <extracomment>image/emf</extracomment>
        <translation>metafitxer millorat</translation>
    </message>
    <message>
        <source>Compressed Enhanced Metafile</source>
        <extracomment>image/x-emf-compressed</extracomment>
        <translation>metafitxer millorat comprimit</translation>
    </message>
    <message>
        <source>Graphics Interchange Format</source>
        <extracomment>image/gif</extracomment>
        <translation>format d&apos;intercanvi de gràfics</translation>
    </message>
    <message>
        <source>AV1 Image File</source>
        <extracomment>image/avif</extracomment>
        <translation>fitxer d&apos;imatge AV1</translation>
    </message>
    <message>
        <source>HEIF - High Efficiency Image File</source>
        <extracomment>image/heif</extracomment>
        <translation>HEIF - Fitxer d&apos;imatge d&apos;alta eficiència</translation>
    </message>
    <message>
        <source>HEIF Sequence - High Efficiency Image Sequence</source>
        <extracomment>image/heif-sequence</extracomment>
        <translation>seqüència HEIF - Seqüència d&apos;imatge d&apos;alta eficiència</translation>
    </message>
    <message>
        <source>HEIF Image using HEVC Codec</source>
        <extracomment>image/heic</extracomment>
        <translation>imatge HEIF utilitzant el còdec HEVC</translation>
    </message>
    <message>
        <source>HEIF Sequence using HEVC Codec</source>
        <extracomment>image/heic-sequence</extracomment>
        <translation>seqüència HEIF utilitzant el còdec HEVC</translation>
    </message>
    <message>
        <source>Apple Icon Image Format</source>
        <extracomment>image/icns</extracomment>
        <translation>format d&apos;imatge d&apos;icones d&apos;Apple</translation>
    </message>
    <message>
        <source>JPEG 2000 Part 1 (JP2)</source>
        <extracomment>image/jp2</extracomment>
        <translation>JPEG 2000 Part 1 (JP2)</translation>
    </message>
    <message>
        <source>Joint Photographic Experts Group</source>
        <extracomment>image/jpeg</extracomment>
        <translation>Joint Photographic Experts Group</translation>
    </message>
    <message>
        <source>JPEG 2000 Part 6 (JPM)</source>
        <extracomment>image/jpm</extracomment>
        <translation>JPEG 2000 Part 6 (JPM)</translation>
    </message>
    <message>
        <source>JPEG 2000 Part 2 (JPX)</source>
        <extracomment>image/jpx</extracomment>
        <translation>JPEG 2000 Part 2 (JPX)</translation>
    </message>
    <message>
        <source>Portable Network Graphics</source>
        <extracomment>image/png</extracomment>
        <translation>gràfics portables de xarxa</translation>
    </message>
    <message>
        <source>Scalable Vector Graphics</source>
        <extracomment>image/svg+xml</extracomment>
        <translation>gràfics vectorials escalables</translation>
    </message>
    <message>
        <source>Tagged Image File Format</source>
        <extracomment>image/tiff</extracomment>
        <translation>format de fitxer d&apos;imnatge etiquetat</translation>
    </message>
    <message>
        <source>Photoshop Image</source>
        <extracomment>image/vnd.adobe.photoshop</extracomment>
        <translation>imatge de Photoshop</translation>
    </message>
    <message>
        <source>MicroStation v7 drawing</source>
        <extracomment>image/vnd.dgn;version=7</extracomment>
        <translation>dibuix de MicroStation v7</translation>
    </message>
    <message>
        <source>MicroStation v8 drawing; requires ole2 detector</source>
        <extracomment>image/vnd.dgn;version=8</extracomment>
        <translation>dibuix de MicroStation v8; requereix un detector ole2</translation>
    </message>
    <message>
        <source>AutoCad Drawing</source>
        <extracomment>image/vnd.dwg</extracomment>
        <translation>dibuix d&apos;AutoCad</translation>
    </message>
    <message>
        <source>AutoCAD DXF simplified Binary</source>
        <extracomment>image/vnd.dxb</extracomment>
        <translation>binari simplificat DXF d&apos;AutoCAD</translation>
    </message>
    <message>
        <source>AutoCAD DXF</source>
        <extracomment>image/vnd.dxf</extracomment>
        <translation>DXF d&apos;AutoCAD</translation>
    </message>
    <message>
        <source>Microsoft Document Imaging</source>
        <extracomment>image/vnd.ms-modi</extracomment>
        <translation>imatgeria de documents de Microsoft</translation>
    </message>
    <message>
        <source>Wireless Bitmap File Format</source>
        <extracomment>image/vnd.wap.wbmp</extracomment>
        <translation>format de fitxer de mapa de bits sense fils</translation>
    </message>
    <message>
        <source>ZSoft Multi-Page Paintbrush</source>
        <extracomment>image/vnd.zbrush.dcx</extracomment>
        <translation>ZSoft Multi-Page Paintbrush</translation>
    </message>
    <message>
        <source>ZSoft Paintbrush PiCture eXchange</source>
        <extracomment>image/vnd.zbrush.pcx</extracomment>
        <translation>ZSoft Paintbrush PiCture eXchange</translation>
    </message>
    <message>
        <source>Windows Metafile</source>
        <extracomment>image/wmf</extracomment>
        <translation>metafitxer de Windows</translation>
    </message>
    <message>
        <source>FreeHand image</source>
        <extracomment>image/x-freehand</extracomment>
        <translation>imatge de FreeHand</translation>
    </message>
    <message>
        <source>A lossless image compression standard from the
      Joint Bi-level Image Experts Group.</source>
        <extracomment>image/x-jbig2</extracomment>
        <translation>Un estàndard de compressió d&apos;imatges sense pèrdua de
      Joint Bi-level Image Experts Group.</translation>
    </message>
    <message>
        <source>JPEG 2000 Codestream</source>
        <extracomment>image/x-jp2-codestream</extracomment>
        <translation>flux de codi JPEG 2000</translation>
    </message>
    <message>
        <source>JPEG 2000 Container Format</source>
        <extracomment>image/x-jp2-container</extracomment>
        <translation>format de contenidor JPEG 2000</translation>
    </message>
    <message>
        <source>JPEG XL</source>
        <extracomment>image/jxl</extracomment>
        <translation>JPEG XL</translation>
    </message>
    <message>
        <source>Navy Interchange File Format</source>
        <extracomment>image/x-niff</extracomment>
        <translation>format de fitxer d&apos;intercanvi Navy</translation>
    </message>
    <message>
        <source>Apple Macintosh QuickDraw/PICT Format</source>
        <extracomment>image/x-pict</extracomment>
        <translation>format QuickDraw/PICT d&apos;Apple Macintosh</translation>
    </message>
    <message>
        <source>Portable Any Map</source>
        <extracomment>image/x-portable-anymap</extracomment>
        <translation>Any Map portable</translation>
    </message>
    <message>
        <source>Portable Bit Map</source>
        <extracomment>image/x-portable-bitmap</extracomment>
        <translation>Bit Map portable</translation>
    </message>
    <message>
        <source>Portable Graymap Graphic</source>
        <extracomment>image/x-portable-graymap</extracomment>
        <translation>gràfic de mapa de grisos portable</translation>
    </message>
    <message>
        <source>UNIX Portable Bitmap Graphic</source>
        <extracomment>image/x-portable-pixmap</extracomment>
        <translation>gràfic de mapa de bits portable UNIX</translation>
    </message>
    <message>
        <source>UNIX Portable Bitmap Graphic Arbitrary Map</source>
        <extracomment>image/x-portable-arbitrarymap</extracomment>
        <translation>mapa arbitrari de gràfic de mapa de bits portable UNIX</translation>
    </message>
    <message>
        <source>Adobe Digital Negative</source>
        <extracomment>image/x-raw-adobe</extracomment>
        <translation>negatiu digital d&apos;Adobe</translation>
    </message>
    <message>
        <source>Hasselblad raw image</source>
        <extracomment>image/x-raw-hasselblad</extracomment>
        <translation>imatge en brut de Hasselblad</translation>
    </message>
    <message>
        <source>Fuji raw image</source>
        <extracomment>image/x-raw-fuji</extracomment>
        <translation>imatge en brut de Fuji</translation>
    </message>
    <message>
        <source>Canon raw image</source>
        <extracomment>image/x-raw-canon</extracomment>
        <translation>imatge en brut de Canon</translation>
    </message>
    <message>
        <source>Canon raw image, version 2, TIFF-based</source>
        <extracomment>image/x-canon-cr2</extracomment>
        <translation>imatge en brut de Canon, versió 2, basada en TIFF</translation>
    </message>
    <message>
        <source>Canon raw image, version 3, Quicktime-based</source>
        <extracomment>image/x-canon-cr3</extracomment>
        <translation>imatge en brut de Canon, versió 3, basada en Quicktime</translation>
    </message>
    <message>
        <source>Kodak raw image</source>
        <extracomment>image/x-raw-kodak</extracomment>
        <translation>imatge en brut de Kodak</translation>
    </message>
    <message>
        <source>Minolta raw image</source>
        <extracomment>image/x-raw-minolta</extracomment>
        <translation>imatge en brut de Minolta</translation>
    </message>
    <message>
        <source>Nikon raw image</source>
        <extracomment>image/x-raw-nikon</extracomment>
        <translation>imatge en brut de Nikon</translation>
    </message>
    <message>
        <source>Olympus raw image</source>
        <extracomment>image/x-raw-olympus</extracomment>
        <translation>imatge en brut d&apos;Olympus</translation>
    </message>
    <message>
        <source>Pentax raw image</source>
        <extracomment>image/x-raw-pentax</extracomment>
        <translation>imatge en brut de Pentax</translation>
    </message>
    <message>
        <source>Sony raw image</source>
        <extracomment>image/x-raw-sony</extracomment>
        <translation>imatge en brut de Sony</translation>
    </message>
    <message>
        <source>Sigma raw image</source>
        <extracomment>image/x-raw-sigma</extracomment>
        <translation>imatge en brut de Sigma</translation>
    </message>
    <message>
        <source>Epson raw image</source>
        <extracomment>image/x-raw-epson</extracomment>
        <translation>imatge en brut d&apos;Epson</translation>
    </message>
    <message>
        <source>Mamiya raw image</source>
        <extracomment>image/x-raw-mamiya</extracomment>
        <translation>imatge en brut de Mamiya</translation>
    </message>
    <message>
        <source>Leaf raw image</source>
        <extracomment>image/x-raw-leaf</extracomment>
        <translation>imatge en brut de Leaf</translation>
    </message>
    <message>
        <source>Panasonic raw image</source>
        <extracomment>image/x-raw-panasonic</extracomment>
        <translation>imatge en brut de Panasonic</translation>
    </message>
    <message>
        <source>Phase One raw image</source>
        <extracomment>image/x-raw-phaseone</extracomment>
        <translation>imatge en brut de Phase One</translation>
    </message>
    <message>
        <source>Red raw image</source>
        <extracomment>image/x-raw-red</extracomment>
        <translation>imatge en brut de Red</translation>
    </message>
    <message>
        <source>Imacon raw image</source>
        <extracomment>image/x-raw-imacon</extracomment>
        <translation>imatge en brut d&apos;Imacon</translation>
    </message>
    <message>
        <source>Logitech raw image</source>
        <extracomment>image/x-raw-logitech</extracomment>
        <translation>imatge en brut de Logitech</translation>
    </message>
    <message>
        <source>Casio raw image</source>
        <extracomment>image/x-raw-casio</extracomment>
        <translation>imatge en brut de Casio</translation>
    </message>
    <message>
        <source>Rawzor raw image</source>
        <extracomment>image/x-raw-rawzor</extracomment>
        <translation>imatge en brut de Rawzor</translation>
    </message>
    <message>
        <source>Silicon Graphics RGB Bitmap</source>
        <extracomment>image/x-rgb</extracomment>
        <translation>mapa de bits RGB de Silicon Graphics</translation>
    </message>
    <message>
        <source>GIMP Image File</source>
        <extracomment>image/x-xcf</extracomment>
        <translation>fitxer d&apos;imatge GIMP</translation>
    </message>
    <message>
        <source>X Windows Dump</source>
        <extracomment>image/x-xwindowdump</extracomment>
        <translation>bolcat de X Windows</translation>
    </message>
    <message>
        <source>MIME Encapsulation of Aggregate HTML Documents</source>
        <extracomment>multipart/related</extracomment>
        <translation>encapsulació MIME de documents HTML agregats</translation>
    </message>
    <message>
        <source>3d imaging data exchange</source>
        <extracomment>model/e57</extracomment>
        <translation>intercanvi de dades d&apos;imatges 3D</translation>
    </message>
    <message>
        <source>Initial Graphics Exchange Specification Format</source>
        <extracomment>model/iges</extracomment>
        <translation>format inicial d&apos;especificació d&apos;intercanvi de gràfics</translation>
    </message>
    <message>
        <source>no magic available</source>
        <extracomment>model/x.stl-binary</extracomment>
        <translation>sense màgia disponible</translation>
    </message>
    <message>
        <source>AutoCAD Design Web Format</source>
        <extracomment>model/vnd.dwf
----------
model/vnd.dwfx+xps</extracomment>
        <translation>format web de disseny AutoCAD</translation>
    </message>
    <message>
        <source>ONline Information eXchange (ONIX) for books</source>
        <extracomment>application/onix-message+xml
----------
application/onix-message-short+xml</extracomment>
        <translation>ONline Information eXchange (ONIX) de llibres</translation>
    </message>
    <message>
        <source>ActionScript source code</source>
        <extracomment>text/x-actionscript</extracomment>
        <translation>codi font d&apos;ActionScript</translation>
    </message>
    <message>
        <source>Ada source code</source>
        <extracomment>text/x-ada</extracomment>
        <translation>codi font d&apos;Ada</translation>
    </message>
    <message>
        <source>AppleScript source code</source>
        <extracomment>text/x-applescript</extracomment>
        <translation>codi font d&apos;AppleScript</translation>
    </message>
    <message>
        <source>Active Server Page</source>
        <extracomment>text/asp</extracomment>
        <translation>Active Server Page</translation>
    </message>
    <message>
        <source>ASP .NET</source>
        <extracomment>text/aspdotnet</extracomment>
        <translation>ASP .NET</translation>
    </message>
    <message>
        <source>AspectJ source code</source>
        <extracomment>text/x-aspectj</extracomment>
        <translation>codi font d&apos;AspectJ</translation>
    </message>
    <message>
        <source>Assembler source code</source>
        <extracomment>text/x-assembly</extracomment>
        <translation>codi font d&apos;assemblador</translation>
    </message>
    <message>
        <source>Cascading Style Sheet</source>
        <extracomment>text/css</extracomment>
        <translation>Cascading Style Sheet</translation>
    </message>
    <message>
        <source>HyperText Markup Language</source>
        <extracomment>text/html</extracomment>
        <translation>llenguatge de marcatge HyperText</translation>
    </message>
    <message>
        <source>Makefile build file</source>
        <extracomment>text/x-makefile</extracomment>
        <translation>fitxer de construcció Makefile</translation>
    </message>
    <message>
        <source>Roff/nroff/troff/groff Unformatted Manual Page (UNIX)</source>
        <extracomment>text/troff</extracomment>
        <translation>pàgina de manual sense format roff/nroff/troff/groff (UNIX)</translation>
    </message>
    <message>
        <source>Graphviz Graph Visualization Software</source>
        <extracomment>text/vnd.graphviz</extracomment>
        <translation>programari de visualització de gràfics Graphviz</translation>
    </message>
    <message>
        <source>American Newspaper Publishers Association Wire Feeds</source>
        <extracomment>text/vnd.iptc.anpa</extracomment>
        <translation>American Newspaper Publishers Association Wire Feeds</translation>
    </message>
    <message>
        <source>WML Script</source>
        <extracomment>text/vnd.wap.wmlscript</extracomment>
        <translation>script WML</translation>
    </message>
    <message>
        <source>Web Video Text Tracks Format</source>
        <extracomment>text/vtt</extracomment>
        <translation>format de les pistes de text de vídeo web</translation>
    </message>
    <message>
        <source>AWK script</source>
        <extracomment>text/x-awk</extracomment>
        <translation>script AWK</translation>
    </message>
    <message>
        <source>Basic source code</source>
        <extracomment>text/x-basic</extracomment>
        <translation>codi font de Basic</translation>
    </message>
    <message>
        <source>C++ source code header</source>
        <extracomment>text/x-c++hdr</extracomment>
        <translation>capçalera de codi font de C++</translation>
    </message>
    <message>
        <source>C++ source code</source>
        <extracomment>text/x-c++src</extracomment>
        <translation>codi font de C++</translation>
    </message>
    <message>
        <source>CGI script</source>
        <extracomment>text/x-cgi</extracomment>
        <translation>script CGI</translation>
    </message>
    <message>
        <source>C source code header</source>
        <extracomment>text/x-chdr</extracomment>
        <translation>capçalera de codi font de C</translation>
    </message>
    <message>
        <source>Clojure source code</source>
        <extracomment>text/x-clojure</extracomment>
        <translation>codi font de Clojure</translation>
    </message>
    <message>
        <source>CoffeeScript source code</source>
        <extracomment>text/x-coffeescript</extracomment>
        <translation>codi font de CoffeeScript</translation>
    </message>
    <message>
        <source>C source code</source>
        <extracomment>text/x-csrc</extracomment>
        <translation>codi font de C</translation>
    </message>
    <message>
        <source>C# source code</source>
        <extracomment>text/x-csharp</extracomment>
        <translation>codi font de C#</translation>
    </message>
    <message>
        <source>COBOL source code</source>
        <extracomment>text/x-cobol</extracomment>
        <translation>codi font de COBOL</translation>
    </message>
    <message>
        <source>ColdFusion source code</source>
        <extracomment>text/x-coldfusion</extracomment>
        <translation>codi font de ColdFusion</translation>
    </message>
    <message>
        <source>Common Lisp source code</source>
        <extracomment>text/x-common-lisp</extracomment>
        <translation>codi font de Common Lisp</translation>
    </message>
    <message>
        <source>Eiffel source code</source>
        <extracomment>text/x-eiffel</extracomment>
        <translation>codi font d&apos;Eiffel</translation>
    </message>
    <message>
        <source>Emacs Lisp source code</source>
        <extracomment>text/x-emacs-lisp</extracomment>
        <translation>codi font de Lisp d&apos;Emacs</translation>
    </message>
    <message>
        <source>Erlang source code</source>
        <extracomment>text/x-erlang</extracomment>
        <translation>codi font d&apos;Erlang</translation>
    </message>
    <message>
        <source>Expect Script</source>
        <extracomment>text/x-expect</extracomment>
        <translation>script Expect</translation>
    </message>
    <message>
        <source>Forth source code</source>
        <extracomment>text/x-forth</extracomment>
        <translation>codi font de Forth</translation>
    </message>
    <message>
        <source>Fortran source code</source>
        <extracomment>text/x-fortran</extracomment>
        <translation>codi font de Fortran</translation>
    </message>
    <message>
        <source>Go source code</source>
        <extracomment>text/x-go</extracomment>
        <translation>codi font de Go</translation>
    </message>
    <message>
        <source>Groovy source code</source>
        <extracomment>text/x-groovy</extracomment>
        <translation>codi font de Groovy</translation>
    </message>
    <message>
        <source>Haskell source code</source>
        <extracomment>text/x-haskell</extracomment>
        <translation>codi font de Haskell</translation>
    </message>
    <message>
        <source>Interface Definition Language</source>
        <extracomment>text/x-idl</extracomment>
        <translation>llenguatge de definició d&apos;interfície</translation>
    </message>
    <message>
        <source>Configuration file</source>
        <extracomment>text/x-ini</extracomment>
        <translation>fitxer de configuració</translation>
    </message>
    <message>
        <source>Java source code</source>
        <extracomment>text/x-java-source</extracomment>
        <translation>codi font de Java</translation>
    </message>
    <message>
        <source>Java Properties</source>
        <extracomment>text/x-java-properties</extracomment>
        <translation>propietats de Java</translation>
    </message>
    <message>
        <source>Java Server Page</source>
        <extracomment>text/x-jsp</extracomment>
        <translation>pàgina de servidor Java</translation>
    </message>
    <message>
        <source>LESS source code</source>
        <extracomment>text/x-less</extracomment>
        <translation>codi font de LESS</translation>
    </message>
    <message>
        <source>Lex/Flex source code</source>
        <extracomment>text/x-lex</extracomment>
        <translation>codi font de Lex/Flex</translation>
    </message>
    <message>
        <source>application log</source>
        <extracomment>text/x-log</extracomment>
        <translation>registre d&apos;aplicació</translation>
    </message>
    <message>
        <source>Lua source code</source>
        <extracomment>text/x-lua</extracomment>
        <translation>codi font de Lua</translation>
    </message>
    <message>
        <source>ML source code</source>
        <extracomment>text/x-ml</extracomment>
        <translation>codi font de ML</translation>
    </message>
    <message>
        <source>Matlab source code</source>
        <extracomment>text/x-matlab</extracomment>
        <translation>codi font de Matlab</translation>
    </message>
    <message>
        <source>MATLAB data file</source>
        <extracomment>application/x-matlab-data</extracomment>
        <translation>fitxer de dades de MATLAB</translation>
    </message>
    <message>
        <source>Modula source code</source>
        <extracomment>text/x-modula</extracomment>
        <translation>codi font de Modula</translation>
    </message>
    <message>
        <source>Objective-C source code</source>
        <extracomment>text/x-objcsrc</extracomment>
        <translation>codi font d&apos;Objective-C</translation>
    </message>
    <message>
        <source>Ocaml source code</source>
        <extracomment>text/x-ocaml</extracomment>
        <translation>codi font d&apos;Ocaml</translation>
    </message>
    <message>
        <source>Pascal source code</source>
        <extracomment>text/x-pascal</extracomment>
        <translation>codi font de Pascal</translation>
    </message>
    <message>
        <source>Perl script</source>
        <extracomment>text/x-perl</extracomment>
        <translation>script Perl</translation>
    </message>
    <message>
        <source>PHP script</source>
        <extracomment>text/x-php</extracomment>
        <translation>script PHP</translation>
    </message>
    <message>
        <source>Prolog source code</source>
        <extracomment>text/x-prolog</extracomment>
        <translation>codi font de Prolog</translation>
    </message>
    <message>
        <source>Python script</source>
        <extracomment>text/x-python</extracomment>
        <translation>script Python</translation>
    </message>
    <message>
        <source>reStructuredText source code</source>
        <extracomment>text/x-rst</extracomment>
        <translation>codi font de reStructuredText</translation>
    </message>
    <message>
        <source>Rexx source code</source>
        <extracomment>text/x-rexx</extracomment>
        <translation>codi font de Rexx</translation>
    </message>
    <message>
        <source>Ruby source code</source>
        <extracomment>text/x-ruby</extracomment>
        <translation>codi font de Ruby</translation>
    </message>
    <message>
        <source>Scala source code</source>
        <extracomment>text/x-scala</extracomment>
        <translation>codi font de Scala</translation>
    </message>
    <message>
        <source>Scheme source code</source>
        <extracomment>text/x-scheme</extracomment>
        <translation>codi font de Scheme</translation>
    </message>
    <message>
        <source>Sed code</source>
        <extracomment>text/x-sed</extracomment>
        <translation>codi Sed</translation>
    </message>
    <message>
        <source>SQL code</source>
        <extracomment>text/x-sql</extracomment>
        <translation>codi SQL</translation>
    </message>
    <message>
        <source>Smalltalk source code</source>
        <extracomment>text/x-stsrc</extracomment>
        <translation>codi font de Smalltalk</translation>
    </message>
    <message>
        <source>Tcl script</source>
        <extracomment>text/x-tcl</extracomment>
        <translation>script Tcl</translation>
    </message>
    <message>
        <source>Text-based (non-binary) Message</source>
        <extracomment>text/x-tika-text-based-message</extracomment>
        <translation>missatge basat en text (no binari)</translation>
    </message>
    <message>
        <source>Visual basic source code</source>
        <extracomment>text/x-vbasic</extracomment>
        <translation>codi font de Visual Basic</translation>
    </message>
    <message>
        <source>VB.NET source code</source>
        <extracomment>text/x-vbdotnet</extracomment>
        <translation>codi font de VB.NET</translation>
    </message>
    <message>
        <source>VBScript source code</source>
        <extracomment>text/x-vbscript</extracomment>
        <translation>codi font de VBScript</translation>
    </message>
    <message>
        <source>Verilog source code</source>
        <extracomment>text/x-verilog</extracomment>
        <translation>codi font de Verilog</translation>
    </message>
    <message>
        <source>VHDL source code</source>
        <extracomment>text/x-vhdl</extracomment>
        <translation>codi font de VHDL</translation>
    </message>
    <message>
        <source>Markdown source code</source>
        <extracomment>text/x-web-markdown</extracomment>
        <translation>codi font de Markdown</translation>
    </message>
    <message>
        <source>Yacc/Bison source code</source>
        <extracomment>text/x-yacc</extracomment>
        <translation>codi font de Yacc/Bison</translation>
    </message>
    <message>
        <source>YAML source code</source>
        <extracomment>text/x-yaml</extracomment>
        <translation>codi font de YAML</translation>
    </message>
    <message>
        <source>JPEG 2000 Part 3 (Motion JPEG, MJ2)</source>
        <extracomment>video/mj2</extracomment>
        <translation>JPEG 2000 Part 3 (Motion JPEG, MJ2)</translation>
    </message>
    <message>
        <source>MPEG Movie Clip</source>
        <extracomment>video/mpeg</extracomment>
        <translation>clip pel·licula MPEG</translation>
    </message>
    <message>
        <source>Ogg Vorbis Video</source>
        <extracomment>video/ogg</extracomment>
        <translation>vídeo Ogg Vorbis</translation>
    </message>
    <message>
        <source>Ogg Daala Video</source>
        <extracomment>video/daala</extracomment>
        <translation>vídeo Ogg Daala</translation>
    </message>
    <message>
        <source>Ogg Theora Video</source>
        <extracomment>video/theora</extracomment>
        <translation>vídeo Ogg Theora</translation>
    </message>
    <message>
        <source>Ogg Packaged Dirac Video</source>
        <extracomment>video/x-dirac</extracomment>
        <translation>vídeo Ogg empaquetat amb Dirac</translation>
    </message>
    <message>
        <source>Ogg Packaged OGM Video</source>
        <extracomment>video/x-ogm</extracomment>
        <translation>vídeo Ogg empaquetat amb OGM</translation>
    </message>
    <message>
        <source>Ogg Packaged Raw UVS Video</source>
        <extracomment>video/x-ogguvs</extracomment>
        <translation>vídeo Ogg empaquetat UVS en brut</translation>
    </message>
    <message>
        <source>Ogg Packaged Raw YUV Video</source>
        <extracomment>video/x-oggyuv</extracomment>
        <translation>vídeo Ogg empaquetat YUV en brut</translation>
    </message>
    <message>
        <source>Ogg Packaged Raw RGB Video</source>
        <extracomment>video/x-oggrgb</extracomment>
        <translation>vídeo Ogg empaquetat RGB en brut</translation>
    </message>
    <message>
        <source>QuickTime Video</source>
        <extracomment>video/quicktime</extracomment>
        <translation>vídeo QuickTime</translation>
    </message>
    <message>
        <source>Windows Media Metafile</source>
        <extracomment>application/x-ms-asx</extracomment>
        <translation>metafitxer multimèdia de Windows</translation>
    </message>
    <message>
        <source>Audio Video Interleave File</source>
        <extracomment>video/x-msvideo</extracomment>
        <translation>fitxer d&apos;entrellaçat vídeo àudio</translation>
    </message>
    <message>
        <source>Matroska Media Container</source>
        <extracomment>application/x-matroska</extracomment>
        <translation>contenidor multimèdia Matroska</translation>
    </message>
    <message>
        <source>Cooltalk Audio</source>
        <extracomment>x-conference/x-cooltalk</extracomment>
        <translation>àudio Cooltalk</translation>
    </message>
    <message>
        <source>FictionBook document</source>
        <extracomment>application/x-fictionbook+xml</extracomment>
        <translation>document FictionBook</translation>
    </message>
    <message>
        <source>Asciidoc source code</source>
        <extracomment>text/x-asciidoc</extracomment>
        <translation>codi font d&apos;Asciidoc</translation>
    </message>
    <message>
        <source>D source code</source>
        <extracomment>text/x-d</extracomment>
        <translation>codi font de D</translation>
    </message>
    <message>
        <source>HAML source code</source>
        <extracomment>text/x-haml</extracomment>
        <translation>codi font d&apos;HAML</translation>
    </message>
    <message>
        <source>Haxe source code</source>
        <extracomment>text/x-haxe</extracomment>
        <translation>codi font d&apos;Haxe</translation>
    </message>
    <message>
        <source>XLIFF 1.2 document</source>
        <extracomment>application/x-xliff+xml</extracomment>
        <translation>document XLIFF 1.2</translation>
    </message>
    <message>
        <source>XLZ Archive</source>
        <extracomment>application/x-xliff+zip</extracomment>
        <translation>arxiu XLZ</translation>
    </message>
    <message>
        <source>R source code</source>
        <extracomment>text/x-rsrc</extracomment>
        <translation>codi font de R</translation>
    </message>
</context>
<context>
    <name>QWindowsUiaMainProvider</name>
    <message>
        <source>blockquote</source>
        <translation>blockquote</translation>
    </message>
</context>
<context>
    <name>QAccessibleColorWellItem</name>
    <message>
        <source>RGB %1, %2, %3</source>
        <extracomment>Color specified via its 3 RGB components (red, green, blue)</extracomment>
        <translation>RGB %1, %2, %3</translation>
    </message>
</context>
<context>
    <name>QProgressBar</name>
    <message>
        <source>%p%</source>
        <extracomment>%p is the percent value, % is the percent sign. When translated to the identical %p%, then the second % symbol will be replaced by the percentage-symbol from the user&apos;s locale.</extracomment>
        <translation>%p%</translation>
    </message>
</context>
</TS>
