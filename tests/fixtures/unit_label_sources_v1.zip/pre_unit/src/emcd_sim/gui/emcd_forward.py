"""Snapshot adapter: independent BW/FFT waves and one shared tensor contraction."""
from dataclasses import dataclass, asdict, replace, field
from pathlib import Path
import hashlib, json, platform, subprocess
from time import perf_counter
import numpy as np
from .geometry import Structure, Settings, geometry, elastic_model, excitation, za_from_tilt
from ..benchmark import nickel_physical_benchmark
from ..geometry import VirtualDetector, electron_wavelength_angstrom
from ..mdff_tensor import DipoleTensor, dipole_tensor_from_transitions
from ..ni_local_mdff import NiLocalConfig, ni_local_transitions
from ..wien2k_xmcd import load_wien2k_xmcd
from ..xmcd_effective_mdff import effective_tensor_from_xmcd
from ..multislice_reference import coherence_from_amplitudes
from ..emcd_angular_plots import paired_geometry, paired_maps
from ..xmcd_postedge_normalization import analyze_postedge_spectra

from .runtime import reference_source, build_info

DEFAULT_SOURCE = reference_source()


def inspect_source(path):
    """Basic import is independent of optional original WIEN2k companion audit."""
    s=load_wien2k_xmcd(path); n=s.nonmagnetic
    maxima=np.flatnonzero((n[1:-1]>n[:-2]) & (n[1:-1]>=n[2:]))+1
    peaks=[]
    for i in sorted(maxima,key=lambda i:n[i],reverse=True):
        if all(abs(s.energy_ev[i]-s.energy_ev[j])>8 for j in peaks):peaks.append(i)
        if len(peaks)==2:break
    selected=None
    if len(peaks)==2:
        selected={}
        for edge,i in zip(('L3','L2'),sorted(peaks)):
            ix=np.flatnonzero(abs(s.energy_ev-s.energy_ev[i])<=3)
            selected[edge]=float(s.energy_ev[ix[np.argmax(abs(s.dichroic[ix]))]])
    info=dict(sha256=s.source_sha256,bounds=[float(s.energy_ev[0]),float(s.energy_ev[-1])],
              selected=selected,provenance='Five-column validated. User must declare source magnetic axis, RP/LP convention and edge assignment.',audit=None)
    suffixes=('raw1','raw2','broad1','broad2','rawxmcd','inso','injoint','inc')
    if Path(path).resolve()==DEFAULT_SOURCE.resolve() and all(Path(path).with_suffix('.'+k).exists() for k in suffixes):
        from ..wien2k_source_audit import energy_audit
        info['audit']=energy_audit(path);info['selected']=info['audit']['selected_magnetic_energies_ev']
        info['provenance']='Original Ni companion audit passed; cubic [001], native unshifted L3/L2.'
    return info


@dataclass(frozen=True)
class ForwardSettings:
    model: str='xmcd'
    source: str=str(DEFAULT_SOURCE)
    source_sha256: str=''
    axis_declared: bool=False
    magnetization: tuple=(0.,0.,1.)
    eta: float=1.
    beta: float=1.
    l3: float=831.271
    l2: float=848.698
    atomic: NiLocalConfig=field(default_factory=NiLocalConfig)
    sigma: float=.8
    radial: float|None=None
    energy_points: int=241
    grid: int=97
    depth: int=64
    subpixels: int=64
    halfwidth: float=1.
    centers: tuple=((.2837684449489217,.2837684449489217),(.2837684449489217,-.2837684449489217))
    radius: float=.0908059024
    correction: bool=True
    window: tuple=(878.,882.)
    propagation: str='bloch'
    fft_grid: int=32
    slice_step: float=2.
    memory_budget_mib: int=2048
    channeling_model: str='single'
    energy_scope: str='full'
    angular_maps: bool=True
    systematic_row: bool=False
    worker_mode: str='automatic'
    parallel_workers: int=1
    fft_generators: tuple|None=None


def material_reason(structure):
    # Conservative Stage B gate: arbitrary CIF inspection is not MDFF validation.
    ref=Structure.nickel().atoms;a=structure.atoms
    if structure.elastic_reason:return structure.elastic_reason
    if (len(a)!=len(ref) or not np.allclose(a.cell.array,ref.cell.array,atol=1e-7)
        or not np.allclose(a.get_scaled_positions()%1,ref.get_scaled_positions()%1,atol=1e-7)):
        return 'Stage B MDFF requires the verified conventional FCC Ni cell (a=3.524 A, equivalent sites). CIF inspection remains available.'
    return ''


def axis_rotation(axis):
    m=np.asarray(axis,float)
    if m.shape!=(3,) or not np.isfinite(m).all() or np.linalg.norm(m)<1e-12:raise ValueError('Declare a nonzero finite crystal Cartesian magnetization axis')
    z=m/np.linalg.norm(m);x=np.array([1.,0,0]);x-=x.dot(z)*z
    if np.linalg.norm(x)<1e-8:x=np.array([0.,1,0]);x-=x.dot(z)*z
    x/=np.linalg.norm(x);return np.stack((x,np.cross(z,x),z),axis=1)


def tensors(cfg,energy,R):
    if cfg.model=='xmcd':
        if not cfg.axis_declared:raise ValueError('Declare the XMCD magnetic-axis, RP/LP handedness and L3/L2 assignments before running')
        Q=axis_rotation(cfg.magnetization)
        source=[effective_tensor_from_xmcd(cfg.source,energy,eta=s*cfg.eta,beta=cfg.beta) for s in (1,-1)]
    elif cfg.model=='atomic':
        if not np.allclose(cfg.magnetization,(0,0,1)):raise ValueError('Atomic cubic-field model currently supports crystal [001] magnetization only')
        Q=np.eye(3)
        source=[dipole_tensor_from_transitions(ni_local_transitions(cfg.atomic,radial_override_angstrom=cfg.radial,magnetization_sign=s),energy,cfg.sigma) for s in (1,-1)]
    else:raise ValueError('Unknown MDFF model')
    out=[]
    for t in source:
        A=R@Q;v=np.einsum('ia,eab,jb->eij',A,t.tensor_angstrom2_per_ev,A)
        if np.linalg.eigvalsh(v).min() < -1e-12*max(float(abs(v).max()),1e-30):raise ValueError('MDFF tensor is not positive semidefinite')
        out.append(DipoleTensor(energy,v,t.source+';crystal_to_local_R_T_RT'))
    if not np.allclose(out[1].tensor_angstrom2_per_ev,out[0].tensor_angstrom2_per_ev.conj(),rtol=1e-10,atol=1e-13*max(abs(out[0].tensor_angstrom2_per_ev).max(),1e-30)):
        raise ValueError('This model does not pass even/odd reversal symmetry; decomposition disabled')
    return out


def energy_grid(cfg,requested=None):
    if cfg.model=='xmcd':
        s=load_wien2k_xmcd(cfg.source);lo,hi=s.energy_ev[[0,-1]]
        if cfg.source_sha256 and cfg.source_sha256!=s.source_sha256:raise ValueError('XMCD source changed since validation; validate again')
    else:lo,hi=cfg.atomic.l3_ev-10,cfg.atomic.l2_ev+10
    if not lo<=cfg.l3<cfg.l2<=hi:raise ValueError('Selected L3/L2 must be ordered inside the native model energy range')
    if cfg.channeling_model not in ('single','double'):raise ValueError('Unknown channeling model; no automatic substitution')
    if cfg.energy_scope not in ('full','edges'):raise ValueError('Unknown spectral energy coverage')
    if not 9<=cfg.energy_points<=501 or not 9<=cfg.grid<=193 or not 2<=cfg.depth<=1025 or not 4<=cfg.subpixels<=256:raise ValueError('Numerical sampling exceeds supported GUI bounds')
    if not np.isfinite([cfg.halfwidth,cfg.radius,*np.ravel(cfg.centers),*cfg.window]).all() or min(cfg.halfwidth,cfg.radius)<=0:raise ValueError('Invalid map/detector/window controls')
    if requested is not None:
        e=np.asarray(requested,float)
        if e.ndim!=1 or len(e)<2 or not np.isfinite(e).all() or np.any(np.diff(e)<=0):raise ValueError('Requested energies must be finite, increasing and contain at least two samples')
        if e[0]<lo or e[-1]>hi:raise ValueError('No MDFF energy extrapolation')
        if not all(np.any(np.isclose(e,v,rtol=0,atol=1e-9)) for v in (cfg.l3,cfg.l2)):raise ValueError('Requested grid must include the selected native L3/L2 energies')
        return e.copy()
    return np.array([cfg.l3,cfg.l2]) if cfg.energy_scope=='edges' else np.unique(np.r_[np.linspace(lo,hi,cfg.energy_points),cfg.l3,cfg.l2])


from ..cancellation import Cancelled, check_cancelled


def calculate(structure,settings,cfg,progress=lambda s:None,cancelled=lambda:False,*,energy_ev=None,energy_checkpoint=None,execution_policy=None):
    check_cancelled(cancelled)
    from .propagation import numerical_info,resolve_fft_configuration
    cfg=resolve_fft_configuration(structure,settings,cfg)
    from .memory_budget import reserve_memory
    info=numerical_info(structure,settings,cfg)
    if execution_policy is not None and execution_policy['effective_workers']!=info['execution']['effective_workers']:
        raise ValueError('Resources changed since preflight; Run again to review the new effective worker counts.')
    execution_policy=info['execution']
    check_cancelled(cancelled)
    # Double kernels make their own concurrent reservations. Reserve retained
    # GUI arrays here, after admitting the complete estimated working set.
    reserved=info['retained_results_working_mib'] if cfg.channeling_model=='double' else info['estimated_working_mib']
    with reserve_memory(reserved,cfg.memory_budget_mib,dense_mib=info['dense_working_estimate_mib']) as admission:
        result=_calculate(structure,settings,cfg,progress,cancelled,energy_ev=energy_ev,energy_checkpoint=energy_checkpoint,execution_policy=execution_policy)
        result['metadata']['execution']=execution_policy
        check_cancelled(cancelled)
        result['metadata']['memory_admission']=admission
        for r in result['methods'].values():r['metadata']['memory_admission']=admission
        return result


def _calculate(structure,settings,cfg,progress,cancelled,*,energy_ev=None,energy_checkpoint=None,execution_policy=None):
    def stage(s):
        if cancelled():raise Cancelled()
        progress(s)
    stage('Validating structure and MDFF')
    reason=material_reason(structure)
    if reason:raise ValueError(reason)
    energy=energy_grid(cfg,energy_ev);elastic=elastic_model(structure,settings,systematic_row=cfg.systematic_row);_,R,hkl,g,_=geometry(structure,settings,systematic_row=cfg.systematic_row)
    if settings.target not in hkl or settings.target==(0,0,0):raise ValueError('Select a nonzero target in the finite diffraction basis')
    memory=64*cfg.grid**2*len(hkl)**2/2**20
    model=replace(nickel_physical_benchmark(),elastic=elastic,detectors={k:VirtualDetector(tuple(p),cfg.radius) for k,p in zip(('A','B'),cfg.centers)},chiral_groups=None)
    # Direct integration requires full physical aperture coverage as well.
    if any(max(abs(np.asarray(p)))+cfg.radius>cfg.halfwidth for p in cfg.centers):raise ValueError('Map halfwidth must fully cover both physical detector apertures')
    from .propagation import propagate, compare_methods, numerical_info
    info=numerical_info(structure,settings,cfg,hkl=hkl,check_memory=False)
    memory=info['dense_working_estimate_mib']
    stage('Generating common +M and -M tensors');ts=tensors(cfg,energy,R)
    z=np.linspace(0,settings.thickness,cfg.depth)
    methods={};fft_info={}
    # Finish one solver before preparing the next: cancellation in BW must
    # prevent even the incoming MS propagation from starting in Both mode.
    solvers=('bloch','fft-multislice') if cfg.propagation=='both' else (cfg.propagation,)
    for method in solvers:
        stage('Preparing '+method+' propagation')
        incoming_start=perf_counter()
        waves,method_fft=propagate(elastic,settings,replace(cfg,propagation=method),z,stage,cancelled=cancelled)
        incoming_seconds=perf_counter()-incoming_start
        prepared_incoming=method_fft.pop('_prepared',None)
        if method_fft:fft_info=method_fft
        psi=waves[method]
        stage('Constructing '+method+' depth coherence');C=coherence_from_amplitudes(z,psi)
        stage('Calculating '+method+' EELS and EMCD')
        from .channeling import contract
        checkpoint=(lambda e,data:energy_checkpoint(method,e,data)) if energy_checkpoint is not None else None
        prepared=contract(model,settings,cfg,method,C,energy,ts,stage,cancelled,prepared_incoming,energy_checkpoint=checkpoint,
            execution_workers=execution_policy['effective_workers'][method] if execution_policy else None)
        methods[method]=_contract(structure,settings,cfg,model,R,hkl,g,memory,z,psi,C,energy,ts,stage,cancelled,prepared=prepared)
        methods[method]['method']=method
        methods[method]['metadata'].update(solver=method+' '+cfg.channeling_model+' channeling localized single ionization',numerics=info,
            incoming_propagation_seconds=incoming_seconds,additional_incoming_preparation_seconds=prepared['incoming_preparation_seconds'])
        if method=='fft-multislice':methods[method]['metadata']['fft']=fft_info['summary']
    stage('Comparing independent BW/MS propagations')
    comparison=compare_methods(methods,fft_info)
    primary=methods.get('bloch',next(iter(methods.values())))
    # Top-level Stage B arrays remain the primary method; method results do not
    # contain the enclosing collection, avoiding recursive/ambiguous dimensions.
    result=dict(primary,methods=methods,comparison=comparison,fft=fft_info)
    result['metadata']=dict(primary['metadata'],method_labels=list(methods),comparison=comparison)
    from .project_io import structure_snapshot
    result['structure_snapshot']=structure_snapshot(structure)
    for r in methods.values():r['structure_snapshot']=result['structure_snapshot']
    stage('Preparing result visualizations')
    return result


def _contract(structure,settings,cfg,model,R,hkl,g,memory,z,psi,C,energy,ts,stage,cancelled,*,prepared):
    """Stage B EELS/parity/post-edge implementation, shared by both coherences."""
    stage('Computing energy-resolved EELS and fractional detector integrals')
    spectra,maps,qx,qy,weights=[prepared[k] for k in ('spectra','maps','qx','qy','weights')]
    stage('Computing L3/L2 map decomposition and post-edge diagnostics')
    ap,bp,am,bm=[spectra[k] for k in ('I_A_plus','I_B_plus','I_A_minus','I_B_minus')]
    na,nb,ma,mb=(ap+am)/2,(bp+bm)/2,(ap-am)/2,(bp-bm)/2
    spectra.update(energy_ev=energy,N_A=na,N_B=nb,M_A=ma,M_B=mb,D_mag=ma-mb,D_nonmag=na-nb,D_raw=ap-bp,Sigma_ref=na+nb)
    from .prb_benchmark import benchmark_spectra
    spectra.update(benchmark_spectra(spectra)[0])
    alpha=None;correction_reason='Correction disabled by user.'
    if cfg.correction:
        try:
            post=analyze_postedge_spectra(energy,ap,bp,am,bm,windows=(cfg.window,),edge_windows={})
            alpha=float(post.spectra['alpha_obs'][0]);correction_reason='Observed +M A/B post-edge integral ratio; corrected contrast is not intrinsically magnetic.'
            for key in ('D_corrected','D_mag_processed_obs','D_nonmag_residual_obs'):spectra[key]=post.spectra[key][0]
            spectra['magnetic_bias']=spectra['D_mag_processed_obs']-spectra['D_mag']
        except ValueError as exc:correction_reason='Correction disabled: '+str(exc)
    try:pg=paired_geometry(model,qx,qy,subpixels=cfg.subpixels);pair_reason='Validated y-reflected physical aperture pair.'
    except ValueError as exc:pg=None;pair_reason='Mirrored maps disabled: '+str(exc)
    if pg is not None:
        for edge,m in maps.items():
            m.update(paired_maps(m['I_plus'],m['I_minus'],alpha if alpha is not None else 1.,pg))
            if alpha is None:
                for key in ('D_corrected','D_mag_processed','D_nonmag_residual'):m.pop(key)
    if not np.allclose(spectra['D_raw'],spectra['D_mag']+spectra['D_nonmag'],rtol=1e-10,atol=1e-13*max(ap.max(),bp.max())):raise ArithmeticError('Detector parity identity failed')
    audit=inspect_source(cfg.source) if cfg.model=='xmcd' else None
    if audit and cfg.source_sha256 and audit['sha256']!=cfg.source_sha256:
        raise ValueError('XMCD source changed during calculation; result discarded')
    build=build_info();commit=build['commit'];dirty=build.get('dirty')
    meta=dict(settings=asdict(settings),mdff=asdict(cfg),structure=structure.description(),frame=R.tolist(),beam_hkl=[list(h) for h in hkl],g=g.tolist(),
        source_audit=audit,energy_ev=energy.tolist(),magnetization_crystal=(np.asarray(cfg.magnetization)/np.linalg.norm(cfg.magnetization)).tolist(),
        magnetization_local=(R@np.asarray(cfg.magnetization)/np.linalg.norm(cfg.magnetization)).tolist(),
        reversal='XMCD: eta reversed in crystal frame; atomic: swap spin holes and reverse exchange at transition level, fixed core-SOC amplitudes; then R T R^T',
        za_q=za_from_tilt(settings.tilt,settings.voltage).tolist(),transmitted_q=[0.,0.],wavelength_angstrom=electron_wavelength_angstrom(settings.voltage),
        s_target=float(excitation(g[hkl.index(settings.target)],settings.tilt,settings.voltage)),alpha=alpha,correction_reason=correction_reason,pair_reason=pair_reason,
        detector_areas={k:float(w.sum()*(qx[0,1]-qx[0,0])**2) for k,w in weights.items()},integration='fractional',dense_estimate_mib=memory,
        channeling_model=cfg.channeling_model,angular_maps_calculated=cfg.angular_maps,spectral_coverage=cfg.energy_scope,
        outgoing_energy_ev=(1000*settings.voltage-energy).tolist() if cfg.channeling_model=='double' else None,
        longitudinal_transfer='q_z=-E_loss/(h*v_in), evaluated at each loss; frozen across branches, not across energy; no new branch or angular corrections',
        systematic_row=cfg.systematic_row,incoming_hkl=[list(h) for h in hkl],outgoing_hkl=[list(h) for h in hkl] if cfg.channeling_model=='double' else None,
        outgoing_energy='incident energy minus actual energy loss' if cfg.channeling_model=='double' else None,
        normalization=dict(raw_components='D_mag=M_A-M_B; D_nonmag=N_A-N_B (a.u.)',components_percent='100 * signed component / (N_A+N_B)',prb='100 * (I_A_plus-I_B_plus)/(I_A_plus+I_B_plus)'),
        precision='float64/complex128',reciprocal_convention='g=1/d, Å^-1; legacy cycles/Å values unchanged',
        detector_evaluation='Full angular grid at selected L3/L2; nonzero fractional-aperture union at other energies' if cfg.angular_maps else 'Only nonzero fractional-aperture support on the unchanged grid; angular maps not calculated',
        angular_evaluation_policy=prepared.get('angular_evaluation_policy','legacy_full_grid_per_energy') if prepared is not None else 'legacy_full_grid_per_energy',
        angular_evaluation=prepared.get('diagnostics',[]) if prepared is not None else [],
        solver='Bloch-wave depth-integrated entrance-only localized single ionization',software_commit=commit,software_worktree_dirty=dirty,
        software_version=build['application_version'],software_display_version=build['display_version'],physics_convention=build['physics_convention'],
        implementation_sha256=build['implementation_sha256'],
        python=platform.python_version(),numpy=np.__version__,
        intensity_convention=('XMCD-effective; transverse source-maximum normalization; relative scattering units' if cfg.model=='xmcd' else 'Atomic length-gauge A^2/eV tensor; relative scattering units; no absolute cross-section calibration'),
        limitations='Projected IAM; '+('entrance-only, no outgoing channeling; ' if cfg.channeling_model=='single' else 'incoming and post-loss outgoing channeling; ')+ 'XMCD-effective is not full DFT MDFF; atomic non-DFT not quantitative Ni; arbitrary intensity units, no electron-count calibration; representative convergence controls do not certify all configurations.')
    stage('Preparing result visualizations')
    return dict(metadata=meta,model=model,settings=settings,config=cfg,maps=maps,spectra=spectra,qx=qx,qy=qy,weights=weights,coherence=C,depth_nm=z,amplitudes=psi)


def metrics(result):
    s=result['spectra'];rows={}
    for edge,e in (('L3',result['config'].l3),('L2',result['config'].l2)):
        i=int(np.argmin(abs(s['energy_ev']-e)));sigma=s['Sigma_ref'][i];floor=1e-10*max(float(s['Sigma_ref'].max()),1e-30)
        row={k:float(s[k][i]) if k in s else None for k in ('D_mag','D_nonmag','D_raw','D_corrected','magnetic_bias','D_nonmag_residual_obs','Sigma_ref')}
        row.update(A_mag=float(s['D_mag'][i]/sigma) if sigma>floor else None,A_nonmag=float(s['D_nonmag'][i]/sigma) if sigma>floor else None,alpha=result['metadata']['alpha'],energy_ev=float(s['energy_ev'][i]))
        rows[edge]=row
    return rows


def _export_single(result,path):
    from matplotlib.figure import Figure
    from .results import draw_maps,draw_eels
    root=Path(path);root.mkdir(parents=True,exist_ok=False)
    meta=dict(result['metadata'],edge_metrics=metrics(result))
    for name,value in (('input_parameters',dict(settings=meta['settings'],mdff=meta['mdff'],structure=meta['structure'])),('metadata',meta)):
        (root/(name+'.json')).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    np.savez_compressed(root/'virtual_detector_eels.npz',**result['spectra'])
    arrays=dict(qx=result['qx'],qy=result['qy'],coherence=result['coherence'],depth_nm=result['depth_nm'],amplitudes=result['amplitudes'])
    for edge,m in result['maps'].items():
        arrays.update({edge+'_'+k:v for k,v in m.items()})
        fig=Figure(figsize=(15,9),layout='constrained');draw_maps(fig,result,edge);fig.savefig(root/(edge+'_angular_maps.png'),dpi=145)
    arrays.update({'weight_'+k:v for k,v in result['weights'].items()});np.savez_compressed(root/'angular_maps.npz',**arrays)
    fig=Figure(figsize=(11,9),layout='constrained');draw_eels(fig,result);fig.savefig(root/'virtual_detector_eels.png',dpi=150)


def export_result(result,path,*,component_mode='raw',advanced=False,map_signal_mode=None):
    """One numerical bundle; raw and percentage spectra survive every display."""
    if advanced:
        _export_single(result,path)
        from .propagation import export_comparison
        export_comparison(result,Path(path),_export_single)
        return
    import csv
    from matplotlib.figure import Figure
    from .project_io import save_project
    from .results import draw_eels,draw_maps
    from .prb_benchmark import benchmark_spectra
    from .component_display import MODES,DEFINITIONS,exported_spectra,exported_angular
    if component_mode not in (*MODES,'relative'):raise ValueError('Unknown EMCD display mode')
    map_signal_mode=map_signal_mode or (component_mode if component_mode in MODES else 'raw')
    if map_signal_mode not in MODES:raise ValueError('Unknown angular signal display')
    root=save_project(result,path)
    derived={};unavailable={}
    methods=result.get('methods',{result.get('method','bloch'):result})
    for name,r in methods.items():
        spectra=dict(r['spectra'],**benchmark_spectra(r['spectra'])[0]);keys=list(spectra)
        with (root/(name+'_spectra.csv')).open('w',newline='',encoding='utf-8') as f:
            writer=csv.writer(f);writer.writerow(['solver','channeling_model']+keys)
            writer.writerows((name,r['config'].channeling_model,*values) for values in zip(*(spectra[k] for k in keys)))
        explicit=exported_spectra(r['spectra']);derived.update({name+'__'+k:v for k,v in explicit.items()})
        with (root/(name+'_signal_display.csv')).open('w',newline='',encoding='utf-8') as f:
            writer=csv.writer(f);writer.writerow(list(explicit));writer.writerows(zip(*explicit.values()))
        prefix='' if name==result.get('method','bloch') else name+'_'
        fig=Figure(figsize=(10,7),layout='constrained');draw_eels(fig,r,component_mode=component_mode)
        for ext in ('png','svg'):fig.savefig(root/(prefix+'virtual_detector_eels.'+ext),dpi=170)
        for edge in r['maps']:
            fig=Figure(figsize=(11,5),layout='constrained');draw_maps(fig,r,edge,signal_mode=map_signal_mode)
            try:derived.update({name+'__'+edge+'__'+k:v for k,v in exported_angular(r,edge).items()})
            except (ValueError,KeyError) as exc:unavailable[name+'__'+edge]=str(exc)
            for ext in ('png','svg'):fig.savefig(root/(prefix+edge+'_angular_maps.'+ext),dpi=170)
    derived['definitions_json']=np.array(json.dumps(DEFINITIONS))
    np.savez_compressed(root/'signal_display.npz',**derived)
    (root/'figure_display.json').write_text(json.dumps(dict(component_mode=component_mode,map_signal_mode=map_signal_mode,definitions=DEFINITIONS,unavailable_paired_maps=unavailable,
        note='Display only. CSV/NPZ retain signed raw components, both relative percentages, raw reversal spectra and denominators.',
        prb='Separate raw +M difference/sum; no factor two or post-edge correction'),indent=2)+'\n',encoding='utf-8')
